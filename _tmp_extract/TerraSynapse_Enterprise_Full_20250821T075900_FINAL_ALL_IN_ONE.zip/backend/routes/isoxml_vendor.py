from fastapi import APIRouter, Body, Query
from ..services.vendor_xsd import list_vendors, set_vendor_xsd, validate_with_vendor, set_vendor_xsd_pack

router = APIRouter(prefix="/isoxml/vendor", tags=["isoxml-vendor"])

@router.get("/list")
def list_():
    return {"ok": True, "vendors": list_vendors()}

@router.post("/set")
def set_(vendor: str = Query(...), xsd_text: str = Body(...)):
    return set_vendor_xsd(vendor, xsd_text)

@router.post("/set_pack")
def set_pack(vendor: str = Query(...), files: dict = Body(...), entrypoint: str = Body(...)):
    return set_vendor_xsd_pack(vendor, files, entrypoint)

@router.post("/validate")
def validate(vendor: str = Query(...), xml_text: str = Body(...)):
    return validate_with_vendor(vendor, xml_text)