import streamlit as st, requests, os, json

st.set_page_config(page_title="SSO – SAML2 (pysaml2)", page_icon="🛡️", layout="wide")
st.title("🛡️ SSO – SAML2 (pysaml2) – Assinatura/Validação")

api = st.text_input("Backend URL", value=os.getenv("TS_BACKEND_URL","http://localhost:8000"))
user_id = st.text_input("Seu e-mail (para permissões)", "lucas@empresa.com")

# Guard simplificado (pressupõe papel admin)
st.info("Cole abaixo o settings.json (IdP/Sp) para ativar SAML2 assinado.")
txt = st.text_area("settings.json", value=json.dumps({
    "sp":{"entityId":"http://localhost:8000/sso/saml2/metadata",
           "assertionConsumerService":{"url":"http://localhost:8000/sso/saml2/acs","binding":"urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST"},
           "singleLogoutService":{"url":"http://localhost:8000/sso/saml2/slo","binding":"urn:oasis:names:tc:SAML:2.0:bindings:HTTP-Redirect"},
           "x509cert":"", "privateKey": ""},
    "idp":{"entityId":"","singleSignOnService":{"url":"","binding":"urn:oasis:names:tc:SAML:2.0:bindings:HTTP-Redirect"},
           "singleLogoutService":{"url":"","binding":"urn:oasis:names:tc:SAML:2.0:bindings:HTTP-Redirect"}, "x509cert":""},
    "security":{"authnRequestsSigned":False,"wantAssertionsSigned":True,"wantMessagesSigned":True}
}, indent=2), height=240)

if st.button("Salvar settings"):
    try:
        payload = json.loads(txt)
        st.json(requests.post(f"{api}/sso/saml2/settings/set", json=payload).json())
    except Exception as e:
        st.error(f"JSON inválido: {e}")

st.subheader("Metadata SP")
if st.button("Gerar metadata"):
    st.json(requests.get(f"{api}/sso/saml2/metadata").json())

st.subheader("Iniciar login (URL do IdP)")
st.json(requests.get(f"{api}/sso/saml2/start").json())