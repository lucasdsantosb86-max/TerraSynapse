
from __future__ import annotations
import streamlit as st, json
from pathlib import Path
from frontend.auth import require
from frontend.security_policies import generate_backup_codes, get_backup_hash

st.set_page_config(page_title="Segurança – Códigos de Backup", page_icon="🔑", layout="centered")
user = require(roles=("developer","gestor","tecnico","visitante"))

USERS_PATH = Path("data/users/users.json")

def load_users():
    try:
        return json.loads(USERS_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {"users":[]}

def save_users(d):
    USERS_PATH.write_text(json.dumps(d, indent=2, ensure_ascii=False), encoding="utf-8")

st.title("🔑 Códigos de Backup (2FA)")
st.caption("Use apenas se perder o acesso ao app autenticador. Cada código é de uso único. Guarde em local seguro.")

d = load_users()
rec = None
for u in d["users"]:
    if u["username"] == user["username"]:
        rec = u; break

if rec is None:
    st.error("Usuário não encontrado."); st.stop()

if st.button("Gerar novos códigos (invalida os anteriores)"):
    codes = generate_backup_codes(10)
    rec["backup_codes"] = [{"hash": get_backup_hash(c), "used": False} for c in codes]
    save_users(d)
    st.success("Anote seus códigos abaixo. Eles só serão mostrados uma vez!")
    st.code("\n".join(codes))

if rec.get("backup_codes"):
    used = sum(1 for c in rec["backup_codes"] if c.get("used"))
    total = len(rec["backup_codes"])
    st.info(f"Códigos existentes: {total} (usados: {used})")
else:
    st.info("Nenhum código ativo.")
