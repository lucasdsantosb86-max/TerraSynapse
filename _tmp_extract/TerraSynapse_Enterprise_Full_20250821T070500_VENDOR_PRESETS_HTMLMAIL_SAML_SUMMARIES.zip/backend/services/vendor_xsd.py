from pathlib import Path
from lxml import etree

BASE = Path(__file__).resolve().parents[2]
DIR  = BASE/"config"/"vendor_xsd"
DIR.mkdir(parents=True, exist_ok=True)

def list_vendors():
    return [p.stem for p in DIR.glob("*.xsd")]

def set_vendor_xsd(vendor: str, xsd_text: str):
    fp = DIR/f"{vendor}.xsd"
    fp.write_text(xsd_text, encoding="utf-8")
    return {"ok": True, "path": str(fp.relative_to(BASE))}

def validate_with_vendor(vendor: str, xml_text: str):
    fp = DIR/f"{vendor}.xsd"
    if not fp.exists():
        return {"ok": False, "error":"vendor_xsd_not_found"}
    parser = etree.XMLParser(remove_blank_text=True)
    xml_doc = etree.fromstring(xml_text.encode("utf-8"), parser)
    schema = etree.XMLSchema(etree.parse(str(fp)))
    ok = schema.validate(xml_doc)
    return {"ok": bool(ok), "errors": [str(e) for e in schema.error_log]}