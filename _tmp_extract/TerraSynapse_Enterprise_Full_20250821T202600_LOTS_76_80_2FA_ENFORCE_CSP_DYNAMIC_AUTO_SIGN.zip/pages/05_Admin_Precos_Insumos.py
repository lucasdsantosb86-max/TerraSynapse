import json
from pathlib import Path
import streamlit as st

st.set_page_config(page_title="Admin – Preços de Insumos", page_icon="💲")
st.title("💲 Admin – Preços de Insumos (R$ por unidade)")

PRICES_PATH = Path(__file__).resolve().parents[1]/"data"/"prices"/"precos_insumos.json"

prices = {}
if PRICES_PATH.exists():
    prices = json.loads(PRICES_PATH.read_text(encoding="utf-8"))

st.caption("Edite os preços unitários. As unidades devem corresponder às taxas por cultura (ex.: kg, L, mil sementes, muda).")

for k in list(prices.keys()):
    prices[k] = st.number_input(f"{k}", value=float(prices[k]), min_value=0.0, step=0.01)

if st.button("Salvar preços"):
    PRICES_PATH.write_text(json.dumps(prices, ensure_ascii=False, indent=2), encoding="utf-8")
    st.success("Preços salvos.")