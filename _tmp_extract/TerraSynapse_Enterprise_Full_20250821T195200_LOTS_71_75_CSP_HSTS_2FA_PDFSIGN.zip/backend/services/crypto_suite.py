import os, json, base64, secrets, time, hmac, hashlib
from pathlib import Path
from typing import Tuple
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives import hashes
from nacl import signing
from argon2 import PasswordHasher

BASE = Path(__file__).resolve().parents[2]
CONF = BASE/"config"/"security.json"
KEYS = BASE/"config"/"keys"
KEYS.mkdir(parents=True, exist_ok=True)

def _conf():
    return json.loads(CONF.read_text(encoding="utf-8"))

def _get_master_key() -> bytes:
    env = _conf()["kms"]["master_key_env"]
    b64 = os.getenv(env, "")
    if not b64:
        # gera uma key transitória (dev); em prod, exigir env
        k = secrets.token_bytes(32)
        return k
    return base64.b64decode(b64)

def _derive_dek(salt: bytes) -> bytes:
    hkdf = HKDF(algorithm=hashes.SHA256(), length=32, salt=salt, info=b"TS:DEK")
    return hkdf.derive(_get_master_key())

def encrypt_bytes(data: bytes, aad: bytes = b"") -> bytes:
    salt = secrets.token_bytes(16)
    dek  = _derive_dek(salt)
    aesgcm = AESGCM(dek)
    nonce = secrets.token_bytes(12)
    ct = aesgcm.encrypt(nonce, data, aad)
    return b"TS1" + salt + nonce + ct  # header simples

def decrypt_bytes(blob: bytes, aad: bytes = b"") -> bytes:
    assert blob[:3] == b"TS1", "header inválido"
    salt = blob[3:19]; nonce = blob[19:31]; ct = blob[31:]
    dek  = _derive_dek(salt)
    aesgcm = AESGCM(dek)
    return aesgcm.decrypt(nonce, ct, aad)

def encrypt_file(src: str, dst: str):
    p = Path(src); data = p.read_bytes()
    blob = encrypt_bytes(data, aad=p.name.encode())
    Path(dst).write_bytes(blob); return {"ok": True, "out": dst}

def decrypt_file(src: str, dst: str):
    p = Path(src); data = p.read_bytes()
    out = decrypt_bytes(data, aad=Path(dst).name.encode())
    Path(dst).write_bytes(out); return {"ok": True, "out": dst}

# Assinatura Ed25519 de artefatos (ex.: index_snippets.jsonl)
def _load_or_create_signer():
    sk_p = KEYS/"signing_ed25519.sk"
    pk_p = KEYS/"signing_ed25519.pk"
    if sk_p.exists() and pk_p.exists():
        sk = signing.SigningKey(sk_p.read_bytes())
        pk = signing.VerifyKey(pk_p.read_bytes())
        return sk, pk
    sk = signing.SigningKey.generate()
    pk = sk.verify_key
    sk_p.write_bytes(bytes(sk)); pk_p.write_bytes(bytes(pk))
    return sk, pk

def sign_file(src: str):
    sk, pk = _load_or_create_signer()
    data = Path(src).read_bytes()
    sig = sk.sign(data).signature
    Path(src + ".sig").write_bytes(sig)
    Path(src + ".pub").write_bytes(bytes(pk))
    return {"ok": True, "sig": base64.b64encode(sig).decode()}

def verify_file(src: str):
    pk_p = KEYS/"signing_ed25519.pk"
    sig_p= Path(src + ".sig")
    if not pk_p.exists() or not sig_p.exists(): return {"ok": False, "detail":"keys/sig ausentes"}
    pk = signing.VerifyKey(pk_p.read_bytes())
    data = Path(src).read_bytes()
    sig = sig_p.read_bytes()
    try:
        pk.verify(data, sig)
        return {"ok": True}
    except Exception as e:
        return {"ok": False, "detail": str(e)}

# Hash em cadeia (audit log à prova de adulteração)
def chain_hash(prev_hash: bytes, entry: bytes) -> bytes:
    return hashlib.sha256(prev_hash + entry).digest()

# Password hashing (Argon2id)
_ph = PasswordHasher(time_cost=3, memory_cost=65536, parallelism=2)
def hash_password(pw: str) -> str:
    return _ph.hash(pw)
def verify_password(hash_str: str, pw: str) -> bool:
    try:
        return _ph.verify(hash_str, pw)
    except Exception:
        return False