
from __future__ import annotations
import json, glob
from pathlib import Path

KNOW_DIR = Path("data/knowledge")
INDEX_PATH = KNOW_DIR/"index_snippets.jsonl"

def list_sources():
    files = sorted(str(p) for p in KNOW_DIR.glob("snippets_premium_lote*.jsonl"))
    return {"files": files, "count_files": len(files)}

def ingest_all():
    files = sorted(KNOW_DIR.glob("snippets_premium_lote*.jsonl"))
    total = 0
    with open(INDEX_PATH, "w", encoding="utf-8") as out:
        for fp in files:
            for line in fp.read_text(encoding="utf-8").splitlines():
                if line.strip():
                    out.write(line+"\n"); total += 1
    return {"indexed": total, "index": str(INDEX_PATH)}
