from pathlib import Path
from cryptography.fernet import Fernet, InvalidToken
import json, os

BASE = Path(__file__).resolve().parents[2]
CONF = BASE / "config"
CONF.mkdir(parents=True, exist_ok=True)
VAULT = CONF / "secrets.enc"
KEY_ENV = "TS_SECRETS_KEY"

def _fernet():
    key = os.getenv(KEY_ENV, None)
    if not key:
        raise RuntimeError(f"Defina a variável de ambiente {KEY_ENV} com uma chave Fernet (base64).")
    return Fernet(key.encode())

def _load():
    if not VAULT.exists():
        return {}
    f = _fernet()
    try:
        data = f.decrypt(VAULT.read_bytes())
        return json.loads(data.decode("utf-8"))
    except InvalidToken:
        raise RuntimeError("Chave do cofre inválida.")
    except Exception:
        return {}

def _save(obj: dict):
    f = _fernet()
    VAULT.write_bytes(f.encrypt(json.dumps(obj).encode("utf-8")))

def set_secret(provider: str, key: str, value: str):
    obj = _load()
    obj.setdefault(provider, {})[key] = value
    _save(obj)
    return True

def get_secret(provider: str, key: str):
    obj = _load()
    return obj.get(provider, {}).get(key)

def list_providers():
    obj = _load()
    return list(obj.keys())

def masked(provider: str):
    obj = _load().get(provider, {})
    return {k: ("***" if v else "") for k,v in obj.items()}