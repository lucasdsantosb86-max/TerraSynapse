#!/usr/bin/env bash
set -euo pipefail

APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$APP_DIR"

usage() {
  cat <<EOF
TerraSynapse – run_all.sh
Uso: ./run_all.sh [start|stop|status|restart]

Comandos:
  start    Sobe backend (Uvicorn) e painéis Streamlit principais
  stop     Para todos os processos iniciados por este script
  status   Mostra PIDs/ports e teste de saúde
  restart  stop + start

Variáveis (opcionais):
  BACKEND_HOST (default: 0.0.0.0)
  BACKEND_PORT (default: 8000)
  STREAMLIT_PORT_BASE (default: 8501)
  STREAMLIT_APPS (default: páginas-chave)
EOF
}

BACKEND_HOST="${BACKEND_HOST:-0.0.0.0}"
BACKEND_PORT="${BACKEND_PORT:-8000}"
STREAMLIT_PORT_BASE="${STREAMLIT_PORT_BASE:-8501}"
STREAMLIT_APPS="${STREAMLIT_APPS:-pages/04_Gerenciar_Usuarios.py pages/27_ISOXML_Schemas_Vendor.py pages/28_ISOXML_Vendor_Presets.py pages/44_Scheduler_Summaries.py}"

VENV="${APP_DIR}/.venv"
LOGS="${APP_DIR}/logs"
PIDS="${APP_DIR}/.pids"
mkdir -p "$LOGS" "$PIDS"

ensure_python() {
  command -v python3 >/dev/null 2>&1 || { echo "python3 não encontrado"; exit 1; }
  ver=$(python3 - <<'PY'
import sys;print(".".join(map(str,sys.version_info[:2])))
PY)
  echo "Python $ver"
}

ensure_venv() {
  if [ ! -d "$VENV" ]; then
    python3 -m venv "$VENV"
  fi
  # shellcheck source=/dev/null
  source "$VENV/bin/activate"
  pip install --upgrade pip >/dev/null
  pip install -r requirements.txt
}

gen_secret_if_needed() {
  if [ -z "${TS_SECRETS_KEY:-}" ]; then
    export TS_SECRETS_KEY=$(python3 - <<'PY'
from cryptography.fernet import Fernet;print(Fernet.generate_key().decode())
PY)
    echo "TS_SECRETS_KEY gerada (sessão atual)"
  fi
}

start_backend() {
  echo "Iniciando backend em ${BACKEND_HOST}:${BACKEND_PORT} ..."
  nohup "$VENV/bin/python" -m uvicorn backend.app:app --host "$BACKEND_HOST" --port "$BACKEND_PORT" >"$LOGS/backend.out" 2>"$LOGS/backend.err" &
  echo $! > "$PIDS/backend.pid"
  echo "Backend PID $(cat "$PIDS/backend.pid")"
}

start_streamlit() {
  i=0
  for app in $STREAMLIT_APPS; do
    port=$((STREAMLIT_PORT_BASE + i))
    name=$(basename "$app" .py)
    echo "Iniciando Streamlit $name na porta $port ..."
    nohup "$VENV/bin/streamlit" run "$app" --server.port "$port" --server.headless true >"$LOGS/streamlit_${name}.out" 2>"$LOGS/streamlit_${name}.err" &
    echo $! > "$PIDS/streamlit_${name}.pid"
    i=$((i+1))
  done
}

stop_all() {
  for f in "$PIDS"/*.pid; do
    [ -e "$f" ] || continue
    pid=$(cat "$f" || true)
    if [ -n "$pid" ]; then
      kill "$pid" >/dev/null 2>&1 || true
    fi
    rm -f "$f"
  done
  echo "Processos finalizados."
}

status_all() {
  echo "Status:"
  for f in "$PIDS"/*.pid; do
    [ -e "$f" ] || continue
    name=$(basename "$f" .pid)
    pid=$(cat "$f")
    if ps -p "$pid" >/dev/null 2>&1; then
      echo "  ${name}: PID ${pid} (ativo)"
    else
      echo "  ${name}: PID ${pid} (morto)"
    fi
  done
  echo "Health-check backend:"
  curl -s "http://127.0.0.1:${BACKEND_PORT}/docs" >/dev/null && echo "  /docs OK" || echo "  /docs FAIL"
}

cmd="${1:-help}"
case "$cmd" in
  start)
    ensure_python
    ensure_venv
    gen_secret_if_needed
    start_backend
    start_streamlit
    ;;
  stop) stop_all ;;
  status) status_all ;;
  restart) stop_all; sleep 1; "$0" start ;;
  *) usage ;;
esac
