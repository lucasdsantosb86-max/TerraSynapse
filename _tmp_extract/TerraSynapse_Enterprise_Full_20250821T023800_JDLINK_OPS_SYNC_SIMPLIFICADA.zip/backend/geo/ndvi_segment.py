# NDVI/segmentação utilitário – TerraSynapse
# Requer: numpy, rasterio (GeoTIFF), PIL (RGB fallback)
import numpy as np

def ndvi_from_bands(red: np.ndarray, nir: np.ndarray, eps: float=1e-6) -> np.ndarray:
    red = red.astype("float32"); nir = nir.astype("float32")
    return (nir - red) / (nir + red + eps)

def ndvi_proxy_from_rgb(rgb: np.ndarray) -> np.ndarray:
    # Proxy simples (ex.: G-R normalizado) quando não há NIR
    rgb = rgb.astype("float32")
    g = rgb[...,1]; r = rgb[...,0]
    return (g - r) / (g + r + 1e-6)

def segment_ndvi(ndvi: np.ndarray, threshold: float=0.30) -> np.ndarray:
    # binário: 1 = vegetação (plantável/vegetada), 0 = não-vegetado
    return (ndvi >= threshold).astype("uint8")

def area_ha_from_mask(mask: np.ndarray, pixel_area_m2: float) -> float:
    # Área (ha) = (pixels_1 * área_pixel_m2) / 10_000
    return float(mask.sum()) * float(pixel_area_m2) / 10000.0