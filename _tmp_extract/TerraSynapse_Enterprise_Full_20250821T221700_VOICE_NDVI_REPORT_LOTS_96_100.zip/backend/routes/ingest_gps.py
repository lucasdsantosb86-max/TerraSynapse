from fastapi import APIRouter
from pydantic import BaseModel
from typing import List
from ..services.gps import append_points, km_por_dia

router = APIRouter(prefix="/ingest/gps", tags=["gps"])

class GPSPoint(BaseModel):
    timestamp: float | str
    animal_id: str
    lat: float
    lon: float

@router.post("")
def ingest(points: List[GPSPoint]):
    return append_points([p.dict() for p in points])

@router.get("/km_dia")
def km_dia():
    return km_por_dia()