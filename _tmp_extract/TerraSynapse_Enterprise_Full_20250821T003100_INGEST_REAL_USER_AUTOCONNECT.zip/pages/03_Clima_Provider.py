import json, os
from pathlib import Path
import streamlit as st

POL_PATH = Path(__file__).resolve().parents[1]/"data"/"security"/"policies.json"
KEY_PATH = Path(__file__).resolve().parents[1]/"data"/"security"/"api_keys.json"

st.set_page_config(page_title="Clima – Provedor", page_icon="🌦️")

st.title("🌦️ Provedor de Clima – TerraSynapse")
st.caption("Selecione o provedor e configure as chaves de API.")

pol = json.loads(POL_PATH.read_text(encoding="utf-8"))
keys = json.loads(KEY_PATH.read_text(encoding="utf-8"))

prov = st.radio("Provedor", ["climatempo","openweather"], index=0 if pol.get("weather_provider")=="climatempo" else 1)

if prov=="climatempo":
    token = st.text_input("ClimaTempo — token", value=keys.get("climatempo_token",""))
    locale = st.number_input("ClimaTempo — localeId (cidade)", value=int(pol.get("weather_locale_id",3477)), step=1)
    st.info("Dica: é necessário **registrar a cidade** no token antes de consultar. Use o botão abaixo.")
    if st.button("Registrar cidade no token (ClimaTempo)"):
        import requests
        url = "http://localhost:8000/weather/climatempo/register"
        try:
            r = requests.post(url, params={"locale_id": int(locale)}, timeout=10)
            st.success(f"Registro: {r.status_code} — {r.text[:200]}")
        except Exception as e:
            st.error(f"Erro ao registrar: {e}")
    pol["weather_provider"] = "climatempo"
    pol["weather_locale_id"] = int(locale)
    keys["climatempo_token"] = token
else:
    ow = st.text_input("OpenWeather — API key", value=keys.get("openweather_key",""))
    pol["weather_provider"] = "openweather"
    keys["openweather_key"] = ow

if st.button("Salvar configuração"):
    POL_PATH.write_text(json.dumps(pol, ensure_ascii=False, indent=2), encoding="utf-8")
    KEY_PATH.write_text(json.dumps(keys, ensure_ascii=False, indent=2), encoding="utf-8")
    st.success("Configurações salvas.")

st.divider()
st.subheader("Teste rápido")
if st.button("Ver clima atual (/weather/current)"):
    import requests
    try:
        r = requests.get("http://localhost:8000/weather/current", timeout=10)
        st.code(r.json())
    except Exception as e:
        st.error(f"Erro ao consultar backend: {e}")