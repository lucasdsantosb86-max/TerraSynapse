from pathlib import Path
from lxml import etree

BASE = Path(__file__).resolve().parents[2]
XSD  = BASE/"config"/"isoxml_xsd"/"isoxml_lite.xsd"

def validate_with_xsd(xml_text: str):
    parser = etree.XMLParser(remove_blank_text=True)
    xml_doc = etree.fromstring(xml_text.encode("utf-8"), parser)
    schema = etree.XMLSchema(etree.parse(str(XSD)))
    ok = schema.validate(xml_doc)
    return {"ok": bool(ok), "errors": [str(e) for e in schema.error_log]}