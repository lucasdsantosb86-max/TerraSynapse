from fastapi import APIRouter, Body, Query
from ..services.alerts_webhook import set_webhook, set_threshold
from ..services.disconnection import check_and_alert

router = APIRouter(prefix="/alerts", tags=["alerts"])

@router.post("/webhook/set")
def webhook(url: str = Body(...)):
    return set_webhook(url)

@router.post("/disconnect/threshold")
def threshold(hours: int = Body(...)):
    return set_threshold(hours)

@router.post("/disconnect/check_now")
def check_now():
    return check_and_alert()