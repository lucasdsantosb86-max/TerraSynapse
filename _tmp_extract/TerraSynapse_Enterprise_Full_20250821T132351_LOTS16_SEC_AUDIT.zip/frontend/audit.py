
from __future__ import annotations
from pathlib import Path
import json, datetime as dt, csv

AUDIT_DIR = Path("data/audit"); AUDIT_DIR.mkdir(parents=True, exist_ok=True)
LOG = AUDIT_DIR/"audit_log.jsonl"
CSV = AUDIT_DIR/"audit_log.csv"

def log_action(actor: str, action: str, target_type: str, target_id: str, details: dict|None=None):
    rec = {
        "ts": dt.datetime.utcnow().isoformat()+"Z",
        "actor": actor,
        "action": action,          # create/update/delete/login/role_change/etc
        "target_type": target_type,# user/role/policy
        "target_id": target_id,
        "details": details or {}
    }
    with LOG.open("a", encoding="utf-8") as f:
        f.write(json.dumps(rec, ensure_ascii=False)+"\n")
    # CSV append (flat)
    hdr = ["ts","actor","action","target_type","target_id","details"]
    new = not CSV.exists()
    with CSV.open("a", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        if new: w.writerow(hdr)
        w.writerow([rec["ts"], rec["actor"], rec["action"], rec["target_type"], rec["target_id"], json.dumps(rec["details"], ensure_ascii=False)])
