import streamlit as st, os, json, pathlib, requests

st.set_page_config(page_title="Admin – Agendador Diário", page_icon="⏰", layout="centered")
st.title("⏰ Admin – Agendador Diário (APScheduler)")

api = st.text_input("Backend URL", value=os.getenv("TS_BACKEND_URL","http://localhost:8000"))

cfg_p = pathlib.Path("config/scheduler.json")
cfg = json.loads(cfg_p.read_text(encoding="utf-8"))
st.write("Time zone:", cfg.get("timezone"))
new_time = st.text_input("Horário diário (HH:MM)", value=cfg.get("daily_time","06:10"))

col1, col2, col3 = st.columns(3)
if col1.button("Salvar horário"):
    cfg["daily_time"] = new_time
    cfg_p.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
    st.success("Horário salvo.")

if col2.button("Iniciar agendador"):
    st.json(requests.post(f"{api}/scheduler/start", json={"api_base": api}).json())

if col3.button("Parar agendador"):
    st.json(requests.post(f"{api}/scheduler/stop").json())

st.markdown("---")
st.subheader("Status")
try:
    st.json(requests.get(f"{api}/scheduler/status").json())
except Exception as e:
    st.error(str(e))