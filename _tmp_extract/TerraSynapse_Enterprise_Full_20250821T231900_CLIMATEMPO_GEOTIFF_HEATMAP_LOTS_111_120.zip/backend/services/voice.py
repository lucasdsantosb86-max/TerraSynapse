from pathlib import Path
import soundfile as sf
import json, time
from vosk import Model, KaldiRecognizer
import pyttsx3

BASE = Path(__file__).resolve().parents[2]
VOICE = BASE/"data"/"voice"
VOICE.mkdir(parents=True, exist_ok=True)

_models = {}

def _get_stt_model(lang="pt"):  # 'pt' (modelo local deve estar em data/voice/model_pt/)
    key = f"stt_{lang}"
    if key not in _models:
        mp = VOICE/f"model_{lang}"
        if not mp.exists():
            raise RuntimeError(f"Modelo Vosk não encontrado em {mp}. Coloque o modelo offline aqui.")
        _models[key] = Model(str(mp))
    return _models[key]

def stt_from_wav(wav_path: str, lang="pt"):
    model = _get_stt_model(lang)
    import wave
    wf = wave.open(wav_path, "rb")
    rec = KaldiRecognizer(model, wf.getframerate())
    rec.SetWords(True)
    text = ""
    while True:
        data = wf.readframes(4000)
        if len(data)==0: break
        if rec.AcceptWaveform(data):
            res = json.loads(rec.Result()); text += " " + res.get("text","")
    res = json.loads(rec.FinalResult()); text += " " + res.get("text","")
    return {"ok": True, "text": text.strip()}

def tts_to_wav(text: str, out_path: str):
    engine = pyttsx3.init()
    engine.setProperty('rate', 175)
    engine.save_to_file(text, out_path)
    engine.runAndWait()
    return {"ok": True, "out": out_path}