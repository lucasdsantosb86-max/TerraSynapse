import streamlit as st
from pathlib import Path
from PIL import Image
import numpy as np
import requests, io, os, json

st.set_page_config(page_title="Planejamento de Talhão", page_icon="🛰️", layout="wide")

st.markdown("""
<style>
:root{ --verde:#2E7D32; --azul:#1565C0; --cinza:#607D8B; --oliva:#6B8E23; }
</style>
""", unsafe_allow_html=True)

st.title("🛰️ Planejamento de Talhão – NDVI & Segmentação (proxy)")

colA, colB = st.columns(2)
with colA:
    up = st.file_uploader("Upload de imagem aérea (RGB/GeoTIFF convertido em PNG)", type=["png","jpg","jpeg"])
    talhao = st.text_input("Nome do talhão", "Talhão 1")
    area_ha = st.number_input("Área estimada (ha)", 0.0, 100000.0, 10.0)
with colB:
    ndvi_ok = st.checkbox("Calcular NDVI proxy (RGB)", True)
    gerar_pdf = st.checkbox("Gerar relatório PDF", True)
    logo = st.text_input("Caminho do logo (opcional)", "")

img_disp = None; ndvi_mean = 0.0; zonas = []
if up:
    img = Image.open(up).convert("RGB")
    img_disp = img.copy()
    arr = np.array(img).astype(np.float32)
    R = arr[:,:,0]; G = arr[:,:,1]; B = arr[:,:,2]
    ndvi = (G - R) / (G + R + 1e-5)  # proxy NDVI a partir de RGB
    ndvi_mean = float(np.clip(np.nanmean(ndvi), -1.0, 1.0))
    # zonas simples por quantis
    q1,q2 = np.quantile(ndvi, [0.33, 0.66])
    zonas = [
        {"id":"Z1","area_ha":area_ha*0.33,"vigor":"baixo","sementes":"-","adubo":"-","defensivos":"-"},
        {"id":"Z2","area_ha":area_ha*0.34,"vigor":"médio","sementes":"-","adubo":"-","defensivos":"-"},
        {"id":"Z3","area_ha":area_ha*0.33,"vigor":"alto","sementes":"-","adubo":"-","defensivos":"-"},
    ]
    st.subheader("Preview NDVI (proxy)")
    st.image(((ndvi - ndvi.min())/(ndvi.max()-ndvi.min()+1e-6)*255).astype(np.uint8), caption=f"NDVI proxy (médio: {ndvi_mean:.3f})", use_column_width=True)

if st.button("Gerar Relatório / Salvar"):
    api = os.getenv("TS_BACKEND_URL","http://localhost:8000")
    payload = {
        "talhao": talhao, "area_ha": area_ha, "ndvi_medio": ndvi_mean,
        "zonas": zonas, "custos": {"Sementes (R$/ha)":"-","NPK (R$/ha)":"-","Defensivos (R$/ha)":"-"},
        "logo_path": logo or None, "user_name": "Lucas"
    }
    try:
        r = requests.post(f"{api}/reports/talhao/generate", json=payload, timeout=60)
        st.success("Relatório gerado"); st.json(r.json())
    except Exception as e:
        st.error(str(e))