import streamlit as st, requests, os, json

st.set_page_config(page_title="Admin – Logs de Eventos", page_icon="🧾", layout="wide")
st.title("🧾 Logs de Eventos & Reenvio")

api = st.text_input("Backend URL", value=os.getenv("TS_BACKEND_URL","http://localhost:8000"))
col = st.columns(3)
start = col[0].text_input("Início (ISO8601, opcional)", "")
end   = col[1].text_input("Fim (ISO8601, opcional)", "")
limit = col[2].number_input("Limite", 50, 2000, 200)

if st.button("Buscar logs"):
    j = requests.get(f"{api}/events/logs", params={"start": start or None, "end": end or None, "limit": limit}).json()
    st.json(j)
    st.session_state.logs = j.get("events", [])

st.markdown("---")
st.subheader("Reenviar eventos selecionados")
sel = st.text_area("Cole JSON de eventos (lista)", "[]")
if st.button("Reenviar"):
    try:
        arr = json.loads(sel)
        r = requests.post(f"{api}/events/logs/resend", json=arr).json()
        st.json(r)
    except Exception as e:
        st.error(str(e))

st.markdown("---")
st.subheader("Gerar PDF de Alertas")
col2 = st.columns(2)
st_start = col2[0].text_input("Início (ISO8601, opcional)", "")
st_end   = col2[1].text_input("Fim (ISO8601, opcional)", "")
if st.button("Gerar PDF"):
    r = requests.get(f"{api}/reports/alerts/pdf", params={"start": st_start or None, "end": st_end or None}).json()
    if r.get("ok"):
        st.success("Relatório gerado")
        st.write(r["path"])
        st.markdown(f"[Baixar PDF]({api.rstrip('/')}/{r['path']})")
    else:
        st.error("Falha ao gerar PDF")