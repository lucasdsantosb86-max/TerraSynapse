from pathlib import Path
import json, re, time
import numpy as np
from typing import List, Dict, Any, Tuple

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import joblib

BASE = Path(__file__).resolve().parents[2]
KNOW = BASE/"data"/"knowledge"
CACHE = BASE/"data"/"cache"
CACHE.mkdir(parents=True, exist_ok=True)

# Estado em memória (pré-carregamento)
_STATE = {
    "models": {},     # category -> (vectorizer, matrix, meta)
    "mtimes": {},     # category -> mtime do índice
}

def _load_snippets() -> List[Dict[str,Any]]:
    idx = KNOW/"index_snippets.jsonl"
    if not idx.exists():
        return []
    rows = []
    for line in idx.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            rows.append(json.loads(line))
        except:
            pass
    return rows

def _filter_by_category(snips, category: str):
    if not category or category.lower() in ["todas","all","*"]:
        return snips
    cat = category.lower()
    out = []
    for r in snips:
        c = (r.get("category") or r.get("culture") or "misc").lower()
        if cat in c or c in cat:
            out.append(r)
    return out or snips  # fallback

def _index_mtime() -> float:
    idx = KNOW/"index_snippets.jsonl"
    return idx.stat().st_mtime if idx.exists() else 0.0

def build_cache(category: str = "all") -> Dict[str, Any]:
    snips = _load_snippets()
    snips = _filter_by_category(snips, category)
    texts = [f"{r.get('title','')} — {r.get('content','')}" for r in snips]
    if not texts:
        return {"ok": False, "detail": "Sem snippets para cache."}
    vec = TfidfVectorizer(max_features=50000, ngram_range=(1,2))
    X = vec.fit_transform(texts)
    meta = [{"id": r.get("id",""), "title": r.get("title",""), "category": r.get("category",""), "culture": r.get("culture",""), "premium": r.get("premium",False)} for r in snips]
    # Persistência (fallback)
    joblib.dump(vec, CACHE/f"tfidf_{category}.joblib")
    joblib.dump(X, CACHE/f"tfidf_{category}.npz")
    (CACHE/f"tfidf_{category}.meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    # Memória
    _STATE["models"][category] = (vec, X, meta, snips)
    _STATE["mtimes"][category] = _index_mtime()
    return {"ok": True, "count": len(meta)}

def _ensure_loaded(category: str):
    mtime = _index_mtime()
    if category in _STATE["models"]:
        if _STATE["mtimes"].get(category,0) != mtime:
            # Hot‑reload
            build_cache(category)
        return
    # tenta carregar do disco; se não houver, constrói
    vec_p = CACHE/f"tfidf_{category}.joblib"
    mat_p = CACHE/f"tfidf_{category}.npz"
    meta_p= CACHE/f"tfidf_{category}.meta.json"
    if vec_p.exists() and mat_p.exists() and meta_p.exists():
        vec = joblib.load(vec_p); X = joblib.load(mat_p); meta = json.loads(meta_p.read_text(encoding="utf-8"))
        snips = _load_snippets()
        snips = _filter_by_category(snips, category)
        _STATE["models"][category] = (vec, X, meta, snips)
        _STATE["mtimes"][category] = _index_mtime()
    else:
        build_cache(category)

# Vocabulário para boosts (pode ser ampliado)
CULTURE_TERMS = [
    "soja","milho","cana","café","trigo","citros","laranja","arroz","algodão","amendoim","sorgo",
    "equinos","bovinos","suínos","aves"
]
DISEASE_TERMS = [
    "ferrugem","mancha","cercosporiose","antracnose","broca","lagarta","brusone",
    "hlb","greening","septoriose","giberela","oidio","mofo","nematoide","cancro"
]
OP_TERMS = ["ndvi","fertirrigação","pulverização","geada","zarc","benchmark","custo/ha","confinamento","racao","gmd","kpi"]

def _keyword_boosts(text: str, query: str) -> Tuple[float, Dict[str,float]]:
    T = text.lower()
    q = query.lower()
    bonus = 0.0
    parts = re.findall(r"[a-zá-ú0-9_/.-]+", q)
    detail = {}
    for w in parts:
        if w in CULTURE_TERMS and w in T:
            bonus += 0.10; detail[w] = detail.get(w,0)+0.10
        elif w in DISEASE_TERMS and w in T:
            bonus += 0.08; detail[w] = detail.get(w,0)+0.08
        elif w in OP_TERMS and w in T:
            bonus += 0.05; detail[w] = detail.get(w,0)+0.05
    return min(bonus, 0.4), detail  # teto para não dominar

def search(query: str, category: str = "all", top_k: int = 8) -> Dict[str, Any]:
    _ensure_loaded(category)
    vec, X, meta, snips = _STATE["models"][category]
    qv = vec.transform([query])
    tfidf_sims = cosine_similarity(qv, X).ravel()
    results = []
    for i, m in enumerate(meta):
        # conteúdo para boosts
        content = None
        if m.get("id"):
            for s in snips:
                if s.get("id")==m["id"]:
                    content = s.get("content",""); break
        fulltext = f"{m.get('title','')} — {content or ''}"
        kb, d = _keyword_boosts(fulltext, query)
        premium_bonus = 0.07 if m.get("premium") else 0.0
        sim = float(tfidf_sims[i])
        hybrid = 0.72*sim + kb + premium_bonus
        results.append({
            "score_tfidf": round(sim,4),
            "score_hybrid": round(hybrid,4),
            "premium_bonus": premium_bonus,
            "keyword_bonus": round(kb,4),
            "id": m.get("id",""), "title": m.get("title",""), "category": m.get("category",""), "culture": m.get("culture",""),
            "content": content,
            "explain": {
                "matched_terms": d,
                "premium": bool(m.get("premium",False)),
                "formula": "0.72*tfidf + keyword_bonus + premium(0.07)"
            }
        })
    # ordena por híbrido
    results.sort(key=lambda r: r["score_hybrid"], reverse=True)
    return {"ok": True, "results": results[:top_k]}

def warm_startup(categories: List[str]):
    for c in categories:
        build_cache(c)
    return {"ok": True, "preloaded": categories}

# Termos por perfil profissional (boosts adicionais)
PROFILE_TERMS = {
    "agricultor": ["dose","calda","pulverização","plantadeira","adubo","lagarta","ferrugem","praga","NDVI","chuva","geada"],
    "eng_agronomo": ["fenologia","adubação","CTC","VR%","ZARC","manejo integrado","deficiência","calibração","deriva","ETc","CAD"],
    "zootecnista": ["confinamento","GMD","ração","FCR","nutrição","silagem","escória","bem‑estar","escore corporal","genética"],
    "veterinario": ["CCS","mastite","sanidade","vacinação","biossegurança","lesão","casco","ectima","verminose","antemortem"],
    "tecnico_agro": ["checklist","bico","pressão","faixa","deriva","calibração","adjuvante","taxa","manutenção","operacional"],
    "gestor": ["R$/ha","benchmark","margem","COE","COT","hedge","barter","logística","KPIs","orçamento"],
    "programador": ["API","MQTT","REST","webhook","sensor","drone","GeoTIFF","GeoJSON","onnx","latency"],
    "piscicultor": ["oxigênio","aeração","amônia","nitrito","pH","RAS","FCR","tilápia","tambaqui","densidade"]
}

def _profile_bonus(text: str, profile: str) -> float:
    if not profile: return 0.0
    p = profile.lower().strip()
    terms = PROFILE_TERMS.get(p, [])
    T = text.lower()
    bonus = 0.0
    for w in terms:
        if w.lower() in T:
            bonus += 0.05
            if bonus >= 0.25:  # teto por perfil
                break
    return bonus
