
import streamlit as st
def apply_theme():
    # Paleta: Verde #2E7D32, Azul #1565C0, Cinza #607D8B, Verde Oliva #556B2F
    css = f'''
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap');
    html, body, [class*="css"]  { '{' } font-family: "Inter", system-ui, -apple-system, Segoe UI, Roboto, Ubuntu, Cantarell, "Helvetica Neue", Arial, "Noto Sans", "Liberation Sans", sans-serif; { '}' }
    :root { '{' }
      --ts-green: #2E7D32;
      --ts-blue:  #1565C0;
      --ts-gray:  #607D8B;
      --ts-olive: #556B2F;
    { '}' }
    .stButton>button { '{' } background: var(--ts-green); color: #fff; border-radius: 12px; { '}' }
    .stTabs [data-baseweb="tab-highlight"] { '{' } background: var(--ts-blue) !important; { '}' }
    .stMetric { '{' } border: 1px solid var(--ts-gray); border-radius: 12px; padding: 8px; { '}' }
    </style>
    '''
    st.markdown(css, unsafe_allow_html=True)
