from fastapi import APIRouter, Query
from ..services.user_roles import get_role

router = APIRouter(prefix="/auth", tags=["auth"])

@router.get("/role")
def role(user_id: str = Query(...)):
    return {"ok": True, "user_id": user_id, "role": get_role(user_id)}