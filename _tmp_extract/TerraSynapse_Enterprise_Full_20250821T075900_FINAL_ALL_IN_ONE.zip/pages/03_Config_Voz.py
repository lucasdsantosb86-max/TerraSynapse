import streamlit as st, json, os
from pathlib import Path

st.set_page_config(page_title="Voz / Áudio", page_icon="🎤", layout="wide")
st.title("🎤 Voz (STT/TTS) – Offline")

base = Path.cwd()
cfgp = base/"config"/"voice.json"
cfg = json.loads(cfgp.read_text(encoding="utf-8")) if cfgp.exists() else {"enabled":False}
st.json(cfg)
st.info("TTS offline usa pyttsx3; STT (voz → texto) Vosk pode ser ativado por plugin futuro.")