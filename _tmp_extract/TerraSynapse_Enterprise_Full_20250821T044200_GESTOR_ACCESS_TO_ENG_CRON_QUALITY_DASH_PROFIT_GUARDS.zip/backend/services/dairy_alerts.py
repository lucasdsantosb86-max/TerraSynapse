from .dairy_kpis import summarize

def check_alerts():
    k = summarize().get("kpis", {})
    alerts = []
    if k.get("rumination_avg_min") is not None and k["rumination_avg_min"] < 400:
        alerts.append({"type":"ruminacao_baixa","level":"alerta","msg":"Ruminação média baixa (<400 min/d). Verificar dieta/fibra/estresse térmico."})
    if k.get("ccs_avg") is not None and k["ccs_avg"] > 400000:
        alerts.append({"type":"mastite_ccs_alta","level":"alerta","msg":"CCS média alta (>400 mil). Investigar higiene/cama/ordenha."})
    return {"ok": True, "alerts": alerts}