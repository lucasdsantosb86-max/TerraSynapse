
from __future__ import annotations
import streamlit as st, json
from pathlib import Path
import streamlit.components.v1 as components
from frontend.security_policies import load_policy, client_ip, add_failed, clear_failed, locked, gen_captcha, hash_pw, verify_recaptcha
from frontend.audit import log_action

st.set_page_config(page_title="Login – TerraSynapse IA", page_icon="🔐", layout="centered")

USERS_PATH = Path("data/users/users.json")

def load_users():
    try:
        data = json.loads(USERS_PATH.read_text(encoding="utf-8"))
        return {u["username"]: u for u in data.get("users",[])}
    except Exception:
        return {}

st.title("🔐 TerraSynapse IA – Login")

pol = load_policy()
ip = client_ip()
users = load_users()

u = st.text_input("Usuário")
p = st.text_input("Senha", type="password")

captcha_needed = pol.get("auth",{}).get("captcha_enabled", False)
captcha_provider = pol.get("auth",{}).get("captcha_provider","math")

recaptcha_token = None
if captcha_needed and captcha_provider == "recaptcha":
    site_key = pol.get("auth",{}).get("recaptcha_site_key","")
    if site_key and site_key != "REPLACE_WITH_SITE_KEY":
        html = f"""
        <script src="https://www.google.com/recaptcha/api.js" async defer></script>
        <form id="rc" action="" method="POST">
          <div class="g-recaptcha" data-sitekey="{site_key}" data-callback="onToken"></div>
        </form>
        <script>
        function onToken(token){const iframe = window.parent; iframe.postMessage(token, "*");}
        </script>
        """
        components.html(html, height=120)
        # Capturar token via on_message
        token = st.text_input("Token reCAPTCHA (preenchido automaticamente em produção)", key="recaptcha_token")
        recaptcha_token = token
    else:
        st.info("reCAPTCHA não configurado. Usando Captcha matemático.")
        captcha_provider = "math"

if captcha_needed and captcha_provider == "math":
    cap = gen_captcha()
    st.session_state.setdefault("cap_q", cap["question"])
    st.session_state.setdefault("cap_a", cap["answer"])
    st.text(f"Captcha: {st.session_state['cap_q']}")
    cap_ans = st.text_input("Resposta do captcha", key="cap_ans")

# 2FA + backup
use_backup = st.checkbox("Usar código de backup para 2FA")
backup_code = st.text_input("Código de backup (se marcado)", max_chars=16) if use_backup else ""

if st.button("Entrar"):
    if locked(u, ip):
        st.error("Muitas tentativas falhas. IP/usuário temporariamente bloqueado."); st.stop()
    rec = users.get(u)
    if not rec or rec.get("password_hash") != hash_pw(p):
        add_failed(u, ip); st.error("Usuário ou senha inválidos."); log_action(u or "desconhecido", "login", "user", u or "-", {"result":"fail","ip":ip}); st.stop()
    # captcha
    if captcha_needed:
        if captcha_provider == "recaptcha":
            if not recaptcha_token or not verify_recaptcha(recaptcha_token):
                add_failed(u, ip); st.error("reCAPTCHA inválido ou ausente."); st.stop()
        else:
            if st.session_state.get("cap_ans","").strip() != st.session_state.get("cap_a"):
                add_failed(u, ip); st.error("Captcha incorreto."); st.stop()
    # expiração de senha
    exp = rec.get("pwd_expires_at")
    if exp:
        from datetime import datetime as _dt
        try:
            if _dt.utcnow() > _dt.fromisoformat(exp.replace("Z","")):
                st.error("Sua senha expirou. Use a página 'Trocar Senha'."); st.stop()
        except Exception:
            pass
    # 2FA — por papel
    role = rec.get("role","visitante")
    req_global = pol.get("auth",{}).get("require_2fa", False)
    req_roles = pol.get("auth",{}).get("require_2fa_roles", [])
    require_2fa = req_global or (role in req_roles)
    if require_2fa:
        if use_backup and backup_code.strip():
            from frontend.security_policies import consume_backup_code
            if not consume_backup_code(rec, backup_code.strip()):
                add_failed(u, ip); st.error("Código de backup inválido/uso anterior."); st.stop()
        else:
            code = st.text_input("Código 2FA (TOTP)", value="", max_chars=6)
            if not code:
                st.warning("Informe o código 2FA do seu autenticador ou use backup."); st.stop()
            else:
                from frontend.security_policies import verify_totp
                if not verify_totp(rec, code.strip()):
                    add_failed(u, ip); st.error("2FA inválido."); st.stop()
    # sucesso
    clear_failed(u, ip)
    from frontend.security_policies import add_session
    add_session(u, ip)
    log_action(u, "login", "user", u, {"result":"success","ip":ip})
    st.success("Login efetuado. (Abra o menu para navegar.)")
    # salvar user com alterações (ex.: backup consumido)
    try:
        data = {"users": list(users.values())}
        USERS_PATH.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    except Exception:
        pass
