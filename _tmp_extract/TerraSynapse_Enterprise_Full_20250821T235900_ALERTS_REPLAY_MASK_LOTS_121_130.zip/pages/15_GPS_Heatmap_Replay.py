import streamlit as st, pandas as pd, numpy as np, requests, os, io, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

st.set_page_config(page_title="GPS – Heatmap & Replay", page_icon="📍", layout="wide")
st.title("📍 GPS – Heatmap & Replay")

api = st.text_input("Backend URL", value=os.getenv("TS_BACKEND_URL","http://localhost:8000"))
up = st.file_uploader("Envie CSV (timestamp, lat, lon, ...)", type=["csv"])
tag = st.text_input("Tag (identificação)", "loteA")

col = st.columns(3)
if col[0].button("Ingerir CSV") and up:
    r = requests.post(f"{api}/ingest/gps", files={"file": (up.name, up.read(),"text/csv")}, data={"tag": tag})
    st.json(r.json())

if col[1].button("Métricas & Heatmap"):
    j = requests.get(f"{api}/ingest/gps/metrics", params={"tag":tag}).json()
    st.json(j)
    if j.get("ok") and j.get("heatmap"):
        st.image(f"{api.rstrip('/')}/{j['heatmap']}", caption="Heatmap GPS")

st.markdown("---")
st.subheader("▶️ Replay temporal")
csv = st.file_uploader("CSV local para replay (timestamp, lat, lon)", type=["csv"], key="replay")
if csv:
    df = pd.read_csv(csv).sort_values("timestamp")
    tmin, tmax = df["timestamp"].min(), df["timestamp"].max()
    t = st.slider("Tempo", int(tmin), int(tmax), int(tmin), step=max(1, int((tmax-tmin)/100)))
    sub = df[df["timestamp"]<=t]
    fig, ax = plt.subplots(figsize=(6,6))
    if not sub.empty:
        ax.plot(sub["lon"], sub["lat"], "-", linewidth=1)
        ax.plot([sub["lon"].iloc[-1]],[sub["lat"].iloc[-1]], "o")
    ax.set_title(f"Replay até {t}")
    ax.set_xlabel("lon"); ax.set_ylabel("lat")
    st.pyplot(fig)