import json
from pathlib import Path

BASE = Path(__file__).resolve().parents[2]
CONF = BASE/"config"/"weather.json"

def get_forecast(lat: float, lon: float):
    # Tenta ClimaTempo; se sem token, cai para Open‑Meteo
    cfg = json.loads(CONF.read_text(encoding="utf-8"))
    prov = (cfg.get("provider") or "climatempo").lower()
    token = cfg.get("climatempo",{}).get("token","")
    if prov == "climatempo" and token:
        from .weather_climatempo import forecast_by_coords
        return forecast_by_coords(lat, lon)
    # fallback
    from .weather_openmeteo import forecast_by_coords as om
    return om(lat, lon)