from fastapi import APIRouter, Body
from ..services.webhooks import list_hooks, add_hook, remove_hook, emit

router = APIRouter(prefix="/webhooks", tags=["webhooks"])

@router.get("")
def list_all():
    return list_hooks()

@router.post("")
def add(url: str = Body(...), event: str = Body(...)):
    return add_hook(url, event)

@router.delete("")
def delete(url: str = Body(...), event: str = Body(...)):
    return remove_hook(url, event)

@router.post("/emit")
def emit_event(event: str = Body(...), payload: dict = Body(default={})):
    return emit(event, payload)