TerraSynapse IA — Teste de Download
Se você conseguiu baixar este arquivo, o acesso ao sandbox está OK.
Em seguida baixe o ZIP completo com o nome único abaixo.
