import streamlit as st, os, requests, time

st.set_page_config(page_title="Chat TerraSynapse", page_icon="💬", layout="centered")
st.title("💬 TerraSynapse IA – Chat")

api = st.text_input("Backend URL", value=os.getenv("TS_BACKEND_URL","http://localhost:8000"))
auto_tts = st.checkbox("🔊 Ler resposta automaticamente (TTS)", True)

tab1, tab2 = st.tabs(["Chat por texto","🎤 Usar voz (upload WAV)"])

with tab1:
    q = st.text_area("Pergunte algo…", "")
    if st.button("Enviar"):
        # Aqui você pode integrar ao seu endpoint /chat/ask, se existente.
        # Por enquanto, respondemos com um placeholder de processamento local.
        resp = f"(demo) Resposta técnica para: {q[:120]}..."
        st.success(resp)
        if auto_tts:
            try:
                r = requests.post(f"{api}/voice/tts", data={"text": resp})
                j = r.json()
                if j.get("ok"):
                    st.audio(f"{api.rstrip('/')}/{j['out']}", format="audio/wav")
            except Exception as e:
                st.error(str(e))

with tab2:
    aud = st.file_uploader("Envie um .wav (16kHz mono)", type=["wav"])
    if st.button("Transcrever e enviar"):
        if aud:
            try:
                files = {"file": (aud.name, aud.read(), "audio/wav")}
                data = {"lang":"pt"}
                r = requests.post(f"{api}/voice/stt", files=files, data=data); j = r.json()
                st.info("Você disse: " + j.get("text","(sem texto)"))
                resp = f"(demo) Resposta técnica para: {j.get('text','')}"
                st.success(resp)
                if auto_tts:
                    r2 = requests.post(f"{api}/voice/tts", data={"text": resp}); j2 = r2.json()
                    if j2.get("ok"): st.audio(f"{api.rstrip('/')}/{j2['out']}", format="audio/wav")
            except Exception as e:
                st.error(str(e))