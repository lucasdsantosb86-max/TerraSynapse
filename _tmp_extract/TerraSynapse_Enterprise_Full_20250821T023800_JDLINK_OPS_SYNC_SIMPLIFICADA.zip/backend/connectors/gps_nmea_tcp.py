import socket, time

def test_connect(host: str, port: int, timeout=5):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(timeout)
    try:
        s.connect((host, int(port)))
        # não fica lendo infinito; apenas valida handshake
        s.sendall(b"TerraSynapse ping\n")
        s.close()
        return {"ok": True, "detail":"conexao_ok"}
    except Exception as e:
        return {"ok": False, "detail": str(e)}