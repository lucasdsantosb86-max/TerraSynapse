
from __future__ import annotations
from pathlib import Path
import json, datetime as dt, csv
from frontend.security_policies import hmac_sign

AUDIT_DIR = Path("data/audit"); AUDIT_DIR.mkdir(parents=True, exist_ok=True)
LOG = AUDIT_DIR/"audit_log.jsonl"
CSV = AUDIT_DIR/"audit_log.csv"

def log_action(actor: str, action: str, target_type: str, target_id: str, details: dict|None=None):
    payload = {
        "ts": dt.datetime.utcnow().isoformat()+"Z",
        "actor": actor,
        "action": action,
        "target_type": target_type,
        "target_id": target_id,
        "details": details or {}
    }
    # assinatura HMAC para integridade
    msg = json.dumps(payload, ensure_ascii=False, sort_keys=True)
    sig = hmac_sign(msg)
    rec = {"payload": payload, "sig": sig}
    with LOG.open("a", encoding="utf-8") as f:
        f.write(json.dumps(rec, ensure_ascii=False)+"\n")
    # CSV (flatten)
    hdr = ["ts","actor","action","target_type","target_id","details","sig"]
    new = not CSV.exists()
    with CSV.open("a", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        if new: w.writerow(hdr)
        w.writerow([payload["ts"], payload["actor"], payload["action"], payload["target_type"], payload["target_id"], json.dumps(payload["details"], ensure_ascii=False), sig])
