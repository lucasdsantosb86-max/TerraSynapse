from fastapi import APIRouter, Body
from ..services.roles_mapping import set_mapping

router = APIRouter(prefix="/auth/roles", tags=["auth-roles"])

@router.post("/mapping/set")
def set_(payload: dict = Body(...)):
    return set_mapping(payload)