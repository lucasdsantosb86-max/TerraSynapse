import streamlit as st, requests, os, json

st.set_page_config(page_title="Mapeamento de Papéis (SSO)", page_icon="🧭", layout="wide")
st.title("🧭 SSO – Mapeamento Automático de Papéis")

api = st.text_input("Backend URL", value=os.getenv("TS_BACKEND_URL","http://localhost:8000"))
user_id = st.text_input("Seu e-mail (para permissões)", "lucas@empresa.com")

# Guard
import requests as rq
role_api = api + "/auth/role"
_res = rq.get(role_api, params={"user_id": user_id}).json()
_user_role = (_res.get("role") or "visitante").lower()
_allowed = {"gestor","integrador","engenheiro"}
if _user_role not in _allowed:
    st.error(f"Acesso restrito. Seu papel: '{_user_role}'. Permitidos: {', '.join(_allowed)}")
    st.stop()

st.subheader("Definir regras de mapeamento")
sample = {
    "default": {"claim":"email","match":"@empresa.com","role":"gestor"},
    "providers": {
        "example-azure-ad": {"claim":"groups","contains":["Agro-Gestores"],"role":"gestor"}
    }
}
text = st.text_area("JSON de regras", value=json.dumps(sample, indent=2), height=220)
if st.button("Salvar regras"):
    try:
        payload = json.loads(text)
        st.json(requests.post(f"{api}/auth/roles/mapping/set", json=payload).json())
    except Exception as e:
        st.error(f"JSON inválido: {e}")