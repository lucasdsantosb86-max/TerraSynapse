import json, requests, pandas as pd, streamlit as st
from pathlib import Path

st.set_page_config(page_title="Custos – Sync", page_icon="💹")
st.title("💹 Custos – Sync (ERS / WorldBank / CONAB / IMEA)")

backend = st.text_input("Backend URL", value="http://localhost:8000")

st.subheader("Baixar planilhas oficiais")
col1, col2 = st.columns(2)

with col1:
    usda_url = st.text_input("USDA ERS (CSV/Excel)", value="")
    if st.button("Sync USDA"):
        try:
            r = requests.post(f"{backend}/costs/sync/usda", json={"url": usda_url}, timeout=60).json()
            st.success(r)
        except Exception as e:
            st.error(e)

with col2:
    conab_url = st.text_input("CONAB (Planilha/CSV)", value="")
    if st.button("Sync CONAB"):
        try:
            r = requests.post(f"{backend}/costs/sync/conab", json={"url": conab_url}, timeout=60).json()
            st.success(r)
        except Exception as e:
            st.error(e)

imea_url = st.text_input("IMEA (Excel/CSV – custo MT)", value="")
if st.button("Sync IMEA"):
    try:
        r = requests.post(f"{backend}/costs/sync/imea", json={"url": imea_url}, timeout=60).json()
        st.success(r)
    except Exception as e:
        st.error(e)

st.divider()
st.subheader("Arquivos baixados")
try:
    files = requests.get(f"{backend}/costs/files", timeout=10).json().get("files", [])
    st.write(files)
except Exception as e:
    st.error(e)

st.divider()
st.subheader("Normalizar custos (schema comum)")
st.caption("Use map_config para mapear colunas das planilhas para region/culture/metric/value/currency/date.")
map_cfg = st.text_area("map_config (JSON)", value="{}", height=200)
if st.button("Normalizar"):
    try:
        payload = {"map_config": json.loads(map_cfg or "{}")}
    except Exception as e:
        st.error(f"JSON inválido: {e}")
        payload = None
    if payload:
        try:
            r = requests.post(f"{backend}/costs/normalize", json=payload, timeout=60).json()
            st.success(r)
        except Exception as e:
            st.error(e)