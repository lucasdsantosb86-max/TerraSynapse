import streamlit as st, requests, json
st.set_page_config(page_title="Chat • RAG Turbo", page_icon="⚡")
st.title("⚡ Chat • RAG Turbo (pré‑rank por categoria)")
backend = st.text_input("Backend URL", value="http://localhost:8000")
cat = st.text_input("Categoria (ex.: soja, citros, equinos, custos, sensores_drones, all)", value="all")
q = st.text_input("Pergunta", value="melhor janela de semeadura por ZARC para soja")
if st.button("Buscar"):
    try:
        r = requests.post(f"{backend}/rag/search", json={"query": q, "category": cat, "top_k": 8}, timeout=30).json()
        st.json(r)
    except Exception as e:
        st.error(e)