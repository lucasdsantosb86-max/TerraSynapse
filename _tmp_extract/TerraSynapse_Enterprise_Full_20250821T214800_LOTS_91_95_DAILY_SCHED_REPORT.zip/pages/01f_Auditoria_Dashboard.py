
from __future__ import annotations
import streamlit as st, json, pandas as pd
from pathlib import Path
from frontend.auth import require

st.set_page_config(page_title="Auditoria – Dashboard", page_icon="📈", layout="wide")
user = require(roles=("developer","gestor"))

LOG = Path("data/audit/audit_log.jsonl")

st.title("📈 Auditoria – Dashboard")

if not LOG.exists():
    st.info("Sem dados de auditoria ainda."); st.stop()

recs = []
for line in LOG.read_text(encoding="utf-8").splitlines():
    if not line.strip(): continue
    rec = json.loads(line)
    pay = rec.get("payload", {})
    recs.append(pay)

df = pd.DataFrame(recs)
if df.empty:
    st.info("Sem dados.")
    st.stop()

df["ts"] = pd.to_datetime(df["ts"])
df["date"] = df["ts"].dt.date
colA, colB, colC = st.columns(3)
with colA: st.metric("Entradas totais", len(df))
with colB: st.metric("Usuários únicos", df["actor"].nunique())
with colC: st.metric("Tipos de ação", df["action"].nunique())

st.subheader("Ações por dia")
chart = df.groupby("date").size().reset_index(name="count")
st.line_chart(chart.set_index("date"))

st.subheader("Top ações")
st.bar_chart(df["action"].value_counts())

st.subheader("Top atores")
st.bar_chart(df["actor"].value_counts())
