from fastapi import APIRouter, Body
from ..services.emailer import set_smtp, send_email

router = APIRouter(prefix="/smtp", tags=["smtp"])

@router.post("/set")
def set_(cfg: dict = Body(...)):
    return set_smtp(cfg)

@router.post("/send")
def send(to: list = Body(...), subject: str = Body(...), text: str = Body(""), attachments: list = Body([])):
    return send_email(to, subject, text, attachments)