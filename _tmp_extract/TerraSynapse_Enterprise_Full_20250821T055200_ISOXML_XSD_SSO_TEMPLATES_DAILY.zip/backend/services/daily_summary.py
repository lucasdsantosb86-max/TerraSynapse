from pathlib import Path
import csv, time, json
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas

BASE = Path(__file__).resolve().parents[2]
AGG = BASE/"data"/"ingest"/"jdlink"/"aggregated"
OUT = BASE/"data"/"reports"
OUT.mkdir(parents=True, exist_ok=True)

def _latest_csv():
    files = sorted(AGG.glob("*.csv"))
    return files[-1] if files else None

def generate_summary():
    latest = _latest_csv()
    ts = time.strftime("%Y%m%d")
    csv_out = OUT/f"daily_summary_{ts}.csv"
    pdf_out = OUT/f"daily_summary_{ts}.pdf"

    # copy CSV lite (if exists)
    if latest:
        csv_out.write_bytes(latest.read_bytes())
    else:
        csv_out.write_text("no_data
", encoding="utf-8")

    # simple PDF
    c = canvas.Canvas(str(pdf_out), pagesize=A4)
    w,h = A4
    c.setFont("Helvetica-Bold", 14)
    c.drawString(40, h-40, "TerraSynapse – Resumo Diário")
    c.setFont("Helvetica", 11)
    c.drawString(40, h-60, f"Data: {time.strftime('%Y-%m-%d %H:%M:%S')}")
    c.drawString(40, h-80, f"CSV: {csv_out.name}")
    c.drawString(40, h-100, "Este é um resumo automático das últimas operações agregadas.")
    c.showPage(); c.save()
    return {"ok": True, "csv": str(csv_out.relative_to(BASE)), "pdf": str(pdf_out.relative_to(BASE))}