from pathlib import Path
import json, time, datetime as dt

BASE = Path(__file__).resolve().parents[2]
CONF = BASE/"config"/"alerts.json"
HEALTH = BASE/"data"/"health.json"
LOG = BASE/"data"/"alerts_log.jsonl"
HEALTH.parent.mkdir(parents=True, exist_ok=True)

def _load_cfg():
    return json.loads(CONF.read_text(encoding="utf-8"))

def _write_log(rec: dict):
    LOG.parent.mkdir(parents=True, exist_ok=True)
    with LOG.open("a", encoding="utf-8") as f:
        f.write(json.dumps(rec, ensure_ascii=False) + "\n")

def update_health(component: str, ok: bool):
    now = int(time.time())
    try:
        obj = json.loads(HEALTH.read_text(encoding="utf-8"))
    except Exception:
        obj = {}
    obj[component] = {"ok": ok, "ts": now}
    HEALTH.write_text(json.dumps(obj), encoding="utf-8")
    return {"ok": True}

def run_checks(forecast: dict=None):
    cfg = _load_cfg()
    rules = cfg.get("rules",{})
    results = []
    ts = dt.datetime.utcnow().isoformat()+"Z"

    # 1) Checagem clima (se previsão fornecida ou integrada externamente)
    if forecast and forecast.get("ok"):
        # Espera estrutura semelhante ao ClimaTempo: data para 7 dias com min/max/wind/rain
        days = forecast.get("data",{}).get("data") or forecast.get("data")
        if isinstance(days, list):
            for d in days[:3]:  # próximas 72h
                tmin = d.get("temperature",{}).get("min") or d.get("tmin") or d.get("min")
                wind = d.get("wind",{}).get("velocity_max") or d.get("wind_kmh")
                rain = d.get("rain",{}).get("precipitation") or d.get("rain_mm")
                if tmin is not None and tmin <= rules.get("frost_min_temp_c",2):
                    rec = {"ts": ts, "type":"alert_frost", "detail": f"Risco de geada: Tmin={tmin}°C"}
                    results.append(rec); _write_log(rec)
                if wind is not None and wind >= rules.get("wind_max_kmh",60):
                    rec = {"ts": ts, "type":"alert_wind", "detail": f"Vento forte: {wind} km/h"}
                    results.append(rec); _write_log(rec)
                if rain is not None and rain >= rules.get("rain_max_mm",80):
                    rec = {"ts": ts, "type":"alert_rain", "detail": f"Chuva intensa: {rain} mm"}
                    results.append(rec); _write_log(rec)

    # 2) Checagem desconexão (componentes sem heartbeat)
    try:
        health = json.loads(HEALTH.read_text(encoding="utf-8"))
    except Exception:
        health = {}
    now = int(time.time())
    for comp,info in health.items():
        if not info.get("ok"):
            rec = {"ts": ts, "type":"alert_disconnect", "detail": f"{comp} reportou falha"}
            results.append(rec); _write_log(rec)
        else:
            if now - int(info.get("ts",now)) > rules.get("disconnect_minutes",10)*60:
                rec = {"ts": ts, "type":"alert_disconnect", "detail": f"{comp} sem heartbeat há > {rules.get('disconnect_minutes')} min"}
                results.append(rec); _write_log(rec)

    return {"ok": True, "alerts": results}