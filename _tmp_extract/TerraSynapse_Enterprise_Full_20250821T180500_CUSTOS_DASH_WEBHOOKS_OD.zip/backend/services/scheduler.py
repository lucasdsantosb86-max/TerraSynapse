from apscheduler.schedulers.background import BackgroundScheduler
from datetime import datetime
from .cost_sync import fetch_usda_ers_costs, fetch_conab_planilha, fetch_imea, normalize_costs
from .webhooks import emit
from pathlib import Path
import json

def start_scheduler():
    cfg_path = Path(__file__).resolve().parents[2]/"data"/"costs"/"auto_links.json"
    sched = BackgroundScheduler(timezone="UTC")
    def job_sync():
        try:
            auto = json.loads(cfg_path.read_text(encoding="utf-8")) if cfg_path.exists() else {}
            # baixar alguns (se definidos)
            for it in auto.get("usda_ers", [])[:1]:
                fetch_usda_ers_costs(it["url"])
            for it in auto.get("conab", [])[:1]:
                fetch_conab_planilha(it["url"])
            for it in auto.get("imea", [])[:1]:
                fetch_imea(it["url"])
            normalize_costs({})
            emit("cost/sync", {"ts": datetime.utcnow().isoformat()})
        except Exception as e:
            emit("cost/sync_error", {"error": str(e)})
    sched.add_job(job_sync, "cron", hour=3, minute=0)  # diário 03:00 UTC
    sched.start()
    return sched