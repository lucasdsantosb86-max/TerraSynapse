from .crm_storage import list_all, get_by_id, create, update, delete
COL = "team"

def list_team(): return list_all(COL)
def get_member(mid: str): return get_by_id(COL, mid)
def create_member(obj: dict): return create(COL, obj)
def update_member(mid: str, patch: dict): return update(COL, mid, patch)
def delete_member(mid: str): return delete(COL, mid)