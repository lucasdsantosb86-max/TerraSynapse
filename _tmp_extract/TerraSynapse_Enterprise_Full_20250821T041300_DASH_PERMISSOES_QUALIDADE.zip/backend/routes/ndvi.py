from fastapi import APIRouter, UploadFile, File, Form
from ..services.ndvi_geotiff import compute_ndvi_geotiff
from pathlib import Path
import time

router = APIRouter(prefix="/ndvi", tags=["ndvi"])

@router.post("/geotiff/summary")
async def ndvi_summary(file: UploadFile = File(...), red_band: int = Form(None), nir_band: int = Form(None)):
    tmp = Path("data/geo")/f"ndvi_{int(time.time())}.tif"
    tmp.parent.mkdir(parents=True, exist_ok=True)
    with open(tmp, "wb") as f:
        f.write(await file.read())
    red = int(red_band) if red_band not in (None, "") else None
    nir = int(nir_band) if nir_band not in (None, "") else None
    return compute_ndvi_geotiff(str(tmp), red, nir)