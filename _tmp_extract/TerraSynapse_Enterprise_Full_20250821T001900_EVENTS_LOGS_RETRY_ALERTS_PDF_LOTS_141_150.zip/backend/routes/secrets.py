from fastapi import APIRouter, Body
from ..services.secrets import set_secret, get_secret, masked, list_providers

router = APIRouter(prefix="/secrets", tags=["secrets"])

@router.post("/set")
def set(provider: str = Body(...), key: str = Body(...), value: str = Body(...)):
    set_secret(provider, key, value)
    return {"ok": True}

@router.get("/masked")
def view(provider: str):
    return {"ok": True, "provider": provider, "keys": masked(provider)}

@router.get("/providers")
def providers():
    return {"ok": True, "providers": list_providers()}