from pathlib import Path
import json
BASE = Path(__file__).resolve().parents[2]
ROLES = BASE/"config"/"users_roles.json"
PERMS = BASE/"config"/"permissions.json"

def get_role(user_id: str) -> str:
    try:
        m = json.loads(ROLES.read_text(encoding="utf-8"))
        return (m.get(user_id) or "visitante").lower()
    except Exception:
        return "visitante"

def set_role(user_id: str, role: str):
    try:
        m = json.loads(ROLES.read_text(encoding="utf-8"))
    except Exception:
        m = {}
    m[user_id] = role.lower()
    ROLES.write_text(json.dumps(m, indent=2, ensure_ascii=False), encoding="utf-8")
    return {"ok": True, "user_id": user_id, "role": role.lower()}

def allowed_for_sync(role: str) -> bool:
    try:
        p = json.loads(PERMS.read_text(encoding="utf-8"))
        allowed = [r.lower() for r in p.get("sync_roles_allowed",[])]
        return role.lower() in allowed
    except Exception:
        return role.lower() in ["gestor","integrador"]