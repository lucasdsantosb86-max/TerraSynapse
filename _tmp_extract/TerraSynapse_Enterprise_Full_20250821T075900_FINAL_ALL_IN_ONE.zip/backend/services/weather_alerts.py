import json, math
from pathlib import Path
from typing import List, Dict
from .weather import WeatherProvider
from .webhooks import send_event

BASE = Path(__file__).resolve().parents[2]
CONF = BASE/"config"/"weather_alerts.json"

def _load_conf():
    return json.loads(CONF.read_text(encoding="utf-8"))

def _kmh(ms): return ms*3.6

def analyze_forecast(forecast: dict, geada_c: float, vento_kmh: float, hail_kw: str, lookahead_h: int = 48):
    alerts = []
    if not forecast or "list" not in forecast:
        return alerts
    for item in forecast.get("list", []):
        # OpenWeather 3h step
        # temperature
        main = item.get("main", {})
        temp_min = main.get("temp_min", None)
        wind_ms = (item.get("wind") or {}).get("speed", 0.0)
        desc = " ".join([w.get("description","") for w in item.get("weather", [])]).lower()
        # time horizon: assume <= lookahead_h
        if temp_min is not None and temp_min <= geada_c:
            alerts.append({"kind":"geada","temp_min": temp_min, "dt": item.get("dt")})
        if _kmh(wind_ms) >= vento_kmh:
            alerts.append({"kind":"vento","wind_kmh": round(_kmh(wind_ms),1), "dt": item.get("dt")})
        if hail_kw and hail_kw.lower() in desc:
            alerts.append({"kind":"granizo","desc": desc, "dt": item.get("dt")})
    return alerts

def check_and_emit(lat: float, lon: float, provider: str = None):
    cfg = _load_conf()
    provider = provider or cfg.get("provider","openweather")
    geada_c = float(cfg.get("geada_temp_c", 2.0))
    vento_kmh = float(cfg.get("vento_kmh", 50))
    hail_kw = str(cfg.get("granizo_keyword","hail"))
    lookahead_h = int(cfg.get("lookahead_hours",48))

    W = WeatherProvider(provider)
    fc = W.forecast(lat, lon)
    alerts = analyze_forecast(fc, geada_c, vento_kmh, hail_kw, lookahead_h)

    fired = []
    for a in alerts:
        ev = {"type":"weather_alert","provider":provider,"lat":lat,"lon":lon, **a}
        send_event(ev)
        fired.append(ev)
    return {"ok": True, "found": alerts, "sent": fired}