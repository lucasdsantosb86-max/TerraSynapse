from reportlab.lib.pagesizes import A4, landscape
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib import colors
from io import BytesIO
from pathlib import Path
import pandas as pd

def gerar_pdf_financeiro(periodo: str, talhoes_csv: str, limiares: dict, out_path: str):
    df = pd.read_csv(talhoes_csv)
    # agrega por mês e talhão
    if "mes" not in df.columns:
        df["mes"] = periodo
    rows = [["Talhão","Cultura","Mês","R$/ha","Limiar","Status"]]
    for _, r in df.iterrows():
        lim = limiares.get(str(r["cultura"]).lower(), 0.0)
        status = "OK" if r["custo_R$_ha"]<=lim else "ACIMA"
        rows.append([r.get("talhao","?"), r.get("cultura","?"),
                     r.get("mes"), f"{r.get('custo_R$_ha',0):.2f}", f"{lim:.2f}", status])
    buf = BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=landscape(A4))
    styles = getSampleStyleSheet()
    story = [Paragraph("Relatório Financeiro – Semáforo Mensal (TerraSynapse)", styles["Title"]), Spacer(1,12)]
    t = Table(rows, repeatRows=1)
    t.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0), colors.HexColor("#2E7D32")),
                           ("TEXTCOLOR",(0,0),(-1,0), colors.white),
                           ("GRID",(0,0),(-1,-1), 0.25, colors.grey),
                           ("ROWBACKGROUNDS",(0,1),(-1,-1), [colors.whitesmoke, colors.HexColor("#E3F2FD")])]))
    story.append(t)
    doc.build(story)
    Path(out_path).write_bytes(buf.getvalue())
    return {"ok": True, "file": out_path}