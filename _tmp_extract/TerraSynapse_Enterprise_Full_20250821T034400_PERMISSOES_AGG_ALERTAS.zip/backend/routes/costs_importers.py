from fastapi import APIRouter, Body
from ..services.costs_importers import import_imea, import_conab, import_usda, import_eurostat
router = APIRouter(prefix="/costs/importers", tags=["costs"])

@router.post("/imea")
def run_imea(url: str = Body(...)):
    return import_imea(url)

@router.post("/conab")
def run_conab(url: str = Body(...)):
    return import_conab(url)

@router.post("/usda")
def run_usda(url: str = Body(...)):
    return import_usda(url)

@router.post("/eurostat")
def run_eurostat(url: str = Body(...)):
    return import_eurostat(url)