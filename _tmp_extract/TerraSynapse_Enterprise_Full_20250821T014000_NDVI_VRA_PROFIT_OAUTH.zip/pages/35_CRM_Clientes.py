import streamlit as st, requests, os, time

st.set_page_config(page_title="CRM – Clientes", page_icon="👥", layout="wide")
st.title("👥 CRM – Clientes")

api = st.text_input("Backend URL", value=os.getenv("TS_BACKEND_URL","http://localhost:8000"))

st.subheader("Cadastrar novo cliente")
with st.form("new_client"):
    name = st.text_input("Nome/Razão Social")
    doc  = st.text_input("Documento (CPF/CNPJ)")
    contato = st.text_input("Contato principal (nome)")
    email = st.text_input("E-mail")
    phone = st.text_input("Telefone/WhatsApp")
    cidade = st.text_input("Cidade")
    uf = st.text_input("UF/Estado")
    lat = st.text_input("Latitude", "")
    lon = st.text_input("Longitude", "")
    segmentos = st.multiselect("Segmentos", ["soja","milho","cana","café","trigo","algodão","arroz","citros","amendoim","bovinos_leite","bovinos_corte","suínos","aves","equinos","piscicultura"])
    area = st.number_input("Área (ha)", 0.0, 1e7, 0.0)
    herd = st.text_input("Rebanho (descrição)", "")
    notes = st.text_area("Observações")
    submitted = st.form_submit_button("Salvar cliente")
    if submitted:
        obj = {"name": name, "doc": doc, "contact": {"name": contato,"email":email,"phone":phone}, "location":{"city":cidade,"state":uf,"lat":lat,"lon":lon}, "segments": segmentos, "area_ha": area, "herd": herd, "notes": notes}
        r = requests.post(f"{api}/crm/clients", json=obj).json()
        st.success("Cliente salvo!"); st.json(r)

st.markdown("---")
st.subheader("Lista de clientes")
if st.button("Atualizar lista"):
    st.session_state.clients = requests.get(f"{api}/crm/clients").json().get("items",[])
cl = st.session_state.get("clients", [])
for c in cl:
    with st.expander(c.get("name","(sem nome)")):
        st.write(c)
        if st.button(f"Excluir {c.get('id')}", key=c["id"]):
            st.json(requests.delete(f"{api}/crm/clients/{c['id']}").json())
            time.sleep(0.2)