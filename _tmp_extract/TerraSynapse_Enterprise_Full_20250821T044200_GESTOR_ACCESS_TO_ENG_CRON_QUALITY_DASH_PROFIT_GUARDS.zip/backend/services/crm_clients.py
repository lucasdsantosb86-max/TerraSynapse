from .crm_storage import list_all, get_by_id, create, update, delete

COL = "clients"

def list_clients(): return list_all(COL)
def get_client(cid: str): return get_by_id(COL, cid)
def create_client(obj: dict): return create(COL, obj)
def update_client(cid: str, patch: dict): return update(COL, cid, patch)
def delete_client(cid: str): return delete(COL, cid)