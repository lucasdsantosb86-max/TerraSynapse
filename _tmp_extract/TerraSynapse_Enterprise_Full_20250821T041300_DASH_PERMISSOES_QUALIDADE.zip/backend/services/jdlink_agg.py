from pathlib import Path
import json, time
import pandas as pd

BASE = Path(__file__).resolve().parents[2]
OPS  = BASE/"data"/"ingest"/"jdlink"/"operations"
OUTD = BASE/"data"/"ingest"/"jdlink"/"aggregated"
OUTD.mkdir(parents=True, exist_ok=True)

def _iter_ops():
    for fp in sorted(OPS.glob("*.json")):
        try:
            doc = json.loads(fp.read_text(encoding="utf-8"))
            for it in doc.get("items", []):
                yield it
        except:
            pass

def aggregate():
    rows = []
    for it in _iter_ops():
        start = it.get("start_ts") or 0
        end   = it.get("end_ts") or start
        dur_h = max(0.0, (end - start) / 3600.0)
        area  = float(it.get("area_ha") or 0.0)
        fuel  = float(it.get("fuel_l") or 0.0)
        prod  = (area / dur_h) if dur_h > 0 else None
        fph   = (fuel / dur_h) if dur_h > 0 else None
        fpha  = (fuel / area) if area > 0 else None
        rows.append({
            "op_id": it.get("op_id"),
            "machine_id": it.get("machine_id"),
            "task": it.get("task"),
            "start_ts": start,
            "end_ts": end,
            "dur_h": dur_h,
            "area_ha": area,
            "ha_h": prod,
            "fuel_l": fuel,
            "fuel_l_h": fph,
            "fuel_l_ha": fpha,
        })
    if not rows:
        return {"ok": True, "count": 0}
    df = pd.DataFrame(rows)
    ts = int(time.time())
    csvp = OUTD/f"ops_agg_{ts}.csv"
    parp = OUTD/f"ops_agg_{ts}.parquet"
    df.to_csv(csvp, index=False, encoding="utf-8")
    try:
        df.to_parquet(parp, index=False)
        parq = parp.name
    except Exception:
        parq = None
    return {"ok": True, "count": len(df), "csv": str(csvp.relative_to(BASE)), "parquet": str(parp.relative_to(BASE)) if parq else None}