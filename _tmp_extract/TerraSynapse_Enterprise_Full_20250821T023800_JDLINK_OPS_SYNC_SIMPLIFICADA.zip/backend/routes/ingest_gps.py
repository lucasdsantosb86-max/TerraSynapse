from fastapi import APIRouter, UploadFile, File, Form
from pathlib import Path
import pandas as pd, json, io, time
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

BASE = Path(__file__).resolve().parents[2]
INGE = BASE/"data"/"ingest"/"gps"
PUB  = BASE/"data"/"public"
INGE.mkdir(parents=True, exist_ok=True)
PUB.mkdir(parents=True, exist_ok=True)

router = APIRouter(prefix="/ingest/gps", tags=["ingest-gps"])

@router.post("")
def upload(file: UploadFile = File(...), tag: str = Form("default")):
    p = INGE/f"{int(time.time())}_{tag}.csv"
    p.write_bytes(file.file.read())
    return {"ok": True, "path": str(p.relative_to(BASE))}

@router.get("/metrics")
def metrics(tag: str):
    files = sorted(INGE.glob(f"*_{tag}.csv"))
    if not files:
        return {"ok": False, "error":"not_found"}
    fp = files[-1]
    df = pd.read_csv(fp)
    # cálculo simples de distância (não esférico, estimativa)
    import numpy as np
    lon, lat = np.radians(df["lon"].values), np.radians(df["lat"].values)
    d = np.sqrt(np.diff(lon,prepend=lon[0])**2 + np.diff(lat,prepend=lat[0])**2)*6371  # approx km
    km_total = float(np.nansum(d))
    # heatmap (densidade simples)
    fig, ax = plt.subplots(figsize=(4,4))
    ax.hexbin(df["lon"], df["lat"], gridsize=30)
    ax.set_title(f"Heatmap {tag}"); ax.set_xlabel("lon"); ax.set_ylabel("lat")
    out = PUB/f"heatmap_{tag}.png"; fig.savefig(out, dpi=120); plt.close(fig)
    return {"ok": True, "km_total": km_total, "points": len(df), "heatmap": f"{out.relative_to(BASE)}"}