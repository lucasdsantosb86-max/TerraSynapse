from fastapi import APIRouter, Query
from ..services.weather_climatempo import forecast_by_coords

router = APIRouter(prefix="/weather/climatempo", tags=["weather"])

@router.get("/forecast")
def fc(lat: float = Query(...), lon: float = Query(...)):
    return forecast_by_coords(lat, lon)