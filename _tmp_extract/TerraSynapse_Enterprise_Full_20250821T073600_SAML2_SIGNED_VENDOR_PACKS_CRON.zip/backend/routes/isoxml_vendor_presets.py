from fastapi import APIRouter, Body
from ..services.isoxml_vendor_full import list_presets, make_vendor_xml

router = APIRouter(prefix="/isoxml/presets", tags=["isoxml-presets"])

@router.get("/list")
def list_():
    return {"ok": True, "presets": list_presets()}

@router.post("/export")
def export(preset: str = Body(...), job_name: str = Body(...), culture: str = Body(...), zones: list = Body(...),
           asap: str = Body(""), grd: str = Body(""), pln: str = Body("")):
    xml = make_vendor_xml(preset, job_name, culture, zones, asap, grd, pln)
    return {"ok": True, "xml": xml}