from pathlib import Path
from lxml import etree
import json

BASE = Path(__file__).resolve().parents[2]
DIR_SINGLE  = BASE/"config"/"vendor_xsd"         # XSD único (legado)
DIR_PACKS   = BASE/"config"/"vendor_xsd_packs"   # múltiplos XSDs + entrypoint
DIR_SINGLE.mkdir(parents=True, exist_ok=True)
DIR_PACKS.mkdir(parents=True, exist_ok=True)

def list_vendors():
    singles = [p.stem for p in DIR_SINGLE.glob("*.xsd")]
    packs = [p.name for p in DIR_PACKS.glob("*") if p.is_dir()]
    return {"single": singles, "packs": packs}

def set_vendor_xsd(vendor: str, xsd_text: str):
    fp = DIR_SINGLE/f"{vendor}.xsd"
    fp.write_text(xsd_text, encoding="utf-8")
    return {"ok": True, "path": str(fp.relative_to(BASE)), "type":"single"}

def set_vendor_xsd_pack(vendor: str, files: dict, entrypoint: str):
    dest = DIR_PACKS/vendor
    dest.mkdir(parents=True, exist_ok=True)
    for name, content in (files or {}).items():
        (dest/name).write_text(content, encoding="utf-8")
    (dest/"_entrypoint.txt").write_text(entrypoint, encoding="utf-8")
    return {"ok": True, "path": str(dest.relative_to(BASE)), "entrypoint": entrypoint, "type":"pack"}

def validate_with_vendor(vendor: str, xml_text: str):
    # tenta pack; se não houver, tenta single
    pack = DIR_PACKS/vendor
    if pack.exists():
        entry = (pack/"_entrypoint.txt").read_text(encoding="utf-8").strip()
        main_xsd = pack/entry
        if not main_xsd.exists():
            return {"ok": False, "error":"entrypoint_not_found"}
        schema = etree.XMLSchema(etree.parse(str(main_xsd)))
        parser = etree.XMLParser(remove_blank_text=True)
        xml_doc = etree.fromstring(xml_text.encode("utf-8"), parser)
        ok = schema.validate(xml_doc)
        return {"ok": bool(ok), "errors": [str(e) for e in schema.error_log]}
    # fallback single
    single = DIR_SINGLE/f"{vendor}.xsd"
    if not single.exists():
        return {"ok": False, "error":"vendor_xsd_not_found"}
    parser = etree.XMLParser(remove_blank_text=True)
    xml_doc = etree.fromstring(xml_text.encode("utf-8"), parser)
    schema = etree.XMLSchema(etree.parse(str(single)))
    ok = schema.validate(xml_doc)
    return {"ok": bool(ok), "errors": [str(e) for e in schema.error_log]}