from fastapi import APIRouter
from ..services.dairy_alerts import check_alerts

router = APIRouter(prefix="/dairy", tags=["dairy-alerts"])

@router.get("/alerts/check")
def check():
    return check_alerts()