import streamlit as st, requests, os, json

st.set_page_config(page_title="Prescrição VRA", page_icon="🧭", layout="wide")
st.title("🧭 Prescrição VRA (SHP/CSV/ISOXML)")

api = st.text_input("Backend URL", value=os.getenv("TS_BACKEND_URL","http://localhost:8000"))

name = st.text_input("Nome da prescrição", "talhao_vra")
fmt  = st.selectbox("Formato", ["csv","shp","isoxml"])

st.subheader("Zonas e taxas")
zones_raw = st.text_area("JSON de zonas (ex.: [{"zone_id":1,"rate":160,"unit":"kg_ha"}])", "[{"zone_id":1,"rate":160,"unit":"kg_ha"},{"zone_id":2,"rate":120,"unit":"kg_ha"}]")

polys_raw = st.text_area("Polígonos (opcional, SHP) – GeoJSON-like simplificado", "[{"zone_id":1,"rate":160,"coords":[[-47.1,-22.1],[-47.0,-22.1],[-47.0,-22.0],[-47.1,-22.0],[-47.1,-22.1]]}]")

if st.button("Gerar"):
    try:
        payload = {"name": name, "format": fmt, "zones": json.loads(zones_raw)}
        if fmt == "shp":
            payload["polygons"] = json.loads(polys_raw)
        j = requests.post(f"{api}/vra/generate", json=payload).json()
        st.json(j)
        if j.get("ok"):
            st.success("Gerado com sucesso")
            st.markdown(f"[Baixar arquivo]({api.rstrip('/')}/{j['path']})")
    except Exception as e:
        st.error(str(e))