from pathlib import Path
import os
from .pdf_sign import sign_pdf

def autosign_if_possible(pdf_path: str) -> str:
    p12 = Path("config/keys/cert.p12")
    if p12.exists() and os.environ.get("TS_P12_PASS"):
        out = str(Path(pdf_path).with_name(Path(pdf_path).stem + "_signed.pdf"))
        sign_pdf(pdf_path, out, str(p12), os.environ["TS_P12_PASS"])
        return out
    return pdf_path