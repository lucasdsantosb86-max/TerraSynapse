
from __future__ import annotations
from fastapi import FastAPI
from .services.security_mw import RateLimitMiddleware, UploadFile, File, Form
from typing import Optional
import json
from backend.services import gps as gpssvc
from backend.services import alerts as alertsvc
from backend.services import aerial as aerialsvc
app = FastAPI(title="TerraSynapse IA – Backend")
@app.get("/health/ping")
def ping(): return {"ok": True}
@app.post("/ingest/gps")
async def ingest_gps(payload: Optional[str]=Form(None), file: Optional[UploadFile]=File(None)):
    if file is not None:
        content = (await file.read()).decode("utf-8", errors="ignore")
        ok = True
        for line in content.splitlines():
            line = line.strip()
            if not line: continue
            if line.startswith("$"): ok = gpssvc.ingest(line) and ok
            else:
                try: ok = gpssvc.ingest(json.loads(line)) and ok
                except Exception: pass
        return {"ok": ok}
    elif payload:
        try:
            data = json.loads(payload); ok = gpssvc.ingest(data); return {"ok": ok}
        except Exception:
            ok = gpssvc.ingest(payload); return {"ok": ok}
    return {"ok": False}
@app.get("/gps/metrics")
def gps_metrics(date: Optional[str]=None): return gpssvc.get_daily_metrics(date)
@app.post("/alerts/apply")
async def alerts_apply(payload: str = Form(...)):
    rows = json.loads(payload); out = alertsvc.apply_sensor_rules(rows); return {"alerts": out}
@app.post("/alerts/heartbeat")
async def alerts_heartbeat(ping_ok: bool = Form(True)):
    rec = alertsvc.check_connectivity(ping_ok); return {"recorded": rec is not None}
@app.post("/vision/aerial/geotiff")
async def vision_aerial_geotiff(file: UploadFile = File(...), cultura: str="soja", spacing_m: float=10.0):
    data = await file.read()
    import tempfile
    with tempfile.NamedTemporaryFile(suffix=".tif", delete=True) as tmp:
        tmp.write(data); tmp.flush()
        res = aerialsvc.analyze_geotiff(tmp.name, cultura=cultura, spacing_m=spacing_m)
    return res


from backend.services import knowledge as knsvc

@app.get("/knowledge/list")
def knowledge_list(): 
    return knsvc.list_sources()

@app.post("/knowledge/ingest_all")
def knowledge_ingest_all():
    return knsvc.ingest_all()

from .routes.security_tools import router as security_tools_router
app.include_router(security_tools_router)

from .routes.costs_seeds import router as costs_seeds_router
app.include_router(costs_seeds_router)

from .routes.benchmarks import router as benchmarks_router
app.include_router(benchmarks_router)

from .routes.auth import router as auth_router
app.include_router(auth_router)

from .routes.reports_visual import router as reports_visual_router
app.include_router(reports_visual_router)

from .routes.totp_recovery import router as totp_recovery_router
app.include_router(totp_recovery_router)

from .routes.costs_importers import router as costs_importers_router
app.include_router(costs_importers_router)
