from fastapi import APIRouter, Body, Query
from ..services.crm_comms import list_comms, create_comm, list_by_client

router = APIRouter(prefix="/crm/comms", tags=["crm-comms"])

@router.get("")
def all(client_id: str = Query(None)):
    if client_id:
        return {"ok": True, "items": list_by_client(client_id)}
    return {"ok": True, "items": list_comms()}

@router.post("")
def create(obj: dict = Body(...)):
    return {"ok": True, "item": create_comm(obj)}