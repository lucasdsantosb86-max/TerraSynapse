import streamlit as st, requests, os, json

st.set_page_config(page_title="SSO – SAML (dev stub)", page_icon="🛡️", layout="wide")
st.title("🛡️ SSO – SAML (dev stub)")

api = st.text_input("Backend URL", value=os.getenv("TS_BACKEND_URL","http://localhost:8000"))
user_id = st.text_input("Seu e-mail (para permissões)", "lucas@empresa.com")

# Guard
import requests as rq
role_api = api + "/auth/role"
_res = rq.get(role_api, params={"user_id": user_id}).json()
_user_role = (_res.get("role") or "visitante").lower()
_allowed = {"gestor","integrador","engenheiro"}
if _user_role not in _allowed:
    st.error(f"Acesso restrito. Seu papel: '{_user_role}'. Permitidos: {', '.join(_allowed)}")
    st.stop()

st.subheader("Provedores SAML")
st.json(requests.get(f"{api}/sso/saml/providers").json())

st.subheader("Definir provedores (JSON)")
cfg = st.text_area("providers.json", value=json.dumps({"providers":[{"name":"example-saml","sso_url":"","entity_id":"","x509_cert":"","acs_url":"http://localhost:8000/sso/saml/acs"}]}, indent=2), height=200)
if st.button("Salvar"):
    try:
        st.json(requests.post(f"{api}/sso/saml/providers/set", json=json.loads(cfg)).json())
    except Exception as e:
        st.error(f"JSON inválido: {e}")

st.subheader("Iniciar login")
prov = st.text_input("Provider", "example-saml")
if st.button("Gerar URL de login"):
    st.json(requests.get(f"{api}/sso/saml/start", params={"provider": prov, "user_id": user_id}).json())