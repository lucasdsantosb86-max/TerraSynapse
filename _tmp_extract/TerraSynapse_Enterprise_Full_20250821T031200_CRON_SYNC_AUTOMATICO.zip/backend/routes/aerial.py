from fastapi import APIRouter, UploadFile, File, Form
from typing import Optional
import numpy as np
from ..geo.ndvi_segment import ndvi_from_bands, ndvi_proxy_from_rgb, segment_ndvi, area_ha_from_mask

router = APIRouter(prefix="/vision/aerial", tags=["aerial"])

@router.post("/analyze")
async def analyze_aerial(cultura: str = Form("soja"), pixel_area_m2: float = Form(0.25), threshold: float = Form(0.30), 
                         red_band: Optional[UploadFile] = File(None), nir_band: Optional[UploadFile] = File(None), rgb_image: Optional[UploadFile] = File(None)):
    # Este endpoint aceita: (1) RED+NIR (arrays .npy) ou (2) uma imagem RGB (proxy)
    if red_band and nir_band:
        red = np.load(await red_band.read())
        nir = np.load(await nir_band.read())
        ndvi = ndvi_from_bands(red, nir)
    elif rgb_image:
        import io, PIL.Image as Image
        im = Image.open(io.BytesIO(await rgb_image.read())).convert("RGB")
        ndvi = ndvi_proxy_from_rgb(np.array(im))
    else:
        return {"ok": False, "detail": "Envie RED+NIR (.npy) ou uma imagem RGB."}

    mask = segment_ndvi(ndvi, threshold=threshold)
    area_ha = area_ha_from_mask(mask, pixel_area_m2=pixel_area_m2)
    return {"ok": True, "cultura": cultura, "area_ha": round(area_ha, 4), "threshold": threshold, "pixel_area_m2": pixel_area_m2}