import numpy as np, cv2, onnxruntime as ort
from pathlib import Path

LABELS = [
    "mastite","lesao_teto","pododermatite","laminite","fissura_casco",
    "conjuntivite","ectima","miíase","dermatite","ferida_necrotica"
]

MODEL_PATH = Path(__file__).resolve().parents[1]/"models"/"onnx"/"animal_lesions_v2.onnx"

def load_model():
    if MODEL_PATH.exists():
        return ort.InferenceSession(str(MODEL_PATH), providers=["CPUExecutionProvider"])
    return None

def preprocess(img):
    # redimensiona para 320x320, normaliza 0..1
    im = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    im = cv2.resize(im, (320,320)).astype("float32")/255.0
    im = np.transpose(im, (2,0,1))[None, ...]
    return im

def postprocess(out):
    # suposição: [1, N, (cls, score, x1,y1,x2,y2)] ou similar. Simplificado aqui.
    # Sem formato fixo, apenas retorna score máximo por classe se disponível.
    return {}

def analyze(image_bgr, threshold=0.6):
    sess = load_model()
    if sess is None:
        # Fallback: sem modelo, retorna vazio com aviso
        return {"ok": False, "detail": "Modelo animal_lesions_v2.onnx não encontrado. Envie modelo para backend/models/onnx/."}
    inp = preprocess(image_bgr)
    out = sess.run(None, {sess.get_inputs()[0].name: inp})
    # Aqui deveria decodificar deteções; por simplicidade, sinaliza execução
    return {"ok": True, "detail": "Modelo ONNX v2 executado", "labels_supported": LABELS}