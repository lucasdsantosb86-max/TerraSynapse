from fastapi import APIRouter, UploadFile, File, Form
from ..services.gps_ingest import ingest_csv, metrics
from pathlib import Path
import time

router = APIRouter(prefix="/ingest/gps", tags=["gps"])

@router.post("")
async def ingest(file: UploadFile = File(...), tag: str = Form("default")):
    tmp = Path("data/gps")/f"in_{int(time.time())}.csv"
    with open(tmp, "wb") as f: f.write(await file.read())
    return ingest_csv(str(tmp), tag)

@router.get("/metrics")
def m(tag: str = None):
    return metrics(tag)