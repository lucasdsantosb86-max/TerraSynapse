from fastapi import APIRouter, Body
from ..services.summaries_scheduler import set_schedules, tick

router = APIRouter(prefix="/summaries", tags=["summaries"])

@router.post("/set")
def set_(payload: dict = Body(...)):
    return set_schedules(payload)

@router.post("/tick")
def tick_():
    return tick()