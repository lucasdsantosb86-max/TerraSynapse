import time, json, base64, hmac, hashlib, os
from typing import Dict
from fastapi import Request, HTTPException
from starlette.middleware.base import BaseHTTPMiddleware
from pathlib import Path

BASE = Path(__file__).resolve().parents[2]
CONF = BASE/"config"/"security.json"
AUD  = BASE/"data"/"audit"
AUD.mkdir(parents=True, exist_ok=True)
CHAIN = AUD/"chain.log"

def _conf():
    return json.loads(CONF.read_text(encoding="utf-8"))

def _hmac_key():
    b64 = os.getenv(_conf()["audit"]["hmac_env"], "")
    return base64.b64decode(b64) if b64 else b""

def _append_chain(entry: Dict):
    line = json.dumps(entry, ensure_ascii=False).encode()
    prev = b""
    if CHAIN.exists():
        prev = bytes.fromhex(CHAIN.read_text(encoding="utf-8").splitlines()[-1].split(" ")[0])
    h = hashlib.sha256(prev + line).hexdigest()
    with CHAIN.open("a", encoding="utf-8") as f:
        f.write(f"{h} {line.decode()}
")

class RateLimitMiddleware(BaseHTTPMiddleware):
    def __init__(self, app, window_sec=60, max_calls=120):
        super().__init__(app)
        self.window = window_sec; self.max = max_calls
        self.store = {}

    async def dispatch(self, request: Request, call_next):
        ip = request.client.host if request.client else "local"
        now = int(time.time())
        bucket = self.store.get(ip, {"t": now, "c": 0})
        if now - bucket["t"] >= self.window:
            bucket = {"t": now, "c": 0}
        bucket["c"] += 1; self.store[ip] = bucket
        if bucket["c"] > self.max:
            raise HTTPException(status_code=429, detail="Rate limit exceeded")
        # Audit (resumo do request)
        ent = {"ts": now, "ip": ip, "path": str(request.url.path)}
        _append_chain(ent)
        return await call_next(request)