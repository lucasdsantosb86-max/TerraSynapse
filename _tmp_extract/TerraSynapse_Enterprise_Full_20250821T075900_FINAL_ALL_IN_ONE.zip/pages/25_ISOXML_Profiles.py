import streamlit as st, requests, os, json

st.set_page_config(page_title="Prescrição ISOXML", page_icon="🗂️", layout="wide")
st.title("🗂️ Prescrição ISOXML – Perfis & Validação")

api = st.text_input("Backend URL", value=os.getenv("TS_BACKEND_URL","http://localhost:8000"))
user_id = st.text_input("Seu e-mail (para permissões)", "lucas@empresa.com")

st.subheader("Perfis disponíveis")
try:
    prof = requests.get(f"{api}/isoxml/profiles").json()
    st.json(prof)
except Exception as e:
    st.warning(f"Não foi possível carregar perfis: {e}")

st.markdown("---")
st.subheader("Gerar prescrição (ZIP)")
with st.form("gen"):
    profile = st.selectbox("Perfil", ["deere_basic","trimble_basic","topcon_basic","agleader_basic"])
    job_name = st.text_input("Nome do job", "Plantio Soja T01")
    culture = st.text_input("Cultura", "soja")
    zones = st.text_area("Zonas (JSON c/ rate, area_ha, class, zone_id)", '[{"zone_id":1,"class":"low","area_ha":10,"rate":180},{"zone_id":2,"class":"mid","area_ha":15,"rate":200},{"zone_id":3,"class":"high","area_ha":5,"rate":220}]', height=160)
    if st.form_submit_button("Gerar ZIP ISOXML"):
        try:
            z = json.loads(zones)
            j = requests.post(f"{api}/isoxml/export", json={"profile": profile, "job_name": job_name, "culture": culture, "zones": z}).json()
            st.json(j)
        except Exception as e:
            st.error(f"JSON inválido: {e}")

st.markdown("---")
st.subheader("Validar ISOXML (colar XML)")
xml = st.text_area("Cole o conteúdo do TASKDATA.XML aqui", "", height=180)
if st.button("Validar XML"):
    st.json(requests.post(f"{api}/isoxml/validate", json={"xml_text": xml}).json())

import requests as rq, os
role_api = os.getenv("TS_BACKEND_URL","http://localhost:8000") + "/auth/role"
_res = rq.get(role_api, params={"user_id": user_id}).json()
_user_role = (_res.get("role") or "visitante").lower()
_allowed = set(['gestor', 'integrador', 'engenheiro'])
if _user_role not in _allowed:
    import streamlit as st
    st.error(f"Acesso restrito. Seu papel: '{_user_role}'. Permitidos: {', '.join(_allowed)}"); st.stop()
