
from __future__ import annotations
import streamlit as st, json
from pathlib import Path
from frontend.auth import require
from frontend.security_policies import rotate_hmac_secret, load_policy, sessions

st.set_page_config(page_title="Segurança – Chaves & Sessões", page_icon="🧷", layout="wide")
user = require(roles=("developer","gestor"))

st.title("🧷 Rotação de Chave HMAC & Sessões")

col1, col2 = st.columns(2)
with col1:
    st.subheader("Assinatura HMAC (auditoria)")
    pol = load_policy()
    st.write("Chaves antigas (últimas 5):")
    st.code("\n".join(pol.get("audit_hmac_old", [])) or "—")
    if st.button("Rotacionar chave HMAC agora"):
        rotate_hmac_secret()
        st.success("Chave rotacionada. Novos logs usarão a nova chave; antigos continuam verificáveis com as antigas.")

with col2:
    st.subheader("Sessões ativas (último login/IP)")
    s = sessions()
    if not s:
        st.info("Sem sessões registradas ainda.")
    else:
        st.json(s)
