
import streamlit as st, requests
st.set_page_config(page_title='Admin – Curadoria (Snippets Premium)', page_icon='📚', layout='wide')
from frontend.auth import require
user = require(roles=('developer','gestor'))

st.title('📚 Curadoria Premium – Ingestão de Lotes (sem ZIP)')
col1, col2 = st.columns(2)
with col1:
    st.subheader('Lotes detectados no servidor')
    r = requests.get('http://localhost:8000/knowledge/list')
    if r.ok:
        data = r.json()
        st.write('Arquivos:', data.get('files', []))
        st.write('Total de lotes:', data.get('count_files', 0))
    else:
        st.error('Backend indisponível.')
with col2:
    st.subheader('Ingestão do conhecimento (agregar todos)')
    if st.button('Ingerir todos os lotes agora'):
        r2 = requests.post('http://localhost:8000/knowledge/ingest_all')
        if r2.ok:
            st.success(f"Indexados: {r2.json().get('indexed')} snippets")
        else:
            st.error('Falha ao ingerir lotes.')
st.caption('Os lotes ficam em data/knowledge/snippets_premium_loteX.jsonl e são agregados em data/knowledge/index_snippets.jsonl.')
