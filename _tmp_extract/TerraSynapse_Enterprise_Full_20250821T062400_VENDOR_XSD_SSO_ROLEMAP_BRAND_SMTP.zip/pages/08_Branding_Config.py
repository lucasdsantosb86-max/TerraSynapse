import streamlit as st, os, json
from pathlib import Path

st.set_page_config(page_title="Branding / White-label", page_icon="🎨", layout="wide")
st.title("🎨 Branding / White‑label")

base = Path(os.getcwd())
cfg = base/"config"/"branding.json"

st.subheader("Configuração atual")
st.json(json.loads(cfg.read_text(encoding="utf-8")) if cfg.exists() else {})

st.info("Para trocar logo, coloque a imagem em static/brands/ e edite config/branding.json. O PDF diário já usa seu brand por domínio de e-mail.")