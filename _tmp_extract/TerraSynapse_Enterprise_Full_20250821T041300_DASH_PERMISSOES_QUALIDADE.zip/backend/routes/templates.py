from fastapi import APIRouter, Query, Body
from ..services.templates import list_cultures, list_apps, get_rates, zones_from_ndvi_classes

router = APIRouter(prefix="/templates", tags=["templates"])

@router.get("/cultures")
def cultures():
    return {"ok": True, "items": list_cultures()}

@router.get("/apps")
def apps(culture: str):
    return {"ok": True, "items": list_apps(culture)}

@router.get("/rates")
def rates(culture: str, application: str):
    return {"ok": True, "rates": get_rates(culture, application)}

@router.post("/zones_from_ndvi")
def zfrom(culture: str, application: str, zones: list = Body(...)):
    return {"ok": True, "zones": zones_from_ndvi_classes(zones, culture, application)}