import json, requests, pandas as pd, streamlit as st
import pydeck as pdk

st.set_page_config(page_title="Heatmap GPS", page_icon="🐄")

st.title("🐄 Heatmap & Distâncias diárias por animal (GPS)")

st.caption("Consome /ingest/gps e mostra deslocamento por animal.")

backend = st.text_input("Backend URL", value="http://localhost:8000")

colA, colB = st.columns(2)
with colA:
    if st.button("Atualizar KM/dia"):
        try:
            km = requests.get(f"{backend}/ingest/gps/km_dia", timeout=10).json()
            st.session_state["km"] = km
        except Exception as e:
            st.error(f"Erro: {e}")
with colB:
    uploaded = st.file_uploader("Importar CSV de GPS (timestamp,animal_id,lat,lon)", type=["csv"])
    if uploaded is not None and st.button("Enviar CSV para /ingest/gps"):
        import csv, time
        rows = list(csv.DictReader(uploaded.read().decode("utf-8").splitlines()))
        payload = [{"timestamp": r["timestamp"], "animal_id": r["animal_id"], "lat": float(r["lat"]), "lon": float(r["lon"])} for r in rows]
        try:
            r = requests.post(f"{backend}/ingest/gps", json=payload, timeout=20).json()
            st.success(f"Enviados: {r.get('added')} pontos")
        except Exception as e:
            st.error(f"Erro: {e}")

st.divider()
km = st.session_state.get("km", {})
if km:
    # tabela plana
    recs = []
    for aid, days in km.items():
        for d, v in days.items():
            recs.append({"animal_id": aid, "data": d, "km": v})
    df = pd.DataFrame(recs)
    st.dataframe(df)

st.divider()
st.subheader("Mapa (pydeck) — pontos recentes")
# Para demo simples, usar últimos 500 pontos do CSV local, se existir
import os, pandas as pd
from pathlib import Path
LOG = Path(__file__).resolve().parents[1]/"data"/"gps"/"gps_log.csv"
if LOG.exists():
    dfl = pd.read_csv(LOG)
    if len(dfl)>500:
        dfl = dfl.tail(500)
    if len(dfl)>0:
        midpoint = (dfl["lat"].mean(), dfl["lon"].mean())
        st.pydeck_chart(pdk.Deck(
            map_style=None,
            initial_view_state=pdk.ViewState(latitude=midpoint[0], longitude=midpoint[1], zoom=12, pitch=45),
            layers=[
                pdk.Layer("HeatmapLayer", data=dfl, get_position='[lon, lat]', aggregation=pdk.types.String("MEAN"), radius_pixels=60),
                pdk.Layer("ScatterplotLayer", data=dfl, get_position='[lon, lat]', get_radius=5)
            ],
        ))
    else:
        st.info("Sem pontos no arquivo local ainda.")
else:
    st.info("Envie um CSV de GPS para visualizar no mapa.")