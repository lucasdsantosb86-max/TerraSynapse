from pathlib import Path
import json, time
from .alerts_webhook import _cfg, send

BASE = Path(__file__).resolve().parents[2]
OPS  = BASE/"data"/"ingest"/"jdlink"/"operations"

def _last_seen_per_machine():
    last = {}
    for fp in OPS.glob("*.json"):
        try:
            doc = json.loads(fp.read_text(encoding="utf-8"))
            for it in doc.get("items", []):
                mid = it.get("machine_id")
                ts  = int(it.get("end_ts") or it.get("start_ts") or 0)
                if mid:
                    last[mid] = max(last.get(mid, 0), ts)
        except:
            pass
    return last

def check_and_alert():
    cfg = _cfg()
    thr_h = int(cfg.get("disconnect_hours") or 4)
    thr_s = thr_h * 3600
    now = int(time.time())
    last = _last_seen_per_machine()
    alerts = []
    for mid, ts in last.items():
        if now - ts >= thr_s:
            payload = {"type":"machine_disconnected","machine_id": mid, "last_seen_ts": ts, "now": now, "gap_hours": round((now - ts)/3600,2)}
            send(payload)
            alerts.append(payload)
    return {"ok": True, "count": len(alerts), "alerts": alerts}