from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib import colors
from io import BytesIO
from pathlib import Path

def gerar_pdf(plan: dict, out_path: str):
    buf = BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4)
    styles = getSampleStyleSheet()
    story = []
    story.append(Paragraph("Relatório de Custos por Talhão – TerraSynapse", styles["Title"]))
    story.append(Spacer(1, 12))
    # Resumo
    meta = [["Cultura", plan.get("cultura","")],["Área útil (ha)", f"{plan.get('area_ha',0):.2f}"],["NDVI médio", f"{plan.get('ndvi_mean',0):.3f}"]]
    t = Table(meta, colWidths=[150, 300])
    t.setStyle(TableStyle([("GRID",(0,0),(-1,-1),0.25,colors.grey)]))
    story.append(t); story.append(Spacer(1, 12))
    # Insumos
    ins = plan.get("insumos", [])
    if ins:
        hdr = [["Item","Qtd","Unid","Preço (R$)","Total (R$)"]]
        rows = hdr + [[i["item"], i["qtd"], i["un"], f"{i['preco_R$']:.2f}", f"{i['total_R$']:.2f}"] for i in ins]
        ti = Table(rows, repeatRows=1)
        ti.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0), colors.HexColor("#1565C0")),
                                ("TEXTCOLOR",(0,0),(-1,0), colors.white),
                                ("GRID",(0,0),(-1,-1),0.25,colors.grey)]))
        story.append(ti); story.append(Spacer(1,12))
    # Totais
    tot = [["Custo total (R$)", f"{plan.get('total_R$',0):.2f}"],
           ["Custo por ha (R$/ha)", f"{plan.get('custo_R$_ha',0):.2f}"],
           ["Benchmark (R$/ha)", f"{plan.get('benchmark_R$_ha',0):.2f}"],
           ["Economia vs. benchmark (R$/ha)", f"{plan.get('economia_R$_ha',0):.2f}"]]
    tt = Table(tot, colWidths=[220, 230])
    tt.setStyle(TableStyle([("GRID",(0,0),(-1,-1),0.25,colors.grey)]))
    story.append(tt)
    doc.build(story)
    Path(out_path).write_bytes(buf.getvalue())
    return {"ok": True, "file": out_path}