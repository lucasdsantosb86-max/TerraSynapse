import streamlit as st, os, requests, json, glob

st.set_page_config(page_title="Admin – Importadores de Custos", page_icon="📥", layout="centered")
st.title("📥 Admin – Importadores de Custos (IMEA/CONAB/USDA/Eurostat)")

api = st.text_input("Backend URL", value=os.getenv("TS_BACKEND_URL","http://localhost:8000"))
url = st.text_input("URL CSV público (fonte oficial)")

col1, col2, col3, col4 = st.columns(4)
if col1.button("Importar IMEA") and url:
    st.json(requests.post(f"{api}/costs/importers/imea", json={"url": url}).json())
if col2.button("Importar CONAB") and url:
    st.json(requests.post(f"{api}/costs/importers/conab", json={"url": url}).json())
if col3.button("Importar USDA") and url:
    st.json(requests.post(f"{api}/costs/importers/usda", json={"url": url}).json())
if col4.button("Importar Eurostat") and url:
    st.json(requests.post(f"{api}/costs/importers/eurostat", json={"url": url}).json())

st.markdown("---")
st.subheader("Arquivos importados (data/costs/sources)")
import os, pathlib
p = pathlib.Path("data/costs/sources")
p.mkdir(parents=True, exist_ok=True)
files = sorted(p.glob("*.csv"), reverse=True)[:10]
for f in files:
    st.write(f.name)
    meta = pathlib.Path(str(f)+".meta.json")
    if meta.exists(): st.json(json.loads(meta.read_text(encoding="utf-8")))