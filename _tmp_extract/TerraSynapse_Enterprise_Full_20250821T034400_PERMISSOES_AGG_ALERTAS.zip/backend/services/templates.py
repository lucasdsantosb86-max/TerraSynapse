from pathlib import Path
import json
BASE = Path(__file__).resolve().parents[2]
TEMPL = json.loads((BASE/"config"/"templates_vra.json").read_text(encoding="utf-8"))

def list_cultures():
    return list(TEMPL.keys())

def list_apps(culture: str):
    c = TEMPL.get(culture.lower(), {})
    return list(c.keys())

def get_rates(culture: str, application: str):
    c = TEMPL.get(culture.lower(), {})
    a = c.get(application, None)
    return a if a else {}

def zones_from_ndvi_classes(ndvi_zones: list, culture: str, application: str, default=150):
    rates = get_rates(culture, application) or {}
    out = []
    for z in ndvi_zones:
        klass = z.get("class")
        rate = rates.get(klass, default)
        out.append({"zone_id": z.get("zone_id"), "rate": rate, "unit": "kg_ha"})
    return out