from pathlib import Path
import numpy as np

def read_ndvi_from_geotiff(path: str):
    import rasterio
    with rasterio.open(path) as src:
        # Tentar bandas padrão: NIR=8, RED=4 (Sentinel-2) — ajustar conforme produto
        try:
            nir = src.read(8).astype("float32")
            red = src.read(4).astype("float32")
        except Exception:
            # fallback: tentar 5 e 3 (alguns produtos)
            nir = src.read(5).astype("float32")
            red = src.read(3).astype("float32")
        ndvi = (nir - red) / (nir + red + 1e-6)
        # máscara básica
        ndvi = np.clip(ndvi, -1.0, 1.0)
        # área do pixel (m²)
        res = src.transform.a * -src.transform.e  # |a|*|e|
        return ndvi, float(res)