import streamlit as st, os, requests, json

st.set_page_config(page_title="Admin – Agenda de Importadores", page_icon="⏱️", layout="centered")
st.title("⏱️ Admin – Agenda de Importadores de Custos")

api = st.text_input("Backend URL", value=os.getenv("TS_BACKEND_URL","http://localhost:8000"))
st.subheader("Cadastrar/atualizar job")
src = st.selectbox("Fonte", ["IMEA","CONAB","USDA","Eurostat"])
url = st.text_input("URL CSV público")
thr = st.number_input("Alerta se variação semanal > %", 0.0, 100.0, 7.5)

if st.button("Salvar job"):
    if url:
        r = requests.post(f"{api}/costs/schedule/upsert", json={"source": src, "url": url, "threshold_pct": thr}).json()
        st.success("Job salvo"); st.json(r)
    else:
        st.error("Informe uma URL CSV válida.")

st.markdown("---")
st.subheader("Jobs cadastrados")
try:
    st.json(requests.get(f"{api}/costs/schedule/list").json())
except Exception as e:
    st.error(str(e))

st.markdown("---")
st.subheader("Executar agora")
if st.button("Rodar importadores agora"):
    try:
        st.json(requests.post(f"{api}/costs/schedule/run").json())
    except Exception as e:
        st.error(str(e))