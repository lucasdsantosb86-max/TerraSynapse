import streamlit as st, numpy as np, rasterio, os, requests, io, PIL
from pathlib import Path
from sklearn.cluster import KMeans

st.set_page_config(page_title="Planejamento de Talhão", page_icon="🛰️", layout="wide")
st.title("🛰️ Planejamento de Talhão – NDVI GeoTIFF + KMeans + Máscara ONNX (se disponível)")

col1, col2 = st.columns(2)
with col1:
    tif = st.file_uploader("Upload GeoTIFF (Sentinel/Landsat)", type=["tif","tiff"])
    red_band = st.number_input("Banda Red (ex. 4)", 1, 20, 4)
    nir_band = st.number_input("Banda NIR (ex. 8)", 1, 20, 8)
with col2:
    talhao = st.text_input("Nome do talhão", "Talhão 1")
    area_ha = st.number_input("Área estimada (ha)", 0.0, 100000.0, 10.0)
    n_zonas = st.slider("Nº de zonas (KMeans)", 3, 5, 3)

api = os.getenv("TS_BACKEND_URL","http://localhost:8000")

if tif:
    with rasterio.open(tif) as src:
        R = src.read(int(red_band)).astype(np.float32)
        N = src.read(int(nir_band)).astype(np.float32)
        ndvi = (N - R) / (N + R + 1e-6)

    # Tenta gerar uma miniatura RGB (se bandas 2/3/4) para segmentação ONNX
    mask_frac = 1.0
    try:
        with rasterio.open(tif) as src:
            if src.count >= 4:
                B = src.read(2).astype(np.float32); G = src.read(3).astype(np.float32); Rr = src.read(4).astype(np.float32)
                rgb = np.stack([Rr,G,B], axis=2)
                # normaliza 0..255 → 0..1
                rgb = (rgb - rgb.min())/(rgb.max()-rgb.min()+1e-6)
                from PIL import Image
                im = Image.fromarray((rgb*255).astype("uint8"))
                import io
                bio = io.BytesIO(); im.save(bio, format="PNG"); bio.seek(0)
                files = {"file": ("preview.png", bio.getvalue(), "image/png")}
                j = requests.post(f"{api}/vision/aerial/segment", files=files, timeout=60).json()
                if j.get("ok") and j.get("area_pixels"):
                    mask_frac = float(j["area_pixels"])/(rgb.shape[0]*rgb.shape[1])
    except Exception as e:
        pass

    ndvi_masked = ndvi * mask_frac
    st.caption(f"Máscara plantável aplicada (fração aprox.): {mask_frac:.2%}")

    st.subheader(f"NDVI – média: {float(np.nanmean(ndvi_masked)):.3f}")
    view = ((ndvi_masked - np.nanmin(ndvi_masked)) / (np.nanmax(ndvi_masked)-np.nanmin(ndvi_masked)+1e-6) * 255).astype(np.uint8)
    st.image(view, caption="NDVI (mascarado, escala 0–255)", use_column_width=True)

    x = ndvi_masked.reshape(-1,1)
    km = KMeans(n_clusters=n_zonas, n_init=10, random_state=42).fit(x)
    centers = sorted([c[0] for c in km.cluster_centers_])
    labels = km.labels_.reshape(ndvi_masked.shape)
    st.caption(f"Centroides (vigor baixo→alto): {', '.join(f'{c:.3f}' for c in centers)}")

    zonas = []
    for i in range(n_zonas):
        frac = float((labels==i).sum())/labels.size
        area_i = frac * area_ha * mask_frac
        zonas.append({"id": f"Z{i+1}", "area_ha": area_i, "vigor": ["baixo","médio","alto","muito alto","elite"][i]})

    st.subheader("Zonas de manejo (estimadas)")
    st.json(zonas)

    if st.button("Gerar PDF (com benchmark de custos)"):
        # bench simplificado
        bench = {"Sementes (R$/ha)":"-", "NPK (R$/ha)":"-", "Defensivos (R$/ha)":"-"}
        try:
            r = requests.get(f"{api}/costs/benchmark", params={"culture":"soja"}, timeout=20).json()
            if r.get("ok"):
                items = r["bench"][:3]
                if items:
                    bench = {f"{it['item']} ({it['unit']})": f"{it['price_med']:.2f}" for it in items}
        except Exception:
            pass
        payload = {"talhao": talhao, "area_ha": area_ha*mask_frac, "ndvi_medio": float(np.nanmean(ndvi_masked)),
                   "zonas": zonas, "custos": bench, "user_name":"Lucas", "logo_path": None}
        try:
            rr = requests.post(f"{api}/reports/talhao/generate", json=payload, timeout=60).json()
            st.success("Relatório gerado"); st.json(rr)
        except Exception as e:
            st.error(str(e))