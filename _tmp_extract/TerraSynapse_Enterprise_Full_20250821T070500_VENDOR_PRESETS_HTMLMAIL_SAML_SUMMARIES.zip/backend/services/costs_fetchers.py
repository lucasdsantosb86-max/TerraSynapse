from pathlib import Path
import pandas as pd
from .costs_global import normalize_csv as normalize_global
from .costs_local import normalize_local as normalize_local_fn

def sync_source(rec: dict):
    t = rec.get("type")
    path = rec.get("path")
    if t=="csv":
        p = Path(path)
        if not p.exists():
            return {"ok": False, "detail": f"not found: {p}"}
        if "global" in rec.get("name",""):
            out = p.with_suffix(".normalized.csv")
            res = normalize_global(str(p), str(out))
            return {"ok": True, "normalized": str(out), **res}
        else:
            out = p.with_suffix(".normalized.csv")
            res = normalize_local_fn(str(p), str(out))
            return {"ok": True, "normalized": str(out), **res}
    # extensível para http/api/json
    return {"ok": False, "detail": "unknown type"}