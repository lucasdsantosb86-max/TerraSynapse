import os, urllib.parse as urlparse
from .secrets import set_secret_user, get_secret_user

AUTH_URL = "https://signin.johndeere.com/oauth/signin"  # referência pública

def start_oauth(user_id: str, client_id: str, redirect_uri: str, scope: str="ag1 machinery"):
    # Gera URL de autorização (usuário será redirecionado no navegador)
    q = urlparse.urlencode({"client_id": client_id, "redirect_uri": redirect_uri, "response_type": "code", "scope": scope})
    return {"ok": True, "authorize_url": f"{AUTH_URL}?{q}"}

def receive_token(user_id: str, access_token: str, refresh_token: str=None):
    # Armazena no cofre por usuário
    set_secret_user(user_id, "jdlink", "access_token", access_token)
    if refresh_token:
        set_secret_user(user_id, "jdlink", "refresh_token", refresh_token)
    return {"ok": True}