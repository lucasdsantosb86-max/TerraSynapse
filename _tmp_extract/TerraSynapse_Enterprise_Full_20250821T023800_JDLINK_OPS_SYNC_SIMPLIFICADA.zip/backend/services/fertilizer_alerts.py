import pandas as pd
from pathlib import Path

DATA = Path(__file__).resolve().parents[2]/"data"/"costs"
DATA.mkdir(parents=True, exist_ok=True)

def check_variation(file_csv: str, column: str, window: int = 3, threshold_pct: float = 10.0):
    """
    Lê um CSV com coluna de preço (ex.: USD/t) e calcula variação vs. média móvel (window).
    Retorna alerta se variação > threshold_pct.
    """
    path = DATA/file_csv
    if not path.exists():
        return {"ok": False, "detail": f"Arquivo {file_csv} não encontrado em data/costs."}
    df = pd.read_csv(path)
    if column not in df.columns:
        return {"ok": False, "detail": f"Coluna {column} não encontrada no CSV."}
    s = df[column].astype(float)
    ma = s.rolling(window).mean()
    delta = (s.iloc[-1] - ma.iloc[-1]) / (ma.iloc[-1] if ma.iloc[-1] else 1) * 100.0
    return {"ok": True, "latest": float(s.iloc[-1]), "ma": float(ma.iloc[-1]) if pd.notnull(ma.iloc[-1]) else None,
            "delta_pct": round(delta,2), "alert": abs(delta) >= threshold_pct}