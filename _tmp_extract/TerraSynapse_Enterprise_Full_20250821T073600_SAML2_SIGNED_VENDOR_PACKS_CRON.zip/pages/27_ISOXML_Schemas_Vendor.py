import streamlit as st, requests, os, json
st.set_page_config(page_title="ISOXML – Schemas do Fabricante", page_icon="🏭", layout="wide")
st.title("🏭 ISOXML – Schemas do Fabricante (upload & validar)")

api = st.text_input("Backend URL", value=os.getenv("TS_BACKEND_URL","http://localhost:8000"))
user_id = st.text_input("Seu e-mail (para permissões)", "lucas@empresa.com")

# Guard
import requests as rq
role_api = api + "/auth/role"
_res = rq.get(role_api, params={"user_id": user_id}).json()
_user_role = (_res.get("role") or "visitante").lower()
_allowed = {"gestor","integrador","engenheiro"}
if _user_role not in _allowed:
    st.error(f"Acesso restrito. Seu papel: '{_user_role}'. Permitidos: {', '.join(_allowed)}")
    st.stop()

st.subheader("Schemas disponíveis")
st.json(requests.get(f"{api}/isoxml/vendor/list").json())

st.subheader("Upload de XSD único (legado)")
vendor_s = st.text_input("Fabricante (single)", "deere_3_3")
xsd_s = st.text_area("Conteúdo do XSD (single)", height=200)
if st.button("Salvar XSD (single)"):
    st.json(requests.post(f"{api}/isoxml/vendor/set", params={"vendor": vendor_s}, json={"xsd_text": xsd_s}).json())

st.subheader("Upload de PACK de XSDs (oficial)")
vendor_p = st.text_input("Fabricante (pack)", "deere_full")
files_p = st.text_area("Arquivos (JSON: nome->conteúdo)", value=json.dumps({"main.xsd":"<xsd:schema xmlns:xsd='http://www.w3.org/2001/XMLSchema'></xsd:schema>"}, indent=2), height=220)
entry = st.text_input("Entrypoint (ex.: main.xsd)", "main.xsd")
if st.button("Salvar PACK"):
    try:
        files = json.loads(files_p)
        st.json(requests.post(f"{api}/isoxml/vendor/set_pack", params={"vendor": vendor_p}, json={"files": files, "entrypoint": entry}).json())
    except Exception as e:
        st.error(f"JSON inválido: {e}")

st.subheader("Validar XML com XSD do fabricante")
vendor_v = st.text_input("Vendor para validar", "deere_full")
xml = st.text_area("Cole o TASKDATA.XML", height=220)
if st.button("Validar Vendor XSD"):
    st.json(requests.post(f"{api}/isoxml/vendor/validate", params={"vendor": vendor_v}, json={"xml_text": xml}).json())