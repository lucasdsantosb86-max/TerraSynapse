
from __future__ import annotations
import numpy as np
from typing import Optional, Dict, Any
from backend.geo.ndvi import ndvi_from_arrays, ndre_from_arrays, ndvi_from_rgb
from backend.geo.segmentation import segment_plantable, stats_from_mask
from backend.services.routes import parallel_lines, export_geojson
try:
    import rasterio
    from rasterio.features import shapes
except Exception:
    rasterio = None
try:
    from shapely.geometry import shape
except Exception:
    shape = None

DEFAULT_SEED_RATE = {
    "soja": 300000, "milho": 55000, "cana": 10000, "cafe": 4000,
    "trigo": 350000, "arroz": 100000, "algodao": 120000, "sorgo": 180000
}
DEFAULT_FERT_KG_HA = {
    "soja": 300, "milho": 350, "cana": 500, "cafe": 250,
    "trigo": 250, "arroz": 250, "algodao": 280, "sorgo": 220
}
def analyze_rgb_image(rgb: np.ndarray, meters_per_px: Optional[float]=None, cultura: str="soja") -> Dict[str,Any]:
    ndvi_proxy = ndvi_from_rgb(rgb)
    mask = segment_plantable(ndvi_proxy, th=0.15)
    stats = stats_from_mask(mask, pixel_area_m2=(meters_per_px**2 if meters_per_px else None))
    area_ha = stats.get("area_ha", None)
    seed_rate = DEFAULT_SEED_RATE.get(cultura.lower(), 250000)
    fert = DEFAULT_FERT_KG_HA.get(cultura.lower(), 250)
    return {
        "cultura": cultura, 
        "ndvi_proxy_stats": {"min": float(ndvi_proxy.min()), "max": float(ndvi_proxy.max()), "mean": float(ndvi_proxy.mean())},
        "mask_pixels": int(mask.sum()), "area_ha": area_ha,
        "recomendacao": {"sementes_un_ha": seed_rate, "adubo_kg_ha": fert}
    }
def analyze_geotiff(path: str, cultura: str="soja", spacing_m=10.0) -> Dict[str,Any]:
    if rasterio is None:
        raise RuntimeError("rasterio não disponível. Instale rasterio/GDAL.")
    with rasterio.open(path) as ds:
        nir = ds.read(1).astype("float32")
        red = ds.read(2).astype("float32")
        re  = ds.read(3).astype("float32") if ds.count>=3 else None
        if nir.max()>1.0: nir/=10000.0
        if red.max()>1.0: red/=10000.0
        if re is not None and re.max()>1.0: re/=10000.0
        ndvi = ndvi_from_arrays(nir, red)
        ndre = ndre_from_arrays(nir, re) if re is not None else None
        mask = segment_plantable(ndvi, th=0.15)
        px_area = abs(ds.transform[0]*ds.transform[4]*-1.0)
        stats = stats_from_mask(mask, pixel_area_m2=px_area)
        polys = []
        for geom, val in shapes(mask, transform=ds.transform):
            if val != 1: continue
            if shape: polys.append(shape(geom))
        if polys:
            poly = max(polys, key=lambda g: g.area)
            lines = parallel_lines(poly, spacing=spacing_m)
            geojson = export_geojson(lines)
        else:
            geojson = {"type":"FeatureCollection","features":[]}
        seed_rate = DEFAULT_SEED_RATE.get(cultura.lower(), 250000)
        fert = DEFAULT_FERT_KG_HA.get(cultura.lower(), 250)
        return {
            "cultura": cultura,
            "area_ha": float(stats.get("area_ha", 0.0)),
            "ndvi_stats": {"min": float(ndvi.min()), "max": float(ndvi.max()), "mean": float(ndvi.mean())},
            "ndre_available": bool(ndre is not None),
            "recomendacao": {"sementes_un_ha": seed_rate, "adubo_kg_ha": fert},
            "routes_geojson": geojson
        }
