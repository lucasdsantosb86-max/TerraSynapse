import json, requests
from pathlib import Path

DB = Path(__file__).resolve().parents[2]/"data"/"webhooks.json"
if not DB.exists(): DB.write_text("[]", encoding="utf-8")

def list_hooks():
    return json.loads(DB.read_text(encoding="utf-8"))

def add_hook(url: str, event: str):
    hooks = list_hooks()
    hooks.append({"url": url, "event": event})
    DB.write_text(json.dumps(hooks, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"ok": True, "count": len(hooks)}

def remove_hook(url: str, event: str):
    hooks = [h for h in list_hooks() if not (h["url"]==url and h["event"]==event)]
    DB.write_text(json.dumps(hooks, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"ok": True, "count": len(hooks)}

def emit(event: str, payload: dict):
    errs = []
    for h in list_hooks():
        if h["event"]==event:
            try:
                requests.post(h["url"], json={"event": event, "payload": payload}, timeout=10)
            except Exception as e:
                errs.append(str(e))
    return {"ok": len(errs)==0, "errors": errs}