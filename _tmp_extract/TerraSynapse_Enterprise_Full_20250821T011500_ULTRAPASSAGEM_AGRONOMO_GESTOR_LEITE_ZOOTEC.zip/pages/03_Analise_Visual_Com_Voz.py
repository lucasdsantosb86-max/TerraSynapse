import streamlit as st, requests, json, tempfile, os
from audio_recorder_streamlit import audio_recorder

st.set_page_config(page_title="Análise Visual • Voz", page_icon="🎥")
st.title("🎥 Análise Visual • Comando por Voz + Resposta Falada")

backend = st.text_input("Backend URL", value="http://localhost:8000")

tab1, tab2 = st.tabs(["Câmera/Upload", "Drone/Aérea"])

with tab1:
    st.subheader("Plantas / Animais")
    f = st.file_uploader("Enviar imagem (JPG/PNG)", type=["jpg","jpeg","png"])
    tipo = st.selectbox("Tipo", ["plant","animal"])
    if st.button("Analisar Foto") and f:
        files = {"file": (f.name, f.read(), f"type")}
        try:
            r = requests.post(f"{backend}/vision/{tipo}/analyze", files=files, timeout=60).json()
            st.success(r)
            st.session_state["diag"] = r
        except Exception as e:
            st.error(e)

    st.caption("🎙️ Comando por voz (gravar e transcrever localmente)")
    audio_bytes = audio_recorder(text="Gravar comando", energy_threshold=(0.01,0.1), pause_threshold=2.0, sample_rate=16000)
    if audio_bytes and st.button("Transcrever & Consultar"):
        # Salva wav temporário e envia ao Chat (se houver)
        with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as tf:
            tf.write(audio_bytes); tf.flush()
            st.info("Áudio gravado. Envie seu endpoint de chat na página de Chat com Voz para processar.")
        os.unlink(tf.name)

    if "diag" in st.session_state and st.button("🔊 Falar resultado"):
        try:
            import pyttsx3, tempfile
            engine = pyttsx3.init(); engine.setProperty('rate', 170); engine.setProperty('volume', 0.9)
            txt = json.dumps(st.session_state["diag"], ensure_ascii=False, indent=2)
            with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as tf:
                engine.save_to_file(txt, tf.name); engine.runAndWait()
                st.audio(open(tf.name,"rb").read(), format="audio/wav")
        except Exception as e:
            st.error(f"TTS indisponível: {e}")

with tab2:
    st.subheader("Drone / Imagem Aérea")
    af = st.file_uploader("Upload GeoTIFF/JPG/PNG", type=["tif","tiff","jpg","jpeg","png"])
    if st.button("Analisar Área") and af:
        files = {"file": (af.name, af.read(), "application/octet-stream")}
        try:
            r = requests.post(f"{backend}/vision/aerial/analyze", files=files, timeout=120).json()
            st.success(r)
        except Exception as e:
            st.error(e)