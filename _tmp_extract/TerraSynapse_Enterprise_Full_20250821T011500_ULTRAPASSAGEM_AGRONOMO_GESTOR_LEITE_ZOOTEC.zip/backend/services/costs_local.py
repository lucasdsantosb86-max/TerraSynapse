from pathlib import Path
import pandas as pd

FX = {"BRL":1.0,"USD":5.0,"EUR":5.5}

def normalize_local(src_path: str, out_path: str):
    df = pd.read_csv(src_path)
    df["fx"] = df["currency"].map(FX).fillna(1.0)
    df["price_BRL"] = df["price_local"]*df["fx"]
    # Índices úteis
    grp = df.groupby(["state","microregion","culture"], as_index=False)["price_BRL"].mean().rename(columns={"price_BRL":"avg_price_BRL"})
    df_out = df.merge(grp, on=["state","microregion","culture"], how="left")
    df_out.to_csv(out_path, index=False)
    return {"ok": True, "rows": len(df_out), "out": out_path}