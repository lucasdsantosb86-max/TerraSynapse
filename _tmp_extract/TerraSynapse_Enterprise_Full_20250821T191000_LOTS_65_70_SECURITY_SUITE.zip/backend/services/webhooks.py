import time, json, requests
from pathlib import Path
from typing import Dict, Any

BASE = Path(__file__).resolve().parents[2]
CONF = BASE/"config"/"webhooks.json"
LOG  = BASE/"data"/"alerts"
LOG.mkdir(parents=True, exist_ok=True)
LAST = LOG/"last_alerts.jsonl"

def _load_conf():
    try:
        return json.loads(CONF.read_text(encoding="utf-8"))
    except Exception:
        return {"channels":[], "throttle_seconds":900, "simulate": True}

def _recent_key(event: Dict[str,Any]) -> str:
    parts = [event.get(k,"") for k in ["type","farm","tank","sensor","status"]]
    return "|".join(parts)

def _too_soon(key: str, throttle: int) -> bool:
    # varre last_alerts.jsonl procurando a última ocorrência da mesma chave
    if not LAST.exists(): return False
    try:
        last_lines = LAST.read_text(encoding="utf-8").strip().splitlines()[-300:]
    except Exception:
        return False
    now = time.time()
    for ln in reversed(last_lines):
        try:
            ev = json.loads(ln)
            if ev.get("key")==key:
                if now - ev.get("ts", 0) < throttle:
                    return True
                break
        except Exception:
            continue
    return False

def _append_log(obj: Dict[str,Any]):
    with LAST.open("a", encoding="utf-8") as f:
        f.write(json.dumps(obj, ensure_ascii=False)+"\n")

def send_event(event: Dict[str,Any]) -> Dict[str,Any]:
    cfg = _load_conf()
    throttle = int(cfg.get("throttle_seconds", 900))
    key = _recent_key(event)
    if _too_soon(key, throttle):
        out = {"ok": False, "detail":"throttled", "key": key}
        _append_log({"ts": time.time(), "key": key, "result": out})
        return out

    payload = {k:v for k,v in event.items() if k not in ["_internal"]}
    results = []
    for ch in cfg.get("channels", []):
        if not ch.get("enabled"): 
            results.append({"channel": ch.get("name"), "skipped": True})
            continue
        url = ch.get("url")
        try:
            if cfg.get("simulate", True):
                results.append({"channel": ch.get("name"), "simulate": True, "url": url, "payload": payload})
            else:
                r = requests.post(url, json=payload, timeout=8)
                r.raise_for_status()
                results.append({"channel": ch.get("name"), "status_code": r.status_code})
        except Exception as e:
            results.append({"channel": ch.get("name"), "error": str(e)})
    out = {"ok": True, "sent": results, "key": key}
    _append_log({"ts": time.time(), "key": key, "event": payload, "result": out})
    return out