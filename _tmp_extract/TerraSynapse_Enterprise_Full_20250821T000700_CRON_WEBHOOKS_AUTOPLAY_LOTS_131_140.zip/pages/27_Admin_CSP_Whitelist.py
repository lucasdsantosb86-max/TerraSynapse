import streamlit as st, json, os, pathlib
st.set_page_config(page_title="Admin – CSP Whitelist por Módulo", page_icon="🛡️", layout="centered")
st.title("🛡️ Admin – CSP Whitelist por Módulo")

p = pathlib.Path("config/csp.json")
cfg = json.loads(p.read_text(encoding="utf-8"))
env = st.selectbox("Ambiente", ["dev","prod"], index=0 if cfg.get("env","dev")=="dev" else 1)

st.subheader("Módulos externos")
maps = st.checkbox("Map Tiles (OpenStreetMap)", True)
mapbox = st.checkbox("Mapbox (opcional)", False)
fonts = st.checkbox("Google Fonts", True)
weather = st.checkbox("APIs de Clima (OpenWeather/ClimaTempo)", True)
cdn = st.checkbox("JS CDN (unpkg/jsdelivr)", False)

def _set(lst, val):
    for v in val:
        if v not in lst: lst.append(v)

if st.button("Aplicar Whitelist"):
    section = cfg[env]
    if maps:
        _set(section["img_src"], ["https://tile.openstreetmap.org"])
        _set(section["connect_src"], ["https://tile.openstreetmap.org"])
    if mapbox:
        _set(section["connect_src"], ["https://api.mapbox.com","https://*.tiles.mapbox.com"])
        _set(section["img_src"], ["https://*.tiles.mapbox.com"])
    if fonts:
        _set(section["style_src"], ["https://fonts.googleapis.com"])
        _set(section["connect_src"], ["https://fonts.googleapis.com","https://fonts.gstatic.com"])
        _set(section["img_src"], ["https://*.gstatic.com","https://*.googleusercontent.com"])
    if weather:
        _set(section["connect_src"], ["https://api.openweathermap.org","https://api.climatempo.com.br"])
    if cdn:
        _set(section["script_src"], ["https://unpkg.com","https://cdn.jsdelivr.net"])
        _set(section["connect_src"], ["https://unpkg.com","https://cdn.jsdelivr.net"])
    cfg["env"] = env
    p.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
    st.success("Whitelist aplicada ao CSP.")