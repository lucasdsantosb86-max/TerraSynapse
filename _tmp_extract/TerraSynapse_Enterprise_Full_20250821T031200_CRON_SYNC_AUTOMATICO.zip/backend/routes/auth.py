from fastapi import APIRouter, Body
from ..services.auth import create_user, login

router = APIRouter(prefix="/auth", tags=["auth"])

@router.post("/create")
def create(email: str = Body(...), password: str = Body(...), role: str = Body("tecnico")):
    return create_user(email, password, role)

@router.post("/login")
def do_login(email: str = Body(...), password: str = Body(...), code: str = Body(None)):
    return login(email, password, code)