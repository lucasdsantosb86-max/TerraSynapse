from fastapi import APIRouter, Body
from ..services.costs_seeds import normalize_seeds
from pathlib import Path
router = APIRouter(prefix="/costs/seeds", tags=["costs"])
@router.post("/normalize")
def normalize(src: str = Body(...)):
    out = Path(src).with_suffix(".normalized.csv")
    return normalize_seeds(src, str(out))