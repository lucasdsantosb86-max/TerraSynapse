from fastapi import APIRouter, Body
from ..services.report_financeiro import gerar_pdf_financeiro
from pathlib import Path

router = APIRouter(prefix="/reports/financeiro", tags=["reports"])

@router.post("/pdf")
def pdf(periodo: str = Body(...), talhoes_csv: str = Body(...), limiares: dict = Body(default=None)):
    out = Path(__file__).resolve().parents[2]/"data"/"reports"/"financeiro_mensal.pdf"
    out.parent.mkdir(parents=True, exist_ok=True)
    lim = limiares or {"soja":6000,"milho":5000,"trigo":4500,"citros":20000,"cana":12000}
    return gerar_pdf_financeiro(periodo, talhoes_csv, lim, str(out))