
from __future__ import annotations
import os, json, math, datetime as dt
from pathlib import Path
from collections import defaultdict
DATA_DIR = Path("data/gps"); DATA_DIR.mkdir(parents=True, exist_ok=True)
def _today():
    return dt.datetime.now().strftime("%Y-%m-%d")
def _path(date: str|None=None):
    return DATA_DIR / f"{date or _today()}.jsonl"
def parse_nmea(line: str):
    parts = line.strip().split(",")
    if not parts or not parts[0].endswith("RMC"): return None
    try:
        lat_raw, ns = parts[3], parts[4]
        lon_raw, ew = parts[5], parts[6]
        spd_knots = float(parts[7]) if parts[7] else 0.0
        def dm_to_deg(dm, hemi):
            if not dm: return None
            d = float(dm[:2 if hemi in ('N','S') else 3])
            m = float(dm[2 if hemi in ('N','S') else 3:])
            deg = d + m/60.0
            if hemi in ('S','W'): deg = -deg
            return deg
        lat = dm_to_deg(lat_raw, ns); lon = dm_to_deg(lon_raw, ew)
        spd_ms = spd_knots * 0.514444
        return {"lat": lat, "lon": lon, "speed_ms": spd_ms}
    except Exception:
        return None
def ingest(payload: dict|str):
    date = _today()
    if isinstance(payload, str):
        n = parse_nmea(payload)
        if n is None: return False
        rec = {"device_id":"nmea", "animal_id":"nmea", "ts":dt.datetime.utcnow().isoformat(), **n}
    else:
        rec = payload
    with _path(date).open("a", encoding="utf-8") as f:
        f.write(json.dumps(rec, ensure_ascii=False)+"\n")
    return True
def _haversine(lat1, lon1, lat2, lon2):
    R = 6371000.0
    import math
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2-lat1); dlmb = math.radians(lon2-lon1)
    a = math.sin(dphi/2)**2 + math.cos(phi1)*math.cos(phi2)*math.sin(dlmb/2)**2
    c = 2*math.atan2(math.sqrt(a), math.sqrt(1-a))
    return R*c
def get_daily_metrics(date: str|None=None):
    p = _path(date); 
    if not p.exists(): return {}
    by_id = defaultdict(list)
    for line in p.read_text(encoding="utf-8").splitlines():
        try:
            rec = json.loads(line); aid = rec.get("animal_id") or rec.get("device_id")
            by_id[aid].append(rec)
        except Exception: continue
    metrics = {}
    for aid, pts in by_id.items():
        pts = sorted(pts, key=lambda x: x.get("ts","")); km = 0.0
        for i in range(1, len(pts)):
            a, b = pts[i-1], pts[i]
            if None in (a.get("lat"), a.get("lon"), b.get("lat"), b.get("lon")): continue
            km += _haversine(a["lat"],a["lon"],b["lat"],b["lon"]) / 1000.0
        metrics[aid] = {"km": round(km, 3), "points": len(pts)}
    return metrics
