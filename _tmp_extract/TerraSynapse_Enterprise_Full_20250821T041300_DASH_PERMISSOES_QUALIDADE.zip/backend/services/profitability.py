from pathlib import Path
import json

BASE = Path(__file__).resolve().parents[2]
COST = json.loads((BASE/"config"/"costs_by_culture.json").read_text(encoding="utf-8"))

def calc_profit(culture: str, area_ha: float, price_per_t: float, yield_t_ha: float, zone_factors=None):
    # zone_factors: [{"zone_id":1,"yield_factor":1.05,"area_ha":5.2}, ...]
    c = COST.get(culture.lower(), {})
    total_cost_per_ha = sum(c.values()) if c else 0.0
    if not zone_factors:
        gross = price_per_t * yield_t_ha
        margin = gross - total_cost_per_ha
        return {"ok": True, "per_ha":{"gross":gross,"cost":total_cost_per_ha,"margin":margin}, "total":{"gross":gross*area_ha,"cost":total_cost_per_ha*area_ha,"margin":margin*area_ha}}
    # por zona
    gross_total = 0.0; area_total = 0.0
    for z in zone_factors:
        yf = z.get("yield_factor",1.0)
        ah = z.get("area_ha",0.0)
        gross_total += price_per_t * yield_t_ha * yf * ah
        area_total += ah
    cost_total = total_cost_per_ha * area_total
    margin_total = gross_total - cost_total
    return {"ok": True, "per_ha":{"gross":(gross_total/area_total if area_total else 0.0), "cost":total_cost_per_ha, "margin":(gross_total/area_total - total_cost_per_ha if area_total else 0.0)}, "total":{"gross":gross_total,"cost":cost_total,"margin":margin_total}}