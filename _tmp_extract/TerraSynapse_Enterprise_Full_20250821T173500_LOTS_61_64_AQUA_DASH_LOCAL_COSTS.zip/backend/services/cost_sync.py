import io, json, pandas as pd, requests
from pathlib import Path
from datetime import datetime

ROOT = Path(__file__).resolve().parents[2]
COSTS = ROOT/"data"/"costs"
COSTS.mkdir(parents=True, exist_ok=True)

def _save_df(df: pd.DataFrame, name: str):
    csv_path = COSTS/f"{name}.csv"
    df.to_csv(csv_path, index=False)
    return {"ok": True, "rows": len(df), "file": str(csv_path)}

def fetch_worldbank_pink_sheet():
    # Pink Sheet (Excel mensal) – URL pode variar. Permitir colar URL na UI.
    raise NotImplementedError("Forneça a URL do Pink Sheet na UI de Sync.")

def fetch_usda_ers_costs(url: str):
    # Baixa um Excel/CSV dos custos por cultura (ERS Commodity Costs & Returns)
    r = requests.get(url, timeout=30)
    r.raise_for_status()
    if url.lower().endswith(".xlsx"):
        df = pd.read_excel(io.BytesIO(r.content))
    else:
        df = pd.read_csv(io.StringIO(r.text))
    return _save_df(df, "usda_ers_costs_raw")

def fetch_conab_planilha(url: str):
    r = requests.get(url, timeout=30)
    r.raise_for_status()
    if url.lower().endswith(".xlsx") or url.lower().endswith(".xls"):
        df = pd.read_excel(io.BytesIO(r.content))
    else:
        df = pd.read_csv(io.StringIO(r.text), sep=";")
    return _save_df(df, "conab_planilha_raw")

def fetch_imea(url: str):
    r = requests.get(url, timeout=30)
    r.raise_for_status()
    if url.lower().endswith(".xlsx") or url.lower().endswith(".xls"):
        df = pd.read_excel(io.BytesIO(r.content))
    else:
        df = pd.read_csv(io.StringIO(r.text), sep=";")
    return _save_df(df, "imea_raw")

def normalize_costs(map_config: dict):
    """
    Normaliza arquivos baixados para um schema comum:
    region,culture,metric,value,currency,date,source
    Recebe um dict com instruções de mapeamento de colunas da planilha.
    """
    out_rows = []
    # Exemplo de normalização mínima (o restante é configurável na UI)
    for src_file in (COSTS/"usda_ers_costs_raw.csv", COSTS/"conab_planilha_raw.csv", COSTS/"imea_raw.csv"):
        if src_file.exists():
            import pandas as pd
            df = pd.read_csv(src_file)
            # Aqui aplicaríamos map_config; por ora, armazenar todo conteúdo como staging:
            for _ in df.head(100).to_dict(orient="records"):  # amostra
                out_rows.append({
                    "region": "AUTO",
                    "culture": "AUTO",
                    "metric": "AUTO",
                    "value": None,
                    "currency": "",
                    "date": datetime.utcnow().date().isoformat(),
                    "source": src_file.name
                })
    df_out = pd.DataFrame(out_rows)
    return _save_df(df_out, "costs_normalized_sample")