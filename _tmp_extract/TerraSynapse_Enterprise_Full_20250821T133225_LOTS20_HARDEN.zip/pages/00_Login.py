
from __future__ import annotations
import streamlit as st, json
from pathlib import Path
from frontend.security_policies import load_policy, client_ip, add_failed, clear_failed, locked, gen_captcha, hash_pw
from frontend.audit import log_action

st.set_page_config(page_title="Login – TerraSynapse IA", page_icon="🔐", layout="centered")

USERS_PATH = Path("data/users/users.json")

def load_users():
    try:
        data = json.loads(USERS_PATH.read_text(encoding="utf-8"))
        return {u["username"]: u for u in data.get("users",[])}
    except Exception:
        return {}

st.title("🔐 TerraSynapse IA – Login")

pol = load_policy()
ip = client_ip()
users = load_users()

u = st.text_input("Usuário")
p = st.text_input("Senha", type="password")

# Captcha opcional
if pol.get("auth",{}).get("captcha_enabled"):
    cap = gen_captcha()
    st.session_state.setdefault("cap_q", cap["question"])
    st.session_state.setdefault("cap_a", cap["answer"])
    st.text(f"Captcha: {st.session_state['cap_q']}")
    cap_ans = st.text_input("Resposta do captcha")

if st.button("Entrar"):
    if locked(u, ip):
        st.error("Muitas tentativas falhas. IP/usuário temporariamente bloqueado.")
        st.stop()
    rec = users.get(u)
    if not rec or rec.get("password_hash") != hash_pw(p):
        add_failed(u, ip)
        st.error("Usuário ou senha inválidos.")
        log_action(u or "desconhecido", "login", "user", u or "-", {"result":"fail","ip":ip})
        st.stop()
    # valida captcha se ativo
    if pol.get("auth",{}).get("captcha_enabled"):
        if cap_ans.strip() != st.session_state.get("cap_a"):
            add_failed(u, ip); st.error("Captcha incorreto."); st.stop()
    # expiração de senha
    exp = rec.get("pwd_expires_at")
    if exp:
        from datetime import datetime as _dt
        try:
            if _dt.utcnow() > _dt.fromisoformat(exp.replace("Z","")):
                st.error("Sua senha expirou. Use a página 'Trocar Senha'.")
                st.stop()
        except Exception:
            pass
    # 2FA se requerido
    require_2fa = pol.get("auth",{}).get("require_2fa", False)
    if require_2fa and rec.get("totp_secret"):
        code = st.text_input("Código 2FA (TOTP)", value="", max_chars=6)
        if not code:
            st.warning("Informe o código 2FA do seu autenticador.")
            st.stop()
        else:
            from frontend.security_policies import verify_totp
            if not verify_totp(rec, code.strip()):
                add_failed(u, ip); st.error("2FA inválido."); st.stop()
    clear_failed(u, ip)
    from frontend.security_policies import add_session
    add_session(u, ip)
    log_action(u, "login", "user", u, {"result":"success","ip":ip})
    st.success("Login efetuado. (Navegue pelo menu ou abra a página desejada.)")
