from pathlib import Path
import json, time, zipfile, io
from typing import Dict, Any, List

BASE = Path(__file__).resolve().parents[2]
CONF = BASE/"config"/"isoxml_profiles.json"
OUT  = BASE/"data"/"exports"/"isoxml"
OUT.mkdir(parents=True, exist_ok=True)

def load_profiles() -> Dict[str,Any]:
    return json.loads(CONF.read_text(encoding="utf-8"))

def validate_zones(zones: List[dict]) -> List[str]:
    errs = []
    if not isinstance(zones, list) or not zones:
        errs.append("zones vazio ou inválido")
        return errs
    for i,z in enumerate(zones, start=1):
        if "zone_id" not in z: errs.append(f"zones[{i}].zone_id ausente")
        if float(z.get("rate", 0)) <= 0: errs.append(f"zones[{i}].rate deve ser > 0")
        if float(z.get("area_ha", 0)) <= 0: errs.append(f"zones[{i}].area_ha deve ser > 0")
        if not z.get("class"): errs.append(f"zones[{i}].class ausente")
    return errs

def make_taskdata_xml(profile_key: str, job_name: str, culture: str, zones: List[dict]) -> str:
    prof = load_profiles().get(profile_key)
    if not prof: raise ValueError("profile não encontrado")
    # XML minimalista de prescrição ISOXML-like (demonstrativo). Equipamentos reais exigem schema completo.
    lines = []
    lines.append('<?xml version="1.0" encoding="UTF-8"?>')
    lines.append(f'<ISOXML version="{prof.get("version","3.3")}">')
    lines.append(f'  <TASK name="{job_name}" culture="{culture}">')
    for z in zones:
        zid = z.get("zone_id"); rate = z.get("rate"); klass = z.get("class")
        lines.append(f'    <PARTFIELD id="{zid}" class="{klass}" targetRate="{rate}"/>')
    lines.append('  </TASK>')
    lines.append('</ISOXML>')
    return "\n".join(lines)

def export_zip(profile_key: str, job_name: str, culture: str, zones: List[dict]) -> str:
    xml = make_taskdata_xml(profile_key, job_name, culture, zones)
    ts = int(time.time())
    outzip = OUT/f"{ts}_{profile_key}_{job_name.replace(' ','_')}.zip"
    with zipfile.ZipFile(outzip, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("TASKDATA.XML", xml)
    return str(outzip.relative_to(BASE))

def validate_xml(xml_text: str) -> Dict[str,Any]:
    # Validação leve: checa tags básicas e presença de PARTFIELD
    ok = xml_text.strip().startswith("<?xml") and "<ISOXML" in xml_text and "<TASK" in xml_text and "<PARTFIELD" in xml_text
    return {"ok": ok, "checks": ["xml_header","ISOXML_tag","TASK_tag","PARTFIELD_tag"], "len": len(xml_text)}

def make_taskdata_xml_full(profile_key: str, job_name: str, culture: str, zones: List[dict], asap:str="", grd:str="", pln:str="") -> str:
    prof = load_profiles().get(profile_key)
    if not prof: raise ValueError("profile não encontrado")
    lines = []
    lines.append('<?xml version="1.0" encoding="UTF-8"?>')
    lines.append(f'<ISOXML version="{prof.get("version","3.3")}">')
    lines.append(f'  <TASK name="{job_name}" culture="{culture}">')
    if asap: lines.append(f'    <ASAP>{asap}</ASAP>')
    if grd:  lines.append(f'    <GRD>{grd}</GRD>')
    if pln:  lines.append(f'    <PLN>{pln}</PLN>')
    for z in zones:
        zid = z.get("zone_id"); rate = z.get("rate"); klass = z.get("class")
        lines.append(f'    <PARTFIELD id="{zid}" class="{klass}" targetRate="{rate}"/>')
    lines.append('  </TASK>')
    lines.append('</ISOXML>')
    return "\n".join(lines)
