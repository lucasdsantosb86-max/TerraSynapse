def thi(temp_c: float, rh: float):
    # THI clássico para gado leiteiro (NOAA-ish)
    # THI = T - (0.55 - 0.55*RH) * (T - 58); usando RH decimal e T°F; aqui aprox para °C:
    # Equação popular em °C: THI = T - (0.31 - 0.31*RH) * (T - 14.4)
    RH = rh/100.0
    THI = temp_c - (0.31 - 0.31*RH) * (temp_c - 14.4)
    # Faixas
    if THI < 68: level="conforto"
    elif THI < 72: level="alerta"
    elif THI < 79: level="estresse"
    else: level="severo"
    return {"ok": True, "thi": THI, "nivel": level}