#!/usr/bin/env python3
import time, sys, urllib.request
CHECKS = [
  ("backend","http://127.0.0.1:8000/health"),
  ("usuarios","http://127.0.0.1:8501/"),
  ("isoxml_vendor","http://127.0.0.1:8502/"),
  ("isoxml_presets","http://127.0.0.1:8503/"),
  ("summaries","http://127.0.0.1:8504/"),
]
def ok(url):
  try:
    with urllib.request.urlopen(url, timeout=4) as r:
      return 200 <= r.status < 400
  except Exception:
    return False
def main():
  while True:
    bad = [name for name,url in CHECKS if not ok(url)]
    if bad:
      sys.stderr.write("WATCHDOG FALHA: %s\n" % ",".join(bad))
      sys.stderr.flush()
    time.sleep(30)
if __name__ == "__main__":
  main()