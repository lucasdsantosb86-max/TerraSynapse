from pathlib import Path
import datetime as dt, json, os
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from .pdf_watermark import add_watermark
from .pdf_sign import sign_pdf

BASE = Path(__file__).resolve().parents[2]
CONF = BASE/"config"/"security.json"
REP  = BASE/"reports"
REP.mkdir(parents=True, exist_ok=True)

def _conf():
    return json.loads(CONF.read_text(encoding="utf-8"))

def generate_visual_pdf(title: str, body: str, out_name: str = None, user: str = "User"):
    out_name = out_name or f"report_{dt.datetime.utcnow().strftime('%Y%m%dT%H%M%S')}.pdf"
    out = REP/out_name
    # cria pdf
    c = canvas.Canvas(str(out), pagesize=A4)
    c.setTitle(title)
    c.setFont("Helvetica-Bold", 16); c.drawString(40, 800, title)
    c.setFont("Helvetica", 11); y = 770
    for line in body.split("\n"):
        c.drawString(40, y, line); y -= 16
        if y < 60: c.showPage(); y=800
    c.save()

    cfg = _conf()
    # watermark
    if (cfg.get("pdf_watermark") or {}).get("enabled", True):
        text = (cfg["pdf_watermark"].get("text") or "TerraSynapse IA • Confidencial")
        text = text.replace("{user}", user).replace("{ts}", dt.datetime.utcnow().isoformat()+"Z")
        wm_out = out.with_name(out.stem+"_wm.pdf")
        add_watermark(str(out), str(wm_out), text)
        out = wm_out

    # assinatura (se configurada via p12)
    p12 = Path("config/keys/cert.p12")
    if p12.exists() and os.environ.get("TS_P12_PASS"):
        signed = out.with_name(out.stem+"_signed.pdf")
        sign_pdf(str(out), str(signed), str(p12), os.environ["TS_P12_PASS"])
        out = signed

    return {"ok": True, "out": str(out)}