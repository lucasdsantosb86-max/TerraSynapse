
from __future__ import annotations
import numpy as np
try:
    import rasterio
    from rasterio.enums import Resampling
except Exception:
    rasterio = None

S2_BANDS = {
    "B2":"blue", "B3":"green", "B4":"red", "B5":"rededge1", "B6":"rededge2",
    "B7":"rededge3", "B8":"nir", "B8A":"nir_narrow", "B11":"swir1", "B12":"swir2"
}

def _safe_ratio(num, den, eps=1e-6):
    out = (num.astype("float32") - 0.0) / (den.astype("float32") + eps)
    out = np.clip(out, -1.0, 1.0)
    return out

def ndvi_from_arrays(nir: np.ndarray, red: np.ndarray) -> np.ndarray:
    return _safe_ratio(nir - red, nir + red)

def ndre_from_arrays(nir: np.ndarray, rededge: np.ndarray) -> np.ndarray:
    return _safe_ratio(nir - rededge, nir + rededge)

def normalize_band(arr):
    arr = arr.astype("float32")
    if arr.max() > 1.5:
        arr /= max(1.0, arr.max())
    return np.clip(arr, 0, 1)

def ndvi_from_rgb(rgb: np.ndarray) -> np.ndarray:
    r = normalize_band(rgb[...,0]); g = normalize_band(rgb[...,1])
    proxy = _safe_ratio(g - r, g + r)
    return proxy
