import streamlit as st

st.set_page_config(page_title="Admin – Instruções de Integração", page_icon="📘", layout="centered")
st.title("📘 Instruções rápidas – Integrações e Ingest")

st.markdown("""
**1. Auto‑connect por usuário**  
Use a página **33_Admin_Integracoes_Usuario** para habilitar *Auto‑connect* (por usuário).  
Ao salvar uma chave (token/ID/host), a IA testa o provedor automaticamente.

**2. Testes de conexão**  
- `POST /connectors/test` com `{provider, user_id?}` → retorna *ready / missing_keys / error*.

**3. Webhooks externos (ingest)**  
- Envie payloads para `POST /ingest/{provider}/webhook` (jdlink, dji, dronedeploy, sentinelhub).  
- Consulte últimos itens: `GET /ingest/{provider}/list`.

**4. GPS CSV**  
- `POST /ingest/gps` com CSV (**timestamp, lat, lon**) e `tag`.  
- `GET /ingest/gps/metrics?tag=` → km total + **heatmap**.

**Segurança**  
- Chaves ficam no cofre criptografado (Fernet).  
- Ative WAF/reverse proxy e TLS no deploy.
""")