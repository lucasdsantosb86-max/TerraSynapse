from fastapi import APIRouter, Query
from ..services.weather_alerts import check_and_emit

router = APIRouter(prefix="/weather/alerts", tags=["weather"])

@router.get("/check")
def check(lat: float = Query(...), lon: float = Query(...), provider: str = Query(None)):
    return check_and_emit(lat, lon, provider)