from pathlib import Path
import csv, time, json

BASE = Path(__file__).resolve().parents[2]
DATA = BASE/"data"/"gps"
DATA.mkdir(parents=True, exist_ok=True)
CSV = DATA/"logs.csv"

def ingest_row(row: dict):
    fieldnames = ["ts","animal_id","lat","lon","speed","hdop"]
    write_header = not CSV.exists()
    with CSV.open("a", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        if write_header: w.writeheader()
        w.writerow({
            "ts": row.get("ts") or int(time.time()),
            "animal_id": row.get("animal_id","A1"),
            "lat": row.get("lat"),
            "lon": row.get("lon"),
            "speed": row.get("speed", 0),
            "hdop": row.get("hdop", 1.0),
        })
    return {"ok": True}

def ingest_bulk(rows: list):
    for r in rows: ingest_row(r)
    return {"ok": True, "count": len(rows)}