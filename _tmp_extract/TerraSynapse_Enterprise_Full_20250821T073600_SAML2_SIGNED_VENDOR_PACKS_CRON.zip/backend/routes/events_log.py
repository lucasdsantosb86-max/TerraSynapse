from fastapi import APIRouter, Body, Query
from pathlib import Path
import json
from ..services.events_log import read_logs, resend

BASE = Path(__file__).resolve().parents[2]
WEBH = BASE/"config"/"webhooks.json"

router = APIRouter(prefix="/events", tags=["events-logs"])

@router.get("/logs")
def logs(start: str = Query(None), end: str = Query(None), limit: int = Query(200)):
    return read_logs(start, end, limit)

@router.post("/logs/resend")
def logs_resend(events: list = Body(...)):
    cfg = json.loads(WEBH.read_text(encoding="utf-8")) if WEBH.exists() else {"urls": {}}
    return resend(events, cfg)