import streamlit as st, requests, os, json, pandas as pd

st.set_page_config(page_title="KPIs – Leite & Bem-Estar", page_icon="🥛", layout="wide")
st.title("🥛 KPIs – Leite & Bem-Estar (Afimilk / DeLaval / CowManager)")

api = st.text_input("Backend URL", value=os.getenv("TS_BACKEND_URL","http://localhost:8000"))

c1, c2 = st.columns(2)
with c1:
    st.subheader("Resumo atual")
    k = requests.get(f"{api}/dairy/kpis").json()
    st.json(k)
    if k.get("ok"):
        kp = k["kpis"]
        st.metric("Leite médio (L/vaca/dia)", f"{kp.get('milk_avg_l') or 0:.2f}")
        st.metric("Ruminação média (min/dia)", f"{kp.get('rumination_avg_min') or 0:.0f}")
        st.metric("CCS média (mil células/ml)", f"{(kp.get('ccs_avg') or 0)/1000:.0f}")
with c2:
    st.subheader("THI (estresse térmico)")
    t = st.number_input("Temperatura (°C)", 0.0, 60.0, 30.0)
    rh = st.number_input("Umidade Relativa (%)", 0.0, 100.0, 60.0)
    j = requests.get(f"{api}/zootec/thi", params={"temp_c": t, "rh": rh}).json()
    st.json(j)

st.markdown("---")
st.subheader("Alertas")
ja = requests.get(f"{api}/dairy/alerts/check").json()
st.json(ja)

# (Opcional) Simples gráfico com histórico se houver (usa arquivos em data/ingest/dairy)
try:
    import glob, json, pandas as pd, os
    base = os.path.abspath(os.path.join(os.getcwd(), "data/ingest/dairy"))
    rows = []
    for prov in ["afimilk","delaval","cowmanager"]:
        p = os.path.join(base, prov)
        if os.path.exists(p):
            for fp in sorted(glob.glob(os.path.join(p, "*.json")))[-50:]:
                with open(fp, "r", encoding="utf-8") as f:
                    d = json.load(f); d["_provider"]=prov; rows.append(d)
    if rows:
        df = pd.DataFrame(rows)
        for col in [c for c in ["milk_l","rumination_min","ccs","heat_index"] if c in df.columns]:
            st.line_chart(df[[col]])
except Exception as e:
    st.info("Sem histórico suficiente para gráficos.")