import streamlit as st, requests, os

st.set_page_config(page_title="Sincronização de Máquinas – JDLink (Simplificada)", page_icon="🚜", layout="wide")
st.title("🚜 Sincronização JDLink – Simplificada por Usuário")

api = st.text_input("Backend URL", value=os.getenv("TS_BACKEND_URL","http://localhost:8000"))
user_id = st.text_input("User ID (e-mail)", "lucas@empresa.com")

st.subheader("1) Testar conexão (tokens no cofre)")
if st.button("Testar JDLink para este usuário"):
    j = requests.get(f"{api}/jdlink/test", params={"user_id": user_id}).json()
    st.json(j)
    if not j.get("ok"):
        st.warning("Sem token. Abra a tela 'Conectar JDLink' e salve os tokens para este usuário.")

st.subheader("2) Ativar Sincronização Simplificada")
c1,c2 = st.columns(2)
enabled = c1.checkbox("Ativar sync automático", value=True)
interval = c2.number_input("Intervalo sugerido (min)", 5, 1440, 60)
if st.button("Salvar preferências de sync"):
    j = requests.post(f"{api}/jdlink/sync/set", json={"user_id": user_id, "enabled": enabled, "interval_min": int(interval)}).json()
    st.json(j)

st.subheader("3) Buscar operações agora (Fetch Now)")
if st.button("Buscar operações imediatamente"):
    j = requests.post(f"{api}/jdlink/operations/fetch_now", json={"user_id": user_id}).json()
    st.json(j)

st.subheader("4) Operações recentes")
j = requests.get(f"{api}/jdlink/operations/recent", params={"limit": 10}).json()
st.json(j)