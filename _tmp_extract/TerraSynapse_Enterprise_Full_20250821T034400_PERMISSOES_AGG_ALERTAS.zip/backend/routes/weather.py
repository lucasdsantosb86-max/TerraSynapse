from fastapi import APIRouter, Query
from ..services.weather import WeatherProvider

router = APIRouter(prefix="/weather", tags=["weather"])

@router.get("/forecast")
def forecast(lat: float = Query(...), lon: float = Query(...), provider: str = Query("openweather")):
    return WeatherProvider(provider).forecast(lat, lon)