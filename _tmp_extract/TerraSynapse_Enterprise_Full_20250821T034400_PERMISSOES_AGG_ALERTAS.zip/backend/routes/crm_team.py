from fastapi import APIRouter, Body
from ..services.crm_team import list_team, get_member, create_member, update_member, delete_member

router = APIRouter(prefix="/crm/team", tags=["crm-team"])

@router.get("")
def all():
    return {"ok": True, "items": list_team()}

@router.get("/{mid}")
def one(mid: str):
    m = get_member(mid)
    return {"ok": bool(m), "item": m}

@router.post("")
def create(obj: dict = Body(...)):
    return {"ok": True, "item": create_member(obj)}

@router.put("/{mid}")
def upd(mid: str, patch: dict = Body(...)):
    return {"ok": True, "item": update_member(mid, patch)}

@router.delete("/{mid}")
def rem(mid: str):
    return {"ok": True, **delete_member(mid)}