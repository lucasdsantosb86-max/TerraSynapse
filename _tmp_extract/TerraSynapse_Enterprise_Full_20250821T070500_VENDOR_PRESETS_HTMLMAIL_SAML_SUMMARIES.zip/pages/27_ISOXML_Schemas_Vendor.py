import streamlit as st, requests, os

st.set_page_config(page_title="ISOXML – Schemas do Fabricante", page_icon="🏭", layout="wide")
st.title("🏭 ISOXML – Schemas do Fabricante (upload & validar)")

api = st.text_input("Backend URL", value=os.getenv("TS_BACKEND_URL","http://localhost:8000"))
user_id = st.text_input("Seu e-mail (para permissões)", "lucas@empresa.com")

# Guard
import requests as rq
role_api = api + "/auth/role"
_res = rq.get(role_api, params={"user_id": user_id}).json()
_user_role = (_res.get("role") or "visitante").lower()
_allowed = {"gestor","integrador","engenheiro"}
if _user_role not in _allowed:
    st.error(f"Acesso restrito. Seu papel: '{_user_role}'. Permitidos: {', '.join(_allowed)}")
    st.stop()

st.subheader("Schemas disponíveis")
st.json(requests.get(f"{api}/isoxml/vendor/list").json())

st.subheader("Upload de XSD (colar conteúdo)")
vendor = st.text_input("Nome do fabricante (ex.: deere_3_3)", "deere_3_3")
xsd = st.text_area("Conteúdo do XSD", height=220)
if st.button("Salvar XSD do fabricante"):
    st.json(requests.post(f"{api}/isoxml/vendor/set", params={"vendor": vendor}, json={"xsd_text": xsd}).json())

st.subheader("Validar XML com XSD do fabricante")
vendor_v = st.text_input("Fabricante para validar", "deere_3_3")
xml = st.text_area("Cole o TASKDATA.XML", height=220)
if st.button("Validar Vendor XSD"):
    st.json(requests.post(f"{api}/isoxml/vendor/validate", params={"vendor": vendor_v}, json={"xml_text": xml}).json())