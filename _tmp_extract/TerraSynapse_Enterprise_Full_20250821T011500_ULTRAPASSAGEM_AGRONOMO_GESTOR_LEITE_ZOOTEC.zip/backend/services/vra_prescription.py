from pathlib import Path
import json, csv, zipfile, io, math
import shapefile  # pyshp

BASE = Path(__file__).resolve().parents[2]
OUT  = BASE/"data"/"public"
OUT.mkdir(parents=True, exist_ok=True)

def _ensure_list(v):
    return v if isinstance(v, list) else [v]

def write_csv(zones, name):
    fp = OUT/f"{name}.csv"
    with fp.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["zone_id","rate","unit"])
        for z in zones:
            w.writerow([z.get("zone_id"), z.get("rate"), z.get("unit","kg_ha")])
    return fp

def write_shp(polygons, name):
    # polygons: list of {"coords":[[x,y],...], "zone_id":.., "rate":.., "unit":..}
    shp = OUT/f"{name}.shp"
    shx = OUT/f"{name}.shx"
    dbf = OUT/f"{name}.dbf"
    w = shapefile.Writer(str(shp))
    w.autoBalance = 1
    w.field("zone_id","C")
    w.field("rate","F", decimal=3)
    w.field("unit","C")
    for p in polygons:
        coords = p.get("coords")  # [[x,y],...]
        if not coords: 
            continue
        w.poly([coords])
        w.record(str(p.get("zone_id")), float(p.get("rate",0.0)), p.get("unit","kg_ha"))
    w.close()
    return shp  # retorna .shp; os outros acompanham no diretório

def write_isoxml(zones, name):
    # Gera pacote ISOXML mínimo (TASKDATA.XML + tratamento simplificado de taxa por zona)
    pkg = OUT/f"{name}_ISOXML.zip"
    taskdata = f'''<?xml version="1.0" encoding="UTF-8"?>
<TASKDATA VERSION="3.4">
  <PFD A="TS_{name}" FID="1"/>
  <PDV ID="1" A="TS_{name}_VRA"/>
  <TSK A="Prescription {name}" TSKID="1" PFD="1">
    <PDT A="RateTable" PDVID="1">
      {''.join([f'<PTN A="Z{z.get("zone_id")}" RT="{z.get("rate")}" U="{z.get("unit","kg_ha")}"/>' for z in zones])}
    </PDT>
  </TSK>
</TASKDATA>'''.strip()
    with zipfile.ZipFile(pkg, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("TASKDATA.XML", taskdata)
    return pkg

def generate(payload: dict):
    # payload: {"name": "talhao123", "zones":[{"zone_id":1,"rate":160,"unit":"kg_ha"},...], "format":"csv|shp|isoxml", "polygons":[{"coords":[[x,y],...]...}] }
    name = payload.get("name","prescricao")
    fmt  = (payload.get("format") or "csv").lower()
    zones = _ensure_list(payload.get("zones", []))
    polys = _ensure_list(payload.get("polygons", []))

    if fmt == "csv":
        fp = write_csv(zones, name)
        return {"ok": True, "format":"csv", "path": f"data/public/{fp.name}"}
    elif fmt == "shp":
        if not polys:
            # fallback: cria quadrados fictícios por zona
            polys = []
            for i,z in enumerate(zones):
                x0 = i*0.001
                polys.append({"coords":[[x0,0],[x0+0.0009,0],[x0+0.0009,0.0009],[x0,0.0009],[x0,0]], "zone_id":z.get("zone_id"), "rate":z.get("rate"), "unit":z.get("unit","kg_ha")})
        shp = write_shp(polys, name)
        return {"ok": True, "format":"shp", "path": f"data/public/{shp.name}"}
    elif fmt == "isoxml":
        pkg = write_isoxml(zones, name)
        return {"ok": True, "format":"isoxml", "path": f"data/public/{pkg.name}"}
    else:
        return {"ok": False, "error":"format_not_supported"}