from fastapi import APIRouter, Body
from ..services.fertilizer_alerts import check_variation

router = APIRouter(prefix="/alerts/fertilizer", tags=["alerts"])

@router.post("/check")
def check(file_csv: str = Body(...), column: str = Body(...), window: int = Body(3), threshold_pct: float = Body(10.0)):
    return check_variation(file_csv, column, window, threshold_pct)