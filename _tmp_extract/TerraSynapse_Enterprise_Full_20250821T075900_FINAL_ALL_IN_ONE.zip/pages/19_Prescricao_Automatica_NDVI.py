import streamlit as st, requests, os, json

st.set_page_config(page_title="Prescrição Automática por NDVI", page_icon="🗺️", layout="wide")
st.title("🗺️ Prescrição Automática por NDVI → VRA")

api = st.text_input("Backend URL", value=os.getenv("TS_BACKEND_URL","http://localhost:8000"))
name = st.text_input("Nome da prescrição", "talhao_ndvi_vra")
fmt  = st.selectbox("Formato", ["csv","shp","isoxml"])

st.subheader("NDVI → Zonas")
area = st.number_input("Área total (ha)", 0.0, 1e7, 50.0)
th   = st.text_input("Thresholds (JSON)", "[0.33,0.66]")
ymap = st.text_input("Yield map (JSON)", "{"low":0.9,"mid":1.0,"high":1.1}")
rates = st.text_input("Taxas por classe (JSON)", "{"low":120,"mid":150,"high":180}")
file = st.file_uploader("NDVI (GeoTIFF) ou imagem RGB", type=["tif","tiff","png","jpg","jpeg"])

if st.button("Gerar Prescrição"):
    if not file: st.error("Envie o arquivo NDVI/RGB.")
    else:
        files={"ndvi_file": (file.name, file.getvalue(), file.type or "application/octet-stream")}
        data={"thresholds": th, "yield_map": ymap, "area_ha": area}
        seg = requests.post(f"{api}/ndvi/segment", files=files, data=data).json()
        st.json(seg)
        if seg.get("ok"):
            cl_rates = json.loads(rates)
            zones = seg["zones"]
            # monta zonas para prescrição
            zlist = [{"zone_id": z["zone_id"], "rate": cl_rates.get(z["class"], 150), "unit":"kg_ha"} for z in zones]
            j = requests.post(f"{api}/vra/generate", json={"name": name, "format": fmt, "zones": zlist}).json()
            st.subheader("Arquivo")
            st.json(j)
            if j.get("ok"):
                st.markdown(f"[Baixar]({api.rstrip('/')}/{j['path']})")