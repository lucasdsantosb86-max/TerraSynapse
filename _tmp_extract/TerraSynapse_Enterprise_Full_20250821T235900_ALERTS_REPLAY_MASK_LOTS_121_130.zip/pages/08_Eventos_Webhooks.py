import streamlit as st, requests, json

st.set_page_config(page_title="Eventos & Webhooks", page_icon="🔔")
st.title("🔔 Eventos & Webhooks")

backend = st.text_input("Backend URL", value="http://localhost:8000")

st.subheader("Cadastrar webhook")
url = st.text_input("URL do webhook")
event = st.selectbox("Evento", ["custo/limite","premium/queda","fertilizante/var","gps/alerta"])
if st.button("Adicionar"):
    try:
        r = requests.post(f"{backend}/webhooks", json={"url": url, "event": event}, timeout=10).json()
        st.success(r)
    except Exception as e:
        st.error(e)

st.subheader("Listar/remover")
if st.button("Listar"):
    try:
        st.write(requests.get(f"{backend}/webhooks", timeout=10).json())
    except Exception as e:
        st.error(e)

del_url = st.text_input("URL para remover")
del_event = st.text_input("Evento para remover")
if st.button("Remover"):
    try:
        r = requests.delete(f"{backend}/webhooks", json={"url": del_url, "event": del_event}, timeout=10).json()
        st.success(r)
    except Exception as e:
        st.error(e)

st.subheader("Emitir teste")
test_event = st.selectbox("Evento teste", ["custo/limite","premium/queda","fertilizante/var","gps/alerta"], index=0)
payload = st.text_area("Payload (JSON)", value='{"hello":"world"}')
if st.button("Emitir"):
    try:
        pj = json.loads(payload or "{}")
        r = requests.post(f"{backend}/webhooks/emit", json={"event": test_event, "payload": pj}, timeout=10).json()
        st.success(r)
    except Exception as e:
        st.error(e)