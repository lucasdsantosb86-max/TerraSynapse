import streamlit as st, json, os, requests
from pathlib import Path

st.set_page_config(page_title="Gerenciar Usuários", page_icon="👥", layout="wide")
st.title("👥 Gerenciar Usuários")

api = st.text_input("Backend URL", value=os.getenv("TS_BACKEND_URL","http://localhost:8000"))
admin = st.text_input("Seu e-mail (para permissões)", "lucas@empresa.com")

# Guard
import requests as rq
role_api = api + "/auth/role"
_res = rq.get(role_api, params={"user_id": admin}).json()
_user_role = (_res.get("role") or "visitante").lower()
_allowed = {"gestor","integrador","engenheiro","developer"}
if _user_role not in _allowed:
    st.error(f"Acesso restrito. Seu papel: '{_user_role}'. Permitidos: {', '.join(_allowed)}")
    st.stop()

st.subheader("Criar usuário")
with st.form("create"):
    email = st.text_input("E-mail")
    pwd = st.text_input("Senha", type="password")
    role = st.selectbox("Papel", ["visitante","tecnico","engenheiro","gestor","integrador","developer"])
    if st.form_submit_button("Criar"):
        st.json(requests.post(f"{api}/auth/password/create", json={"email": email, "password": pwd, "role": role}).json())

st.subheader("Trocar papel de usuário")
with st.form("role"):
    email2 = st.text_input("E-mail do usuário")
    role2 = st.selectbox("Novo papel", ["visitante","tecnico","engenheiro","gestor","integrador","developer"])
    if st.form_submit_button("Salvar papel"):
        st.json(requests.post(f"{api}/auth/password/create", json={"email": email2, "password": "PLACEHOLDER", "role": role2}).json())
        st.info("Se o usuário já existia, apenas o papel foi atualizado.")