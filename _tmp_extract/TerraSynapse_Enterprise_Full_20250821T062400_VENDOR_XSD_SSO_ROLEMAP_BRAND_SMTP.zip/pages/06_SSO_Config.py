import streamlit as st, requests, os, json

st.set_page_config(page_title="SSO Corporativo (OIDC)", page_icon="🔐", layout="wide")
st.title("🔐 SSO Corporativo – OIDC (Azure AD/Keycloak/Google)")

api = st.text_input("Backend URL", value=os.getenv("TS_BACKEND_URL","http://localhost:8000"))
user_id = st.text_input("Seu e-mail (para permissões)", "lucas@empresa.com")

st.subheader("Provedores atuais")
st.json(requests.get(f"{api}/sso/oidc/providers").json())

st.subheader("Definir provedores (JSON)")
cfg = st.text_area("Cole o JSON de auth_providers.json", value=json.dumps({
    "providers": [
        {"name":"example-azure-ad","type":"oidc","client_id":"","client_secret":"","auth_url":"","token_url":"","userinfo_url":"","redirect_uri":"http://localhost:8000/sso/oidc/callback"}
    ]
}, indent=2))
if st.button("Salvar provedores"):
    try:
        payload = json.loads(cfg)
        st.json(requests.post(f"{api}/sso/oidc/providers/set", json=payload).json())
    except Exception as e:
        st.error(f"JSON inválido: {e}")

st.subheader("Iniciar Login (gera URL)")
prov = st.text_input("Nome do provider", "example-azure-ad")
if st.button("Gerar URL de login"):
    st.json(requests.get(f"{api}/sso/oidc/start", params={"provider": prov, "user_id": user_id}).json())

import requests as rq, os
role_api = os.getenv("TS_BACKEND_URL","http://localhost:8000") + "/auth/role"
_res = rq.get(role_api, params={"user_id": user_id}).json()
_user_role = (_res.get("role") or "visitante").lower()
_allowed = set(['gestor', 'integrador', 'engenheiro'])
if _user_role not in _allowed:
    import streamlit as st
    st.error(f"Acesso restrito. Seu papel: '{_user_role}'. Permitidos: {', '.join(_allowed)}"); st.stop()
