
from __future__ import annotations
import streamlit as st, json
from pathlib import Path
from frontend.auth import require
from frontend.audit import log_action

st.set_page_config(page_title="Admin – Permissões (Roles)", page_icon="🛡️", layout="wide")
user = require(roles=("developer","gestor"))

ROLES_PATH = Path("data/users/roles.json")

def load_roles():
    try:
        return json.loads(ROLES_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}

def save_roles(d):
    ROLES_PATH.write_text(json.dumps(d, indent=2, ensure_ascii=False), encoding="utf-8")

st.title("🛡️ Gerenciar Permissões (roles.json)")

roles = load_roles()
col1, col2 = st.columns([1,2])

with col1:
    st.subheader("➕ Criar novo papel")
    rname = st.text_input("Nome do papel (ex.: analista)")
    rdesc = st.text_input("Descrição")
    rperms = st.text_area("Permissões (uma por linha)", value="vision.use")
    if st.button("Criar papel"):
        if not rname.strip():
            st.error("Informe um nome.")
        elif rname in roles:
            st.warning("Papel já existe.")
        else:
            perms = [p.strip() for p in rperms.splitlines() if p.strip()]
            roles[rname] = {"description": rdesc, "permissions": perms}
            save_roles(roles)
            log_action(user['username'], 'create','role', rname, {'permissions':perms});
            st.success(f"Papel '{rname}' criado. Reabra a página para ver na lista.")

with col2:
    st.subheader("🗂️ Papéis existentes")
    if not roles:
        st.info("Nenhum papel definido.")
    else:
        for name, spec in roles.items():
            with st.expander(f"{name} — {spec.get('description','')}"):
                desc = st.text_input("Descrição", spec.get("description",""), key=f"d_{name}")
                perms_txt = "\n".join(spec.get("permissions", []))
                perms = st.text_area("Permissões (uma por linha)", value=perms_txt, key=f"p_{name}")
                c1, c2 = st.columns(2)
                with c1:
                    if st.button("Salvar alterações", key=f"s_{name}"):
                        roles[name]["description"] = desc
                        roles[name]["permissions"] = [p.strip() for p in perms.splitlines() if p.strip()]
                        save_roles(roles)
                        log_action(user['username'], 'update','role', name, {'permissions':roles[name]['permissions']});
                        st.success("Alterações salvas.")
                with c2:
                    danger = st.checkbox("Confirmar exclusão", key=f"x_{name}")
                    if st.button("Excluir papel", key=f"del_{name}"):
                        if name in ("developer","gestor","tecnico","visitante"):
                            st.error("Por segurança, esses papéis padrão não podem ser excluídos.")
                        elif not danger:
                            st.error("Marque a confirmação para excluir.")
                        else:
                            roles.pop(name, None)
                            save_roles(roles)
                            log_action(user['username'], 'delete','role', name, {});
                            st.success("Papel excluído. Atualize a página.")
