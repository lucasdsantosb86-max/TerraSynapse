import pandas as pd
from pathlib import Path
def pivot_bench(src_path: str, out_path: str):
    df = pd.read_csv(src_path)
    # simples: média por microregião/cultura
    grp = df.groupby(["country","state","microregion","culture"], as_index=False)["yield_kg_ha"].mean().rename(columns={"yield_kg_ha":"avg_yield_kg_ha"})
    grp.to_csv(out_path, index=False)
    return {"ok": True, "rows": len(grp), "out": out_path}