import streamlit as st
import requests, os

st.set_page_config(page_title="Admin – Scheduler", page_icon="🕒", layout="wide")
st.title("🕒 Admin – Scheduler de Custos")

api = st.text_input("Backend URL", value=os.getenv("TS_BACKEND_URL","http://localhost:8000"))
col1, col2, col3, col4 = st.columns(4)
if col1.button("Start"): st.write(requests.post(f"{api}/admin/scheduler/start").json())
if col2.button("Stop"): st.write(requests.post(f"{api}/admin/scheduler/stop").json())
if col3.button("Run Once"): st.write(requests.post(f"{api}/admin/scheduler/run_once").json())
if col4.button("Status"): st.write(requests.get(f"{api}/admin/scheduler/status").json())
st.caption("Config editável em config/scheduler.json")