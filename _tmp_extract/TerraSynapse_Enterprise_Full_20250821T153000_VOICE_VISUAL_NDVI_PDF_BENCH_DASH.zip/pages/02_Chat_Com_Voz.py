import streamlit as st
import io, json

st.set_page_config(page_title="Chat • Voz Offline", page_icon="🎤")
st.title("🎤 Chat com Voz (Offline STT/TTS)")

st.info("Para STT offline, adicione um modelo Vosk PT-BR em 'data/vosk/model-pt'. Para TTS, o sistema usa pyttsx3 local.")

# Entrada por texto (fallback)
msg = st.text_area("Mensagem (ou envie áudio abaixo):", height=120)

# Upload de áudio (gravação externa ou com plugin)
audio_file = st.file_uploader("Enviar áudio (.wav)", type=["wav"])

# STT com Vosk (se modelo estiver presente)
def transcribe_wav(file):
    try:
        import wave, json
        import vosk
        from pathlib import Path
        model_path = Path(__file__).resolve().parents[1]/"data"/"vosk"/"model-pt"
        if not model_path.exists():
            st.warning("Modelo Vosk não encontrado em data/vosk/model-pt. Usando apenas texto.")
            return None
        wf = wave.open(file, "rb")
        if wf.getnchannels() != 1 or wf.getsampwidth() != 2 or wf.getframerate() not in [8000,16000,32000,44100,48000]:
            st.warning("Converta para WAV mono 16‑bit (8–48 kHz).")
            return None
        rec = vosk.KaldiRecognizer(vosk.Model(str(model_path)), wf.getframerate())
        rec.SetWords(True)
        text = []
        while True:
            data = wf.readframes(4000)
            if len(data) == 0: break
            if rec.AcceptWaveform(data):
                res = json.loads(rec.Result())
                text.append(res.get("text",""))
        res = json.loads(rec.FinalResult())
        text.append(res.get("text",""))
        return " ".join([t for t in text if t]).strip()
    except Exception as e:
        st.error(f"Erro STT: {e}")
        return None

if audio_file is not None and st.button("🗣️ Transcrever Áudio"):
    txt = transcribe_wav(audio_file)
    if txt:
        st.success(f"Transcrição: {txt}")
        msg = txt

# Simulação de resposta (plugue seu endpoint de chat aqui)
backend_chat = st.text_input("Endpoint de Chat (opcional)", value="")
if st.button("Enviar"):
    if backend_chat:
        import requests
        try:
            r = requests.post(backend_chat, json={"message": msg}, timeout=30).json()
            st.session_state["resp"] = r.get("answer","(sem resposta do backend)")
        except Exception as e:
            st.session_state["resp"] = f"[erro] {e}"
    else:
        st.session_state["resp"] = f"(eco) {msg}"

if "resp" in st.session_state:
    st.subheader("Resposta")
    st.write(st.session_state["resp"])

    if st.button("🔊 Falar resposta"):
        try:
            import pyttsx3, tempfile, os
            engine = pyttsx3.init()
            engine.setProperty('rate', 170)
            engine.setProperty('volume', 0.9)
            # Salva em WAV temporário e oferece download (execução local fala direto)
            with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as tf:
                engine.save_to_file(st.session_state["resp"], tf.name)
                engine.runAndWait()
                data = open(tf.name, "rb").read()
                st.audio(data, format="audio/wav")
                os.unlink(tf.name)
        except Exception as e:
            st.error(f"TTS indisponível: {e}")