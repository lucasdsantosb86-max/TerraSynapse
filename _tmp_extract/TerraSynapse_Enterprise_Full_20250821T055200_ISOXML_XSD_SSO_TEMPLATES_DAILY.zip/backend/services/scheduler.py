from pathlib import Path
import json, time, threading, traceback
from typing import Dict, Any
from .jdlink_ops import fetch_now, _load_cfg, _save_cfg
from .daily_summary import generate_summary
from .notifier import send_all
from .quality import check_now as quality_check
from .disconnection import check_and_alert

BASE = Path(__file__).resolve().parents[2]
CFG  = BASE/"config"/"jdlink_sync.json"

_running_flag = False
_thread = None

def _tick_once():
    cfg = _load_cfg()  # {user_id: {enabled, interval_min, updated_ts, last_run_ts?}}
    now = int(time.time())
    changed = False
    for uid, st in cfg.items():
        if not st.get("enabled"):
            continue
        interval = int(st.get("interval_min") or 60) * 60
        last = int(st.get("last_run_ts") or 0)
        if now - last >= interval:
            try:
                # executa coleta
                r = fetch_now(uid)
                # atualiza last_run
                cfg[uid]["last_run_ts"] = now
                cfg[uid]["last_result"] = {"ok": r.get("ok", False), "count": r.get("count", 0), "ts": now}
                changed = True
            except Exception as e:
                cfg[uid]["last_result"] = {"ok": False, "error": str(e), "ts": now}
                changed = True
    if changed:
        _save_cfg(cfg)
    return cfg

def _loop(interval_base=60):
    _last_alert_ts = 0
    _last_quality_ts = 0
    _last_daily_ts = 0
    global _running_flag
    while _running_flag:
        try:
            _tick_once()
            # resumo diário (1x/dia)
            import time as _t
            if int(_t.time()/86400) != int(_last_daily_ts/86400):
                try:
                    res = generate_summary()
                    send_all({"type":"daily_summary","files":[res.get('csv'), res.get('pdf')]})
                finally:
                    _last_daily_ts = _t.time()
            # a cada 10 minutos, roda verificação de desconexão
            import time as _t
            if _t.time() - _last_alert_ts >= 600:
                try:
                    check_and_alert()
                finally:
                    _last_alert_ts = _t.time()
            # a cada 15 minutos, roda verificação de qualidade operacional
            if _t.time() - _last_quality_ts >= 900:
                try:
                    quality_check()
                finally:
                    _last_quality_ts = _t.time()
        except Exception:
            traceback.print_exc()
        time.sleep(interval_base)  # roda a cada 60s

def start_scheduler():
    global _running_flag, _thread
    if _running_flag:
        return {"ok": True, "status":"already_running"}
    _running_flag = True
    _thread = threading.Thread(target=_loop, kwargs={"interval_base":60}, daemon=True)
    _thread.start()
    return {"ok": True, "status":"started"}

def stop_scheduler():
    global _running_flag, _thread
    _running_flag = False
    return {"ok": True, "status":"stopping"}

def status():
    cfg = _load_cfg()
    return {"ok": True, "items": cfg}