
from __future__ import annotations
import json, time, datetime as dt
from pathlib import Path
ALERTS_DIR = Path("data/alerts"); ALERTS_DIR.mkdir(parents=True, exist_ok=True)
RULES_PATH = Path("data/config/alert_rules.json")
DEFAULT_RULES = {"humidity_min_pct": 30, "wind_max_kmh": 60, "frost_risk_c": 2.0, "offline_grace_s": 20}
def load_rules():
    if RULES_PATH.exists():
        return json.loads(RULES_PATH.read_text(encoding="utf-8"))
    return DEFAULT_RULES
def record_alert(kind: str, message: str, meta: dict|None=None):
    rec = {"ts": dt.datetime.utcnow().isoformat(), "kind": kind, "message": message, "meta": meta or {}}
    with (ALERTS_DIR/"alerts.jsonl").open("a", encoding="utf-8") as f:
        f.write(json.dumps(rec, ensure_ascii=False)+"\n")
    return rec
def apply_sensor_rules(rows: list[dict]):
    rules = load_rules(); out = []
    for r in rows:
        if "humidity" in r and r["humidity"] < rules["humidity_min_pct"]:
            out.append(record_alert("low_humidity", f"Umidade baixa: {r['humidity']}%", {"row": r}))
        if "wind_kmh" in r and r["wind_kmh"] > rules["wind_max_kmh"]:
            out.append(record_alert("high_wind", f"Vento forte: {r['wind_kmh']} km/h", {"row": r}))
        if "temp_c" in r and r["temp_c"] <= rules["frost_risk_c"]:
            out.append(record_alert("frost_risk", f"Risco de geada: {r['temp_c']}°C", {"row": r}))
    return out
_LAST_PING = 0.0
def check_connectivity(ping_ok: bool):
    global _LAST_PING; import time
    now = time.time()
    if ping_ok:
        _LAST_PING = now; return None
    rules = load_rules()
    if now - _LAST_PING > rules["offline_grace_s"]:
        return record_alert("disconnect", "Sistema offline detectado pela Home.", {})
    return None
