from fastapi import APIRouter, Query
from ..services.weather_provider import WeatherClient

router = APIRouter(prefix="/weather", tags=["weather"])

@router.get("/current")
def current_weather():
    return WeatherClient().current()

@router.post("/climatempo/register")
def climatempo_register(locale_id: int = Query(..., description="ID da cidade no ClimaTempo")):
    return WeatherClient().climatempo_register_locale(locale_id)