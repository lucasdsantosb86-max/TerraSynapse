from fastapi import APIRouter, Body
from ..services.secrets import set_secret_user
from ..services.user_integrations import on_secret_saved

router = APIRouter(prefix="/secrets", tags=["secrets-user-hook"])

@router.post("/user/set_autoconnect")
def set_user_and_connect(user_id: str = Body(...), provider: str = Body(...), key: str = Body(...), value: str = Body(...)):
    set_secret_user(user_id, provider, key, value)
    res = on_secret_saved(user_id, provider)
    return {"ok": True, "auto_connect_result": res}