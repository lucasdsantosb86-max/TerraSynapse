import smtplib, ssl, mimetypes
from email.message import EmailMessage
from pathlib import Path
from .secrets_store import save_secret, load_secret

BASE = Path(__file__).resolve().parents[2]

def set_smtp(cfg: dict):
    # cfg: host, port, user, password, use_tls
    return save_secret("smtp", cfg)

def _smtp_cfg():
    r = load_secret("smtp")
    if not r.get("ok"):
        return None
    return r.get("data")

def send_email(to: list, subject: str, text: str, attachments: list = None, html: str = None):
    cfg = _smtp_cfg()
    if not cfg:
        return {"ok": False, "error":"smtp_not_configured"}
    msg = EmailMessage()
    msg["From"] = cfg.get("user")
    msg["To"] = ", ".join(to)
    msg["Subject"] = subject
    msg.set_content(text or "")
    if html:
        msg.add_alternative(html, subtype="html")
    for p in (attachments or []):
        fp = BASE/p
        if not fp.exists(): 
            continue
        ctype, _ = mimetypes.guess_type(str(fp))
        maintype, subtype = (ctype or "application/octet-stream").split("/",1)
        msg.add_attachment(fp.read_bytes(), maintype=maintype, subtype=subtype, filename=fp.name)
    context = ssl.create_default_context()
    if cfg.get("use_tls", True):
        with smtplib.SMTP_SSL(cfg.get("host"), int(cfg.get("port"))) as s:
            s.login(cfg.get("user"), cfg.get("password"))
            s.send_message(msg)
    else:
        with smtplib.SMTP(cfg.get("host"), int(cfg.get("port"))) as s:
            s.starttls(context=context)
            s.login(cfg.get("user"), cfg.get("password"))
            s.send_message(msg)
    return {"ok": True}