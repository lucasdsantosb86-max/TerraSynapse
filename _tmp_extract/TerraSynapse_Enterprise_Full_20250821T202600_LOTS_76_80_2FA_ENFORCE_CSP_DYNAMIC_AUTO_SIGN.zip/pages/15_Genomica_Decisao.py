import streamlit as st, pandas as pd, tempfile
from backend.services.genomics import rank_animals, mating_plan

st.set_page_config(page_title="Genômica – Decisão", page_icon="🧬")
st.title("🧬 Genômica – Decisão (ranking e acasalamento)")

st.caption("Envie um CSV com colunas: ID, Sexo (M/F), e GEBVs (ex.: Leite, Gordura, Proteina, Fertilidade, etc.)")

csv = st.file_uploader("CSV de animais (GEBV/EPD)", type=["csv"])
weights_default = {"Leite": 1.0, "GanhoMedio": 0.8, "Fertilidade": 0.7, "Longevidade": 0.5}
w = st.text_input("Pesos (JSON)", value=str(weights_default))
if csv and st.button("Rankear"):
    import ast
    weights = ast.literal_eval(w) if w else {}
    with tempfile.NamedTemporaryFile(delete=False, suffix=".csv") as tf:
        tf.write(csv.read()); tf.flush()
        df = rank_animals(tf.name, weights)
    st.dataframe(df.head(50))
    if st.button("Plano de acasalamento (top pares)"):
        plan = mating_plan(tf.name, weights, max_pairs=30, min_rel=0.125)  # ex.: evitar >12.5%
        st.dataframe(plan)
        st.download_button("Baixar pares (CSV)", data=plan.to_csv(index=False), file_name="mating_plan.csv", mime="text/csv")