from fastapi import APIRouter, Body
from ..services.profitability_zoned import calc_profit_zoned

router = APIRouter(prefix="/profit", tags=["profitability"])

@router.post("/calc_zoned")
def calc_zoned(culture: str, price_per_t: float, yield_t_ha: float, zones: list = Body(...)):
    return calc_profit_zoned(culture, price_per_t, yield_t_ha, zones)