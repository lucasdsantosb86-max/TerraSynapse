from fastapi import APIRouter, Body, Query
from ..services.jdlink_ops import set_sync, get_sync_status, fetch_now, list_recent

router = APIRouter(prefix="/jdlink", tags=["jdlink-ops"])

@router.post("/sync/set")
def sync_set(user_id: str = Body(...), enabled: bool = Body(...), interval_min: int = Body(60)):
    return set_sync(user_id, enabled, interval_min)

@router.get("/sync/status")
def sync_status(user_id: str = Query(...)):
    return get_sync_status(user_id)

@router.post("/operations/fetch_now")
def fetch(user_id: str = Body(...)):
    return fetch_now(user_id)

@router.get("/operations/recent")
def recent(limit: int = Query(10)):
    return list_recent(limit)