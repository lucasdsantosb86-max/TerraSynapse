
from __future__ import annotations
import streamlit as st, json, hashlib
from pathlib import Path

USERS_PATH = Path("data/users/users.json")

def _load_users():
    try:
        data = json.loads(USERS_PATH.read_text(encoding="utf-8"))
        return {u["username"]: u for u in data.get("users", [])}
    except Exception:
        return {}

def _sha256(p: str) -> str:
    return hashlib.sha256(p.encode("utf-8")).hexdigest()

def login_form():
    st.subheader("🔐 Login")
    u = st.text_input("Usuário", key="auth_user")
    p = st.text_input("Senha", type="password", key="auth_pass")
    if st.button("Entrar"):
        users = _load_users()
        rec = users.get(u)
        if rec and rec["password_hash"] == _sha256(p):
            st.session_state["user"] = {"username": u, "role": rec.get("role","user"), "display": rec.get("display_name", u)}
            st.success(f"Bem-vindo, {st.session_state['user']['display']}")
            st.experimental_rerun()
        else:
            st.error("Credenciais inválidas.")
    st.caption("Dica: usuário inicial dev_terrasynapse / senha TS!Dev2025 — altere no Admin.")

def require(roles=("developer","gestor","tecnico")):
    user = st.session_state.get("user")
    if not user:
        st.warning("Faça login para continuar.")
        login_form()
        st.stop()
    if roles and user.get("role") not in roles:
        st.error("Acesso negado para seu perfil.")
        st.stop()
    return user

def logout_button():
    if st.button("Sair"):
        st.session_state.pop("user", None)
        st.experimental_rerun()
