from pathlib import Path, PurePosixPath
import pandas as pd, numpy as np, time, json, math, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

BASE = Path(__file__).resolve().parents[2]
ING = BASE/"data"/"gps"
OUT = BASE/"data"/"gps_out"
ING.mkdir(parents=True, exist_ok=True)
OUT.mkdir(parents=True, exist_ok=True)

def ingest_csv(csv_path: str, tag: str="default"):
    df = pd.read_csv(csv_path)
    # Espera colunas: timestamp, lat, lon, (opcional vel, heading, id)
    req = ["timestamp","lat","lon"]
    if not all(c in df.columns for c in req):
        raise ValueError("CSV deve conter colunas: timestamp, lat, lon")
    ts = int(time.time())
    out = ING/f"{tag}_{ts}.csv"
    df.to_csv(out, index=False)
    return {"ok": True, "stored": str(out)}

def _km(a,b):
    # haversine simplificado
    R=6371.0
    lat1,lon1,lat2,lon2 = map(math.radians, [a[0],a[1],b[0],b[1]])
    dlat=lat2-lat1; dlon=lon2-lon1
    h=math.sin(dlat/2)**2+math.cos(lat1)*math.cos(lat2)*math.sin(dlon/2)**2
    return 2*R*math.asin(min(1, math.sqrt(h)))

def metrics(tag: str=None):
    files = sorted(ING.glob("*.csv"))
    if tag: files = [f for f in files if f.name.startswith(tag+"_")]
    if not files: return {"ok": False, "detail":"sem dados"}
    df = pd.concat([pd.read_csv(f) for f in files], ignore_index=True).sort_values("timestamp")
    # km/dia (agregado simples)
    df["date"] = pd.to_datetime(df["timestamp"], unit="s").dt.date
    g = df.groupby("date")[["lat","lon"]].apply(lambda x: sum(_km(a,b) for a,b in zip(x.values[:-1], x.values[1:]))).reset_index(name="km")
    # heatmap simples (scatter densidade)
    fig, ax = plt.subplots(figsize=(5,5))
    ax.hexbin(df["lon"], df["lat"], gridsize=50)
    ax.set_xlabel("lon"); ax.set_ylabel("lat"); ax.set_title("Heatmap GPS")
    png = OUT/"heatmap.png"; fig.savefig(png, bbox_inches="tight"); plt.close(fig)
    return {"ok": True, "km_by_day": g.to_dict(orient="records"), "heatmap": str(png)}