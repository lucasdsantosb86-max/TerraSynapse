import streamlit as st
from pathlib import Path
import os, base64, json

st.set_page_config(page_title="Admin – Segurança & Auditoria", page_icon="🛡️", layout="wide")
st.title("🛡️ Admin – Segurança & Auditoria")

st.subheader("Chaves & Vars (somente leitura)")
st.code("TS_MASTER_KEY_B64 (env)
TS_AUDIT_HMAC_B64 (env)", language="bash")
st.caption("Defina as variáveis de ambiente antes do deploy para segurança máxima.")

st.subheader("Assinatura do índice RAG")
if st.button("Assinar index_snippets.jsonl"):
    import requests
    api = os.getenv("TS_BACKEND_URL","http://localhost:8000")
    st.json(requests.post(f"{api}/security/sign_index").json())
if st.button("Verificar assinatura"):
    import requests
    api = os.getenv("TS_BACKEND_URL","http://localhost:8000")
    st.json(requests.get(f"{api}/security/verify_index").json())

st.subheader("Audit Log (hash em cadeia) – último trecho")
chain = Path("data/audit/chain.log")
if chain.exists():
    lines = chain.read_text(encoding="utf-8").splitlines()[-50:]
    st.text("\n".join(lines))
else:
    st.info("Ainda sem eventos. Navegue pelo app para gerar entradas.")