
from __future__ import annotations
from pathlib import Path
import json, re, hashlib, datetime as dt

SEC = Path("data/security"); SEC.mkdir(parents=True, exist_ok=True)
POL = SEC/"policies.json"
FAILED = SEC/"failed_logins.json"

def load_policy():
    try:
        return json.loads(POL.read_text(encoding="utf-8"))
    except Exception:
        return {"password_policy":{"level":"medium","min_length":8,"groups_required":3,"expire_days":180,"history_depth":3,"max_failed_attempts":5,"lockout_minutes":15}}

def strong_enough(p: str, min_len: int, groups: int) -> bool:
    g = 0
    g += bool(re.search(r"[a-z]", p))
    g += bool(re.search(r"[A-Z]", p))
    g += bool(re.search(r"[0-9]", p))
    g += bool(re.search(r"[^a-zA-Z0-9]", p))
    return len(p) >= min_len and g >= groups

def add_failed(username: str):
    data = {}
    if FAILED.exists():
        try: data = json.loads(FAILED.read_text(encoding="utf-8"))
        except Exception: data = {}
    rec = data.get(username, {"fails":0,"until":None})
    rec["fails"] = rec.get("fails",0) + 1
    pol = load_policy()["password_policy"]
    if rec["fails"] >= pol.get("max_failed_attempts",5):
        until = dt.datetime.utcnow() + dt.timedelta(minutes=pol.get("lockout_minutes",15))
        rec["until"] = until.isoformat()+"Z"
    data[username] = rec
    FAILED.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")

def clear_failed(username: str):
    if not FAILED.exists(): return
    try:
        data = json.loads(FAILED.read_text(encoding="utf-8"))
        if username in data: data.pop(username)
        FAILED.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    except Exception:
        pass

def locked(username: str) -> bool:
    if not FAILED.exists(): return False
    try:
        data = json.loads(FAILED.read_text(encoding="utf-8"))
        rec = data.get(username)
        if not rec: return False
        until = rec.get("until")
        if not until: return False
        u = dt.datetime.fromisoformat(until.replace("Z",""))
        return dt.datetime.utcnow() < u
    except Exception:
        return False

def hash_pw(p:str) -> str:
    return hashlib.sha256(p.encode("utf-8")).hexdigest()

def check_history(user_record: dict, new_hash: str, depth: int) -> bool:
    hist = user_record.get("pwd_history", [])
    return new_hash not in hist[-depth:] if depth>0 else True

def push_history(user_record: dict, new_hash: str):
    hist = user_record.get("pwd_history", [])
    hist.append(new_hash)
    user_record["pwd_history"] = hist[-10:]
