import os, json, base64
from pathlib import Path

try:
    from cryptography.fernet import Fernet
except Exception:
    Fernet = None

BASE = Path(__file__).resolve().parents[2]
DIR = BASE/"data"/"secrets"
DIR.mkdir(parents=True, exist_ok=True)

def _fernet():
    key = os.getenv("TS_SECRETS_KEY","").encode()
    if Fernet and key:
        return Fernet(key)
    return None

def save_secret(name: str, payload: dict):
    fp = DIR/f"{name}.json"
    data = json.dumps(payload, ensure_ascii=False).encode()
    f = _fernet()
    if f:
        data = f.encrypt(data)
        fp.write_bytes(data)
        return {"ok": True, "encrypted": True, "path": str(fp)}
    fp.write_bytes(data)
    return {"ok": True, "encrypted": False, "path": str(fp)}

def load_secret(name: str):
    fp = DIR/f"{name}.json"
    if not fp.exists():
        return {"ok": False, "error":"not_found"}
    raw = fp.read_bytes()
    f = _fernet()
    if f:
        try:
            raw = f.decrypt(raw)
        except Exception:
            pass
    try:
        return {"ok": True, "data": json.loads(raw.decode())}
    except Exception:
        return {"ok": False, "error":"invalid_json"}