from pathlib import Path
import json, datetime as dt

BASE = Path(__file__).resolve().parents[2]
LOG  = BASE/"data"/"alerts_log.jsonl"

def _parse_ts(ts: str):
    # espera ISO8601Z; fallback para str simples
    try:
        return dt.datetime.fromisoformat(ts.replace("Z","+00:00"))
    except Exception:
        try:
            return dt.datetime.utcfromtimestamp(int(ts))
        except Exception:
            return None

def read_logs(start: str=None, end: str=None, limit: int=200):
    rows = []
    if not LOG.exists(): return {"ok": True, "events": []}
    t0 = _parse_ts(start) if start else None
    t1 = _parse_ts(end) if end else None
    with LOG.open("r", encoding="utf-8") as f:
        for ln in f:
            try:
                j = json.loads(ln)
            except Exception:
                continue
            ts = j.get("ts")
            dt_ts = _parse_ts(ts) if ts else None
            if t0 and dt_ts and dt_ts < t0: 
                continue
            if t1 and dt_ts and dt_ts > t1: 
                continue
            rows.append(j)
    rows = rows[-limit:]
    return {"ok": True, "events": rows}

def resend(events: list, webhooks_cfg: dict):
    # Envia novamente cada evento para os webhooks do tipo correspondente
    urls = (webhooks_cfg or {}).get("urls", {})
    tried = []
    import requests
    for ev in events:
        typ = ev.get("type")
        for wh in urls.get(typ, []):
            status = "ok"
            try:
                r = requests.post(wh, json=ev, timeout=10)
                if r.status_code >= 400:
                    status = f"http_{r.status_code}"
            except Exception as e:
                status = "error"
            tried.append({"event": ev, "webhook": wh, "status": status})
    return {"ok": True, "tried": tried}