from fastapi import APIRouter, Query
from ..services.costs_benchmark import benchmark
router = APIRouter(prefix="/costs/benchmark", tags=["costs"])

@router.get("")
def run(culture: str = Query(None), region: str = Query(None)):
    return benchmark(culture, region)