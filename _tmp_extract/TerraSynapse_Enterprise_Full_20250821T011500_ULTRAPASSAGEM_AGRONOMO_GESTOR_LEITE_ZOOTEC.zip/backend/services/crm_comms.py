from .crm_storage import list_all, get_by_id, create, update, delete
COL = "comms"

def list_comms(): return list_all(COL)
def create_comm(obj: dict): return create(COL, obj)
def list_by_client(client_id: str):
    return [c for c in list_all(COL) if c.get("client_id")==client_id]