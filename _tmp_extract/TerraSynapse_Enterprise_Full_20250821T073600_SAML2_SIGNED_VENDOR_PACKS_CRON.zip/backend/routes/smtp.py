from fastapi import APIRouter, Body
from ..services.emailer import set_smtp, send_email
from ..services.email_templates import render_html

router = APIRouter(prefix="/smtp", tags=["smtp"])

@router.post("/set")
def set_(cfg: dict = Body(...)):
    return set_smtp(cfg)

@router.post("/send")
def send(to: list = Body(...), subject: str = Body(...), text: str = Body(""), attachments: list = Body([]), html_title: str = Body(""), html_body: str = Body(""), from_email: str = Body("noreply@empresa.com")):
    html = render_html(from_email, html_title, html_body) if html_title or html_body else None
    return send_email(to, subject, text, attachments, html=html)