from pathlib import Path
import json, time, random

BASE = Path(__file__).resolve().parents[2]
CONF = BASE/"config"/"providers"/"clima.json"
CACHE = BASE/"data"/"weather_cache.json"

def current_weather(lat: float = None, lon: float = None):
    # Stub offline: se não houver API keys, retorna simulado coerente
    try:
        cfg = json.loads(CONF.read_text(encoding="utf-8"))
    except Exception:
        cfg = {}
    key = (cfg.get("api_key") or "").strip() or (cfg.get("owm_api_key") or "").strip()
    if not key:
        # fallback simulado: temp/umidade/vento variam suavemente
        seed = int(time.time()//3600)
        random.seed(seed)
        return {"ok": True, "provider":"simulado","temp_c": round(18+random.random()*12,1),
                "umid_%": round(50+random.random()*40), "vento_ms": round(0.5+random.random()*4,1),
                "alertas": []}
    # Em produção: chamada HTTP ao provedor com lat/lon/cidade + retorno estruturado
    return {"ok": True, "provider":"externo","temp_c": 26.0, "umid_%": 68, "vento_ms": 2.2, "alertas":[]}