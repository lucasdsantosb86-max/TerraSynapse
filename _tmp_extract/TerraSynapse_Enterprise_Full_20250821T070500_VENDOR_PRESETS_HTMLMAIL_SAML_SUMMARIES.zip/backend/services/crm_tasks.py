from .crm_storage import list_all, get_by_id, create, update, delete
COL = "tasks"

def list_tasks(): return list_all(COL)
def list_tasks_by(filter_fn):
    return [t for t in list_all(COL) if filter_fn(t)]
def get_task(tid: str): return get_by_id(COL, tid)
def create_task(obj: dict): return create(COL, obj)
def update_task(tid: str, patch: dict): return update(COL, tid, patch)
def delete_task(tid: str): return delete(COL, tid)