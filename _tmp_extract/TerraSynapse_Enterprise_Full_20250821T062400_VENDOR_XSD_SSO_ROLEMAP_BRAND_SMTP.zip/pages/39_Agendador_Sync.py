import streamlit as st, requests, os, json
st.set_page_config(page_title="Agendador de Sync (Cron leve)", page_icon="⏱️", layout="wide")
user_id = st.text_input('Seu e-mail (para permissões)', 'lucas@empresa.com')
st.title("⏱️ Agendador de Sync – JDLink")

api = st.text_input("Backend URL", value=os.getenv("TS_BACKEND_URL","http://localhost:8000"))

c1,c2,c3 = st.columns(3)
if c1.button("Iniciar agendador"):
    st.json(requests.post(f"{api}/scheduler/start").json())
if c2.button("Parar agendador"):
    st.json(requests.post(f"{api}/scheduler/stop").json())
if c3.button("Status"):
    st.json(requests.get(f"{api}/scheduler/status").json())

st.markdown("---")
st.subheader("Preferências por usuário (editar na tela de Sync)")
st.write("As preferências de cada usuário (enabled/interval_min) são lidas de config/jdlink_sync.json e atualizadas via tela **Sincronização JDLink (Simplificada)**.")

import requests, streamlit as st, os
role_api = os.getenv("TS_BACKEND_URL","http://localhost:8000") + "/auth/role"
_res = requests.get(role_api, params={"user_id": user_id}).json()
_user_role = (_res.get("role") or "visitante").lower()
_allowed = set(['gestor', 'integrador', 'engenheiro'])
if _user_role not in _allowed:
    st.error(f"Acesso restrito. Seu papel: '{_user_role}'. Permitidos: {', '.join(_allowed)}")
    st.stop()
