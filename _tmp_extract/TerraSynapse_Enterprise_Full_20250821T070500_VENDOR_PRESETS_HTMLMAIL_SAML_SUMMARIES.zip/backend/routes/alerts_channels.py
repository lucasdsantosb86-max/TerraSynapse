from fastapi import APIRouter, Body
from ..services.notifier import set_channels, send_all

router = APIRouter(prefix="/alerts/channels", tags=["alerts-channels"])

@router.post("/set")
def set_(channels: list = Body(...)):
    return set_channels(channels)

@router.post("/test")
def test(payload: dict = Body(...)):
    return send_all(payload)