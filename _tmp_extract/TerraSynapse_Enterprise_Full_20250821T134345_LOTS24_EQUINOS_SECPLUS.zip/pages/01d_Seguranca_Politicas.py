
from __future__ import annotations
import streamlit as st, json, base64, os
from pathlib import Path
from frontend.auth import require

st.set_page_config(page_title="Segurança – Políticas", page_icon="🛡️", layout="wide")
user = require(roles=("developer","gestor"))

POL = Path("data/security/policies.json")

def load_pol():
    try:
        return json.loads(POL.read_text(encoding="utf-8"))
    except Exception:
        return {}

def save_pol(d):
    POL.write_text(json.dumps(d, indent=2, ensure_ascii=False), encoding="utf-8")

st.title("🛡️ Políticas de Segurança")

p = load_pol()

st.subheader("Senha")
colA, colB, colC, colD = st.columns(4)
with colA:
    p["password_policy"]["level"] = st.selectbox("Nível", ["medium","strong"], index=1 if p["password_policy"]["level"]=="strong" else 0)
with colB:
    p["password_policy"]["min_length"] = st.number_input("Mín. caracteres", min_value=8, max_value=64, value=int(p["password_policy"]["min_length"]))
with colC:
    p["password_policy"]["groups_required"] = st.number_input("Grupos exigidos", min_value=2, max_value=4, value=int(p["password_policy"]["groups_required"]))
with colD:
    p["password_policy"]["history_depth"] = st.number_input("Histórico (N últimas)", min_value=0, max_value=10, value=int(p["password_policy"]["history_depth"]))

colE, colF = st.columns(2)
with colE:
    p["password_policy"]["expire_days"] = st.number_input("Expirar em (dias)", min_value=0, max_value=365, value=int(p["password_policy"]["expire_days"]))
with colF:
    p["password_policy"]["max_failed_attempts"] = st.number_input("Máx. falhas", min_value=3, max_value=10, value=int(p["password_policy"]["max_failed_attempts"]))

colG, colH = st.columns(2)
with colG:
    p["password_policy"]["lockout_minutes"] = st.number_input("Bloqueio (min)", min_value=5, max_value=120, value=int(p["password_policy"]["lockout_minutes"]))
with colH:
    st.write(" ")

st.subheader("Autenticação")
col1, col2 = st.columns(2)
with col1:
    p.setdefault("auth", {})["require_2fa"] = st.checkbox("Exigir 2FA", value=bool(p.get("auth",{}).get("require_2fa", False)))
with col2:
    p.setdefault("auth", {})["captcha_enabled"] = st.checkbox("Ativar Captcha no login", value=bool(p.get("auth",{}).get("captcha_enabled", False)))

st.subheader("Auditoria")
st.caption("Assinatura HMAC das entradas para integridade.")
if st.button("Gerar nova chave secreta HMAC"):
    p["audit_hmac_secret"] = base64.b64encode(os.urandom(32)).decode("ascii")
    st.success("Nova chave gerada. (Registre em local seguro).")

if st.button("Salvar políticas"):
    save_pol(p); st.success("Políticas atualizadas.")
