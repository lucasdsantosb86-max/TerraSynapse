from fastapi import APIRouter, Body
from ..services.ingest_mqtt_aqua import _load_conf, eval_rules

router = APIRouter(prefix="/ingest/aqua", tags=["ingest"])

@router.post("/sample")
def sample(sample: dict = Body(...)):
    conf = _load_conf()
    return eval_rules(sample, conf)