from pathlib import Path
import json
from typing import List

BASE = Path(__file__).resolve().parents[2]
PRE = BASE/"config"/"isoxml_vendor_presets.json"

def _presets():
    return json.loads(PRE.read_text(encoding="utf-8"))

def list_presets():
    return _presets()

def make_vendor_xml(preset: str, job_name: str, culture: str, zones: List[dict], asap:str="", grd:str="", pln:str="") -> str:
    cfg = _presets().get(preset)
    if not cfg: raise ValueError("preset não encontrado")
    ttag = cfg.get("task_tag","TASK")
    ptag = cfg.get("partfield_tag","PARTFIELD")
    ver  = (cfg.get("attrs") or {}).get("version","3.3")
    lines = []
    lines.append('<?xml version="1.0" encoding="UTF-8"?>')
    lines.append(f'<ISOXML version="{ver}">')
    lines.append(f'  <{ttag} name="{job_name}" culture="{culture}">')
    if (cfg.get("extra") or {}).get("ASAP") and asap:
        lines.append(f'    <ASAP>{asap}</ASAP>')
    if (cfg.get("extra") or {}).get("GRD") and grd:
        lines.append(f'    <GRD>{grd}</GRD>')
    if (cfg.get("extra") or {}).get("PLN") and pln:
        lines.append(f'    <PLN>{pln}</PLN>')
    for z in zones:
        zid = z.get("zone_id"); rate = z.get("rate"); klass = z.get("class")
        lines.append(f'    <{ptag} id="{zid}" class="{klass}" targetRate="{rate}"/>')
    lines.append(f'  </{ttag}>')
    lines.append('</ISOXML>')
    return "\n".join(lines)