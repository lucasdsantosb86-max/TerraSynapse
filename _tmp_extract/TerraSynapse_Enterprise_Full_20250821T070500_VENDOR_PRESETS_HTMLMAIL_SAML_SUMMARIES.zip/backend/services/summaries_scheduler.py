from pathlib import Path
import json, time
from .daily_summary import generate_summary
from .emailer import send_email
from .email_templates import render_html

BASE = Path(__file__).resolve().parents[2]
CONF = BASE/"config"/"summaries.json"

def _cfg():
    try:
        return json.loads(CONF.read_text(encoding="utf-8"))
    except Exception:
        return {"schedules":[]}

def set_schedules(payload: dict):
    CONF.write_text(json.dumps(payload or {"schedules":[]}, indent=2, ensure_ascii=False), encoding="utf-8")
    return {"ok": True}

def _should_run(item, tm):
    # item: {"freq": "daily"/"weekly", "hour":"HH:MM", "dow": "mon..sun" optional}
    hhmm = item.get("hour","18:00")
    ok_hour = tm.tm_hour == int(hhmm.split(":")[0]) and tm.tm_min == int(hhmm.split(":")[1])
    if item.get("freq") == "daily":
        return ok_hour
    if item.get("freq") == "weekly":
        dmap = ["mon","tue","wed","thu","fri","sat","sun"]
        return ok_hour and (item.get("dow","fri").lower()[:3] == dmap[tm.tm_wday])
    return False

def tick():
    tm = time.localtime()
    for item in _cfg().get("schedules", []):
        if _should_run(item, tm):
            res = generate_summary()
            html = render_html((item.get("emails") or ["noreply@empresa.com"])[0], f"Resumo – {item.get('scope')} {item.get('id')}", "Segue resumo automático anexado.")
            send_email(item.get("emails") or [], f"Resumo – {item.get('scope')} {item.get('id')}", "Resumo automático", [res.get("csv"), res.get("pdf")], html=html)
    return {"ok": True}