from fastapi import APIRouter, Body
from ..services import scheduler

router = APIRouter(prefix="/scheduler", tags=["scheduler"])

@router.post("/start")
def start():
    return scheduler.start()

@router.post("/stop")
def stop():
    return scheduler.stop()

@router.get("/status")
def status():
    return scheduler.status()