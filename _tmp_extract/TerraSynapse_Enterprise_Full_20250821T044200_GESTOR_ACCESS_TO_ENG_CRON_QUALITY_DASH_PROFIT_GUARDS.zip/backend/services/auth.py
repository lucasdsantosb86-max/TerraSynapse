import json, time, base64, os
from pathlib import Path
import jwt
from .crypto_suite import hash_password, verify_password
from .totp import verify_2fa

BASE = Path(__file__).resolve().parents[2]
CONF = BASE/"config"/"security.json"
USERS = BASE/"data"/"users"
USERS.mkdir(parents=True, exist_ok=True)
DB = USERS/"users.json"

def _conf():
    return json.loads(CONF.read_text(encoding="utf-8"))

def _db():
    if DB.exists():
        return json.loads(DB.read_text(encoding="utf-8"))
    return {"users":[]}

def _save(db): DB.write_text(json.dumps(db, ensure_ascii=False, indent=2), encoding="utf-8")

def create_user(email: str, password: str, role: str = "tecnico"):
    db = _db()
    if any(u["email"]==email for u in db["users"]):
        return {"ok": False, "detail":"exists"}
    h = hash_password(password)
    db["users"].append({"email": email, "pass": h, "role": role, "created_at": int(time.time())})
    _save(db); return {"ok": True}

def login(email: str, password: str, code: str = None):
    db = _db()
    user = next((u for u in db["users"] if u["email"]==email), None)
    if not user: return {"ok": False, "detail":"not_found"}
    if not verify_password(user["pass"], password): return {"ok": False, "detail":"invalid_password"}
    cfg = _conf()
    req_roles = set(cfg.get("roles_require_2fa", []))
    if user["role"] in req_roles:
        if not _user_has_2fa(email):
            return {"ok": False, "detail":"2fa_not_enabled"}
        if not code:
            return {"ok": False, "detail":"2fa_required"}
        v = verify_2fa_or_recovery(email, code)
        if not v.get("ok"): return {"ok": False, "detail":"2fa_invalid"}
    # issue JWT
    now = int(time.time())
    jwt_cfg = cfg.get("jwt", {"alg":"HS512"})
    payload = {"iss": jwt_cfg.get("issuer","TerraSynapse"),
               "sub": email, "role": user["role"], "iat": now, "exp": now + 60*60*jwt_cfg.get("rotate_hours",12)}
    key = base64.b64encode(os.urandom(64)).decode()  # para demo; em prod, usar key durável via env/secret
    token = jwt.encode(payload, key, algorithm=jwt_cfg.get("alg","HS512"))
    return {"ok": True, "token": token, "role": user["role"]}

def _user_has_2fa(email: str):
    # simples: verifica presença de segredo e enabled no store 2FA
    import json, base64
    from .totp import _load as _load2fa
    db = _load2fa()
    rec = db.get(email)
    return bool(rec and rec.get("enabled"))


def verify_2fa_or_recovery(email: str, code: str = None):
    from .totp import verify_2fa
    from .totp_recovery import use_recovery_code
    if not code:
        return {"ok": False}
    # tenta TOTP
    v = verify_2fa(email, code)
    if v.get("ok"): return v
    # tenta recovery
    return use_recovery_code(email, code)
