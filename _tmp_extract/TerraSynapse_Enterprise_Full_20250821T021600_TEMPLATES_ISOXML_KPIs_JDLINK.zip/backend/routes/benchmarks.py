from fastapi import APIRouter, Body
from ..services.benchmarks import pivot_bench
from pathlib import Path
router = APIRouter(prefix="/benchmarks", tags=["benchmarks"])
@router.post("/pivot")
def pivot(src: str = Body(...)):
    out = Path(src).with_suffix(".pivot.csv")
    return pivot_bench(src, str(out))