from fastapi import APIRouter, UploadFile, File, Form
from ..services.crypto_suite import encrypt_file, decrypt_file, sign_file, verify_file
from pathlib import Path

router = APIRouter(prefix="/security", tags=["security"])

@router.post("/encrypt_file")
async def enc(file: UploadFile = File(...)):
    src = Path("data")/file.filename
    src.write_bytes(await file.read())
    out = str(src)+".enc"
    return encrypt_file(str(src), out)

@router.post("/decrypt_file")
async def dec(filename: str = Form(...)):
    src = Path("data")/filename
    out = str(src).replace(".enc","")
    return decrypt_file(str(src), out)

@router.post("/sign_index")
def sign_index():
    idx = Path("data/knowledge/index_snippets.jsonl")
    return sign_file(str(idx))

@router.get("/verify_index")
def verify_index():
    idx = Path("data/knowledge/index_snippets.jsonl")
    return verify_file(str(idx))