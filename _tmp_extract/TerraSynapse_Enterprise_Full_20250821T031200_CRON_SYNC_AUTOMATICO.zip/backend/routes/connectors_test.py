from fastapi import APIRouter, Body
from ..services.connectors_common import test_provider

router = APIRouter(prefix="/connectors", tags=["connectors-test"])

@router.post("/test")
def test(provider: str = Body(...), user_id: str = Body(None)):
    return test_provider(provider, user_id)