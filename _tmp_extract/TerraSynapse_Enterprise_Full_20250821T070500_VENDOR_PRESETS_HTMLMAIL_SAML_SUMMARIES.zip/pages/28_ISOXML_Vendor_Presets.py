import streamlit as st, requests, os, json
st.set_page_config(page_title="ISOXML – Presets do Fabricante", page_icon="🧩", layout="wide")
st.title("🧩 ISOXML – Presets do Fabricante (geração rápida)")

api = st.text_input("Backend URL", value=os.getenv("TS_BACKEND_URL","http://localhost:8000"))
user_id = st.text_input("Seu e-mail (para permissões)", "lucas@empresa.com")

# Guard
import requests as rq
role_api = api + "/auth/role"
_res = rq.get(role_api, params={"user_id": user_id}).json()
_user_role = (_res.get("role") or "visitante").lower()
_allowed = {"gestor","integrador","engenheiro"}
if _user_role not in _allowed:
    st.error(f"Acesso restrito. Seu papel: '{_user_role}'. Permitidos: {', '.join(_allowed)}")
    st.stop()

st.subheader("Presets disponíveis")
st.json(requests.get(f"{api}/isoxml/presets/list").json())

st.subheader("Gerar XML por preset")
with st.form("gen"):
    preset = st.text_input("Preset", "deere_demo")
    job_name = st.text_input("Nome do job", "Plantio Soja T01")
    culture = st.text_input("Cultura", "soja")
    zones = st.text_area("Zonas (JSON)", '[{"zone_id":1,"class":"low","rate":180},{"zone_id":2,"class":"mid","rate":200}]', height=140)
    asap = st.text_input("ASAP (opcional)", "")
    grd  = st.text_input("GRD (opcional)", "")
    pln  = st.text_input("PLN (opcional)", "")
    if st.form_submit_button("Gerar XML"):
        try:
            z = json.loads(zones)
            st.json(requests.post(f"{api}/isoxml/presets/export", json={"preset":preset, "job_name":job_name, "culture":culture, "zones":z, "asap": asap, "grd":grd, "pln":pln}).json())
        except Exception as e:
            st.error(f"JSON inválido: {e}")