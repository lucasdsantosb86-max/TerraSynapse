from fastapi import APIRouter, Body, Query
from ..services.secrets import set_secret, get_secret, masked, list_users, set_secret_user, get_secret_user, masked_user

router = APIRouter(prefix="/secrets", tags=["secrets"])

@router.post("/set")
def set(provider: str = Body(...), key: str = Body(...), value: str = Body(...)):
    set_secret(provider, key, value); return {"ok": True}

@router.get("/masked")
def view(provider: str = Query(...)):
    return {"ok": True, "provider": provider, "keys": masked(provider)}

@router.get("/users")
def users():
    return {"ok": True, "users": list_users()}

# --- por usuário ---
@router.post("/user/set")
def set_user(user_id: str = Body(...), provider: str = Body(...), key: str = Body(...), value: str = Body(...)):
    set_secret_user(user_id, provider, key, value); return {"ok": True}

@router.get("/user/masked")
def view_user(user_id: str = Query(...), provider: str = Query(...)):
    return {"ok": True, "user_id": user_id, "provider": provider, "keys": masked_user(user_id, provider)}