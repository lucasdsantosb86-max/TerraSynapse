from fastapi import APIRouter, Body
from ..services.totp_recovery import generate_recovery_codes, use_recovery_code

router = APIRouter(prefix="/auth/2fa/recovery", tags=["auth"])

@router.post("/generate")
def gen(user: str = Body(...)):
    return generate_recovery_codes(user)

@router.post("/use")
def use(user: str = Body(...), code: str = Body(...)):
    return use_recovery_code(user, code)