import streamlit as st, pandas as pd, folium
from folium.plugins import HeatMap
from pathlib import Path

st.set_page_config(page_title="Heatmap GPS", page_icon="🔥", layout="wide")
st.title("🔥 Heatmap GPS – Deslocamento por animal/lote")

base = Path.cwd()
csv = base/"data"/"gps"/"logs.csv"
if not csv.exists():
    st.warning("Ainda não há dados. Use /ingest/gps para enviar logs (row/bulk).")
else:
    df = pd.read_csv(csv)
    st.dataframe(df.head(100))
    if len(df):
        m = folium.Map(location=[df['lat'].mean(), df['lon'].mean()], zoom_start=14)
        HeatMap(df[['lat','lon']].values.tolist()).add_to(m)
        st.components.v1.html(m._repr_html_(), height=520, scrolling=False)