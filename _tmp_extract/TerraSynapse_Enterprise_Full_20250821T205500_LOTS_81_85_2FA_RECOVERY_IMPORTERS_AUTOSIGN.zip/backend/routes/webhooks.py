from fastapi import APIRouter, Body
from pathlib import Path
import json
from ..services.webhooks import send_event

router = APIRouter(prefix="/alerts/webhooks", tags=["alerts"])
CONF = Path(__file__).resolve().parents[2]/"config"/"webhooks.json"

@router.get("/list")
def list_channels():
    return json.loads(CONF.read_text(encoding="utf-8"))

@router.post("/register")
def register_channel(channel: dict = Body(...)):
    cfg = json.loads(CONF.read_text(encoding="utf-8"))
    # substitui se name já existe
    name = channel.get("name")
    if name:
        cfg["channels"] = [c for c in cfg.get("channels",[]) if c.get("name")!=name] + [channel]
    else:
        cfg["channels"] = cfg.get("channels",[]) + [channel]
    CONF.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"ok": True, "channels": cfg["channels"]}

@router.post("/test")
def test_event(message: str = Body(...), channel: str = Body(default="broadcast")):
    ev = {"type":"test","message": message}
    if channel != "broadcast":
        ev["_internal"] = {"channel": channel}
    return send_event(ev)