import streamlit as st, json, requests, os, base64

st.set_page_config(page_title="Admin – Conectores & Chaves", page_icon="🔑", layout="wide")
st.title("🔑 Conectores & Chaves – TerraSynapse")

st.info("As chaves ficam em cofre criptografado. Defina a variável de ambiente TS_SECRETS_KEY (Fernet base64).")

api = st.text_input("Backend URL", value=os.getenv("TS_BACKEND_URL","http://localhost:8000"))

colA, colB = st.columns(2)
with colA:
    r = requests.get(f"{api}/connectors/registry").json()
    provs = r.get("providers", {})
    prov = st.selectbox("Provedor", sorted(provs.keys()))
    if prov:
        reqs = provs[prov].get("required", [])
        st.caption("Campos exigidos: " + (", ".join(reqs) if reqs else "—"))
        for k in reqs:
            val = st.text_input(f"{prov}.{k}", type="password")
            if st.button(f"Salvar {k}"):
                jj = requests.post(f"{api}/secrets/set", json={"provider":prov,"key":k,"value":val}).json()
                st.success("Salvo.")
        if st.button("Ativar/Validar"):
            st.json(requests.post(f"{api}/connectors/activate", json={"provider":prov}).json())
with colB:
    st.subheader("Ver chaves (mascaradas)")
    prov2 = st.selectbox("Provedor (ver)", sorted(provs.keys()), key="prov2")
    if prov2:
        st.json(requests.get(f"{api}/secrets/masked", params={"provider":prov2}).json())