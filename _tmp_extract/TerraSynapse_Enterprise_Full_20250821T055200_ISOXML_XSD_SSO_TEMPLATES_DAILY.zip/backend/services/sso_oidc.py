from pathlib import Path
import json, secrets, time
import base64
from typing import Dict, Any

BASE = Path(__file__).resolve().parents[2]
CONF = BASE/"config"/"auth_providers.json"
STATE = BASE/"data"/"sso_state.json"

def _cfg():
    try:
        return json.loads(CONF.read_text(encoding="utf-8"))
    except Exception:
        return {"providers":[]}

def list_providers():
    return _cfg()

def set_providers(payload: dict):
    CONF.write_text(json.dumps(payload or {"providers":[]}, indent=2, ensure_ascii=False), encoding="utf-8")
    return {"ok": True}

def start(provider_name: str, user_id: str) -> Dict[str,Any]:
    cfg = _cfg()
    p = next((x for x in cfg.get("providers",[]) if x.get("name")==provider_name), None)
    if not p: return {"ok": False, "error":"provider_not_found"}
    state = secrets.token_urlsafe(24)
    # registro simples de state
    try:
        st = json.loads(STATE.read_text(encoding="utf-8"))
    except Exception:
        st = {}
    st[state] = {"user_id": user_id, "ts": int(time.time()), "provider": provider_name}
    STATE.write_text(json.dumps(st, indent=2), encoding="utf-8")
    # url de auth (stub; cliente deve preencher endpoints válidos)
    url = f"{p.get('auth_url')}?client_id={p.get('client_id')}&redirect_uri={p.get('redirect_uri')}&response_type=code&scope=openid%20profile%20email&state={state}"
    return {"ok": True, "auth_url": url, "state": state}

def callback(code: str, state: str) -> Dict[str,Any]:
    # Em produção: trocar 'code' por tokens no token_url do provider e mapear o e-mail/UPN para user_id
    # Aqui: valida apenas o state salvo
    try:
        st = json.loads(STATE.read_text(encoding="utf-8"))
    except Exception:
        return {"ok": False, "error":"invalid_state_store"}
    if state not in st:
        return {"ok": False, "error":"state_not_found"}
    rec = st[state]
    return {"ok": True, "linked_user": rec.get("user_id"), "provider": rec.get("provider"), "code": code}

import requests
from pathlib import Path
TOKENS_DIR = BASE/"data"/"auth"
TOKENS_DIR.mkdir(parents=True, exist_ok=True)

def _by_name(name: str):
    cfg = _cfg()
    return next((x for x in cfg.get("providers",[]) if x.get("name")==name), None)

def exchange_token(provider_name: str, code: str):
    p = _by_name(provider_name)
    if not p: return {"ok": False, "error":"provider_not_found"}
    data = {
        "grant_type": "authorization_code",
        "code": code,
        "redirect_uri": p.get("redirect_uri"),
        "client_id": p.get("client_id"),
        "client_secret": p.get("client_secret")
    }
    r = requests.post(p.get("token_url"), data=data, timeout=10)
    tok = r.json()
    return {"ok": True, "tokens": tok}

def fetch_userinfo(provider_name: str, access_token: str):
    p = _by_name(provider_name)
    if not p: return {"ok": False, "error":"provider_not_found"}
    h = {"Authorization": f"Bearer {access_token}"}
    r = requests.get(p.get("userinfo_url"), headers=h, timeout=10)
    return {"ok": True, "userinfo": r.json()}

def persist_link(user_id: str, provider: str, userinfo: dict, tokens: dict):
    rec = {"user_id": user_id, "provider": provider, "userinfo": userinfo, "tokens": tokens}
    fp = TOKENS_DIR/f"{user_id.replace('@','_at_')}_{provider}.json"
    fp.write_text(json.dumps(rec, indent=2, ensure_ascii=False), encoding="utf-8")
    return {"ok": True, "path": str(fp.relative_to(BASE))}
