
import streamlit as st, requests
st.set_page_config(page_title='TerraSynapse – Home', page_icon='🏠', layout='wide')
st.title('🏠 TerraSynapse IA – Home')
status = '🟢 Online'
try: ok = requests.get('http://localhost:8000/health/ping', timeout=3).ok
except Exception: ok = False
if not ok:
    status = '🔴 Offline'
    try: requests.post('http://localhost:8000/alerts/heartbeat', data={'ping_ok': False})
    except Exception: pass
else:
    requests.post('http://localhost:8000/alerts/heartbeat', data={'ping_ok': True})
st.metric('Conectividade do backend', status)
st.caption('A Home registra automaticamente alerta de desconexão quando detectar Offline.')
