from pathlib import Path
from datetime import datetime
from typing import List, Dict
import csv, math

DATA = Path(__file__).resolve().parents[2]/"data"/"gps"
DATA.mkdir(parents=True, exist_ok=True)
LOG = DATA/"gps_log.csv"

def haversine_km(lat1, lon1, lat2, lon2):
    R = 6371.0
    from math import radians, sin, cos, asin, sqrt
    dlat = radians(lat2-lat1); dlon = radians(lon2-lon1)
    a = sin(dlat/2)**2 + cos(radians(lat1))*cos(radians(lat2))*sin(dlon/2)**2
    c = 2*asin(sqrt(a))
    return R*c

def append_points(points: List[Dict]):
    # points: [{timestamp, animal_id, lat, lon}]
    fresh = []
    for p in points:
        t = p.get("timestamp")
        if isinstance(t, (int,float)):
            ts = datetime.utcfromtimestamp(t).isoformat()
        else:
            ts = str(t)
        fresh.append([ts, str(p.get("animal_id")), float(p.get("lat")), float(p.get("lon"))])
    exists = LOG.exists()
    with LOG.open("a", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        if not exists:
            w.writerow(["timestamp","animal_id","lat","lon"])
        w.writerows(fresh)
    return {"ok": True, "added": len(fresh)}

def km_por_dia():
    # retorna {animal_id: {YYYY-MM-DD: km}}
    if not LOG.exists():
        return {}
    import pandas as pd
    df = pd.read_csv(LOG, parse_dates=["timestamp"])
    df = df.sort_values(["animal_id","timestamp"]).reset_index(drop=True)
    out = {}
    for aid, g in df.groupby("animal_id"):
        g = g.sort_values("timestamp")
        km = 0.0
        daily = {}
        prev = None
        for _, row in g.iterrows():
            day = row["timestamp"].date().isoformat()
            if day not in daily:
                daily[day] = 0.0
                prev = None
            if prev is not None:
                d = haversine_km(prev["lat"], prev["lon"], row["lat"], row["lon"])
                daily[day] += d
            prev = row
        out[str(aid)] = {k: round(v, 3) for k, v in daily.items()}
    return out