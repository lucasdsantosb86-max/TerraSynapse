import json
from pathlib import Path

BASE = Path(__file__).resolve().parents[2]
TH = BASE/"data"/"prices"/"cost_thresholds.json"

def check_cost_threshold(cultura: str, total_R$: float, area_ha: float):
    if area_ha <= 0:
        return {"ok": False, "detail": "Área inválida"}
    per_ha = total_R$ / area_ha
    d = json.loads(TH.read_text(encoding="utf-8")) if TH.exists() else {}
    ref = float(d.get(cultura.lower(), 0.0))
    alert = per_ha > ref if ref > 0 else False
    return {"ok": True, "cultura": cultura, "custo_R$_ha": round(per_ha,2), "limiar_R$_ha": ref, "alerta": alert}