import pandas as pd

def rank_animals(csv_path: str, weights: dict):
    df = pd.read_csv(csv_path)
    for k,v in weights.items():
        if k in df.columns:
            df[f"W_{k}"] = df[k].astype(float)*float(v)
    df["IndexEcon"] = df[[c for c in df.columns if c.startswith("W_")]].sum(axis=1)
    return df.sort_values("IndexEcon", ascending=False)

def mating_plan(csv_path: str, weights: dict, max_pairs: int = 20, min_rel: float = 0.0):
    # min_rel: limite de parentesco (0 = ignora). Se houver coluna 'Relacao' (0..1), filtra pares <= min_rel.
    df = rank_animals(csv_path, weights)
    # Heurística simples: top machos x top fêmeas (coluna 'Sexo' M/F)
    m = df[df.get("Sexo","M").str.upper().str.startswith("M")]
    f = df[df.get("Sexo","F").str.upper().str.startswith("F")]
    pairs = []
    for i, (_, rm) in enumerate(m.head(50).iterrows()):
        for j, (_, rf) in enumerate(f.head(50).iterrows()):
            if "Relacao" in df.columns and float(rm.get("Relacao",0))>min_rel: 
                continue
            score = rm["IndexEcon"] + rf["IndexEcon"]
            pairs.append({"Macho": rm.get("ID"), "Femea": rf.get("ID"), "Score": round(score,2)})
            if len(pairs)>=max_pairs: break
        if len(pairs)>=max_pairs: break
    return pd.DataFrame(pairs)