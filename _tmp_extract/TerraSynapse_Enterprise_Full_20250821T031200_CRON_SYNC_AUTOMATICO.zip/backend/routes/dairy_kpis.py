from fastapi import APIRouter, Query
from ..services.dairy_kpis import summarize

router = APIRouter(prefix="/dairy", tags=["dairy-kpis"])

@router.get("/kpis")
def kpis(client_id: str = Query(None)):
    return summarize(client_id)