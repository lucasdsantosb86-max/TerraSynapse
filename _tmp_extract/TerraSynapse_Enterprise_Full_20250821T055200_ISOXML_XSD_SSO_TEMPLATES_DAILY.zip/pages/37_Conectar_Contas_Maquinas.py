import streamlit as st, requests, os

st.set_page_config(page_title="Conectar Máquinas – JDLink", page_icon="🔗", layout="wide")
st.title("🔗 Conectar JDLink (OAuth)")

api = st.text_input("Backend URL", value=os.getenv("TS_BACKEND_URL","http://localhost:8000"))
user_id = st.text_input("User ID (e-mail)", "lucas@empresa.com")
client_id = st.text_input("Client ID (JD Developer)")
redirect_uri = st.text_input("Redirect URI (configurada no JD)", "https://sua-ia.exemplo.com/oauth/jdlink/callback")

if st.button("Gerar link de autorização"):
    j = requests.post(f"{api}/oauth/jdlink/start", json={"user_id": user_id, "client_id": client_id, "redirect_uri": redirect_uri}).json()
    st.json(j)
    if j.get("ok"):
        st.markdown(f"[Abrir autorização JDLink]({j['authorize_url']})")

st.subheader("Callback manual (colar tokens após login JD)")
acc = st.text_input("access_token")
ref = st.text_input("refresh_token (opcional)")
if st.button("Salvar tokens no cofre"):
    j = requests.post(f"{api}/oauth/jdlink/callback", json={"user_id": user_id, "access_token": acc, "refresh_token": ref}).json()
    st.json(j)
    st.success("Tokens salvos por usuário (auto-connect pode testar endpoints).")