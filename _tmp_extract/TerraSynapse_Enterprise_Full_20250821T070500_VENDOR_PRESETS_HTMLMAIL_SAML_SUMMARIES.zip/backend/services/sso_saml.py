from pathlib import Path
import json, base64
from typing import Dict, Any

BASE = Path(__file__).resolve().parents[2]
CONF = BASE/"config"/"saml"/"providers.json"
POSTS = BASE/"data"/"saml_posts"
POSTS.mkdir(parents=True, exist_ok=True)

def _cfg():
    try:
        return json.loads(CONF.read_text(encoding="utf-8"))
    except Exception:
        return {"providers":[]}

def list_providers():
    return _cfg()

def set_providers(payload: dict):
    CONF.write_text(json.dumps(payload or {"providers":[]}, indent=2, ensure_ascii=False), encoding="utf-8")
    return {"ok": True}

def start(provider_name: str, user_id: str):
    p = next((x for x in _cfg().get("providers",[]) if x.get("name")==provider_name), None)
    if not p: return {"ok": False, "error":"provider_not_found"}
    # Em produção: gerar AuthnRequest assinado. Aqui: URL simples para teste manual.
    return {"ok": True, "redirect_to": p.get("sso_url"), "relay_state": user_id}

def acs(provider_name: str, SAMLResponse: str, RelayState: str = "") -> Dict[str,Any]:
    # DEV STUB: apenas decodifica base64 e salva o POST; não valida assinatura.
    try:
        raw = base64.b64decode(SAMLResponse.encode("utf-8"))
    except Exception:
        raw = b""
    (POSTS/"last_assertion.xml").write_bytes(raw or b"")
    # Mapeia papel usando OIDC role mapper (reuso das regras pelo claim 'email' se existir no XML de forma simples)
    # Em produção: parse XML com verificação de assinatura e extração de NameID/Attributes.
    email = ""
    try:
        txt = (raw or b"").decode(errors="ignore")
        import re
        m = re.search(r"EmailAddress\">([^<]+)<", txt)
        if m:
            email = m.group(1)
    except Exception:
        pass
    role = "visitante"
    if email:
        try:
            from .roles_mapping import map_role
            role = map_role(provider_name, {"email": email}, email)
        except Exception:
            pass
    return {"ok": True, "linked_user": RelayState or email, "email": email, "role_mapped": role, "warning":"DEV STUB: sem validação de assinatura"}