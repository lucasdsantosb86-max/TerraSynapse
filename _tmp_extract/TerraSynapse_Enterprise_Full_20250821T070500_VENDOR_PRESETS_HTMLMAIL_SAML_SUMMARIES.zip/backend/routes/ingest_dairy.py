from fastapi import APIRouter, Body
from pathlib import Path
import json, time

BASE = Path(__file__).resolve().parents[2]
ING  = BASE/"data"/"ingest"/"dairy"
ING.mkdir(parents=True, exist_ok=True)

router = APIRouter(prefix="/ingest/dairy", tags=["ingest-dairy"])

@router.post("/{provider}/webhook")
def wb(provider: str, payload: dict = Body(...)):
    p = ING/provider; p.mkdir(parents=True, exist_ok=True)
    fn = p/f"{int(time.time())}.json"
    fn.write_text(json.dumps(payload), encoding="utf-8")
    return {"ok": True, "stored": str(fn.relative_to(BASE))}