import pandas as pd
from pathlib import Path
FX = {"BRL":1.0,"USD":5.0,"EUR":5.5}
def normalize_seeds(src_path: str, out_path: str):
    df = pd.read_csv(src_path)
    df["fx"] = df["currency"].map(FX).fillna(1.0)
    df["price_BRL"] = df["price_local"]*df["fx"]
    df.to_csv(out_path, index=False)
    return {"ok": True, "rows": len(df), "out": out_path}