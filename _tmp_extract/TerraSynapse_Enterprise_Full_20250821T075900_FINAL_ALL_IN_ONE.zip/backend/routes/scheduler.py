from fastapi import APIRouter
from ..services.scheduler import start_scheduler, stop_scheduler, status

router = APIRouter(prefix="/scheduler", tags=["scheduler"])

@router.post("/start")
def start():
    return start_scheduler()

@router.post("/stop")
def stop():
    return stop_scheduler()

@router.get("/status")
def get_status():
    return status()