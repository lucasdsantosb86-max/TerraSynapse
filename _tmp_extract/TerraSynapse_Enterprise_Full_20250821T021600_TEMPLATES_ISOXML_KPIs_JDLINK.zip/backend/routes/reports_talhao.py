from fastapi import APIRouter, Body
from ..services.ndvi_report import gerar_relatorio_talhao
from ..services.reports_autosign import autosign_if_possible

router = APIRouter(prefix="/reports/talhao", tags=["reports"])

@router.post("/generate")
def gen(talhao: str = Body("Talhão 1"),
        area_ha: float = Body(0.0),
        ndvi_medio: float = Body(0.0),
        zonas: list = Body([]),
        custos: dict = Body({}),
        logo_path: str = Body(None),
        user_name: str = Body("Usuário")):
    out = f"reports/talhao_{talhao}.pdf"
    r = gerar_relatorio_talhao(out, logo_path, user_name, talhao, area_ha, ndvi_medio, zonas, custos)
    signed = autosign_if_possible(r["out"])
    return {"ok": True, "out": signed}