from fastapi import APIRouter, Body
from pathlib import Path
import json, time

BASE = Path(__file__).resolve().parents[2]
INGE = BASE/"data"/"ingest"

router = APIRouter(prefix="/ingest", tags=["ingest-external"])

@router.post("/{provider}/webhook")
def provider_webhook(provider: str, payload: dict = Body(...)):
    p = (INGE/provider)
    p.mkdir(parents=True, exist_ok=True)
    fn = p/f"{int(time.time())}.json"
    fn.write_text(json.dumps(payload), encoding="utf-8")
    return {"ok": True, "stored": str(fn.relative_to(BASE))}

@router.get("/{provider}/list")
def provider_list(provider: str):
    p = (INGE/provider)
    arr = []
    if p.exists():
        for fp in sorted(p.glob("*.json"))[-20:]:
            arr.append(str(fp.relative_to(BASE)))
    return {"ok": True, "items": arr}