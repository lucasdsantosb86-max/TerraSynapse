import streamlit as st, requests, os, json

st.set_page_config(page_title="Lucro por Talhão (NDVI + Zonas)", page_icon="💰", layout="wide")
st.title("💰 Lucro por Talhão – NDVI → Zonas → Profit")

api = st.text_input("Backend URL", value=os.getenv("TS_BACKEND_URL","http://localhost:8000"))

c1,c2,c3 = st.columns(3)
culture = c1.selectbox("Cultura", ["soja","milho","cana","cafe","trigo"])
price = c2.number_input("Preço (R$/t)", 0.0, 100000.0, 1800.0)
yld   = c3.number_input("Produtividade base (t/ha)", 0.0, 100.0, 3.5)

st.subheader("NDVI")
area = st.number_input("Área total do talhão (ha)", 0.0, 1e7, 50.0)
th   = st.text_input("Thresholds (JSON)", "[0.33,0.66]")
ymap = st.text_input("Yield map (JSON)", "{"low":0.9,"mid":1.0,"high":1.1}")
file = st.file_uploader("NDVI (GeoTIFF) ou imagem RGB", type=["tif","tiff","png","jpg","jpeg"])

if st.button("Calcular Lucro com NDVI"):
    if not file:
        st.error("Envie um arquivo NDVI/RGB.")
    else:
        files={"ndvi_file": (file.name, file.getvalue(), file.type or "application/octet-stream")}
        data={"thresholds": th, "yield_map": ymap, "area_ha": area}
        r = requests.post(f"{api}/ndvi/segment", files=files, data=data).json()
        st.json(r)
        if r.get("ok"):
            zones = r["zones"]
            j = requests.post(f"{api}/profit/calc_zoned", params={"culture":culture,"price_per_t":price,"yield_t_ha":yld}, json=zones).json()
            st.subheader("Resultado")
            st.json(j)