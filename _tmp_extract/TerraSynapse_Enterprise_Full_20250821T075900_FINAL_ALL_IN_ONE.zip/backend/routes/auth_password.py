from fastapi import APIRouter, Body, Query
from ..services.auth_password import create_user, login, set_role, get_role

router = APIRouter(prefix="/auth", tags=["auth"])

@router.post("/password/create")
def create(email: str = Body(...), password: str = Body(...), role: str = Body("visitante")):
    return create_user(email, password, role)

@router.post("/password/login")
def login_(email: str = Body(...), password: str = Body(...)):
    return login(email, password)

@router.get("/role")
def role(user_id: str = Query(...)):
    return get_role(user_id)