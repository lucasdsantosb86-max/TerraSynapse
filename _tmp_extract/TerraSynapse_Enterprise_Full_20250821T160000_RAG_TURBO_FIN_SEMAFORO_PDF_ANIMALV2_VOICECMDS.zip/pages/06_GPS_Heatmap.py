
import streamlit as st, pandas as pd, numpy as np, requests
st.set_page_config(page_title='Heatmap GPS – TerraSynapse', page_icon='🐄', layout='wide')
st.title('🐄 Heatmap de deslocamento + km/dia por animal')
with st.expander('Upload de logs (JSONL ou NMEA por linha)'):
    up = st.file_uploader('Envie arquivo de logs', type=['jsonl','txt','log','nmea'])
    if up and st.button('Ingerir'):
        ok = requests.post('http://localhost:8000/ingest/gps', files={'file': (up.name, up.getvalue(), 'text/plain')})
        st.success('Ingestão realizada!' if ok.ok else 'Falha na ingestão.')
col1, col2 = st.columns(2)
with col1:
    date = st.date_input('Data', value=None)
    date_str = date.isoformat() if date else None
    r = requests.get('http://localhost:8000/gps/metrics', params={'date': date_str})
    data = r.json() if r.ok else {}
    df = pd.DataFrame([{'animal_id':k, **v} for k,v in data.items()])
    st.subheader('Distância por animal (km)')
    if not df.empty: st.dataframe(df, use_container_width=True)
    else: st.info('Sem dados.')
with col2:
    st.subheader('Heatmap (placeholder)'); st.caption('Para produção, renderize com Folium/leafmap.')
    import numpy as np, matplotlib.pyplot as plt
    arr = np.random.rand(64,64)
    fig, ax = plt.subplots(); c = ax.imshow(arr, cmap='inferno'); st.pyplot(fig)
