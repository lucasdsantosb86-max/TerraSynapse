from fastapi import APIRouter, Query
from ..services.reports_alerts import build_pdf

router = APIRouter(prefix="/reports/alerts", tags=["reports"])

@router.get("/pdf")
def pdf(start: str = Query(None), end: str = Query(None)):
    return build_pdf(start, end)