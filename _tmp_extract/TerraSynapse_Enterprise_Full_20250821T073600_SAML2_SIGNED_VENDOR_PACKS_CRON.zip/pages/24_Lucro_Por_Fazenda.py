import streamlit as st, requests, os, pandas as pd

st.set_page_config(page_title="Lucro por Fazenda (Ranking)", page_icon="🏆", layout="wide")
st.title("🏆 Ranking – Lucro por Fazenda")

api = st.text_input("Backend URL", value=os.getenv("TS_BACKEND_URL","http://localhost:8000"))
user_id = st.text_input("Seu e-mail (para permissões)", "lucas@empresa.com")

# Guard (engenheiro=gestor)
import requests as rq
role_api = api + "/auth/role"
_res = rq.get(role_api, params={"user_id": user_id}).json()
_user_role = (_res.get("role") or "visitante").lower()
_allowed = {"gestor","integrador","engenheiro"}
if _user_role not in _allowed:
    st.error(f"Acesso restrito. Seu papel: '{_user_role}'. Permitidos: {', '.join(_allowed)}")
    st.stop()

try:
    hist = requests.get(f"{api}/profit/store/list", params={"limit": 1000}).json()
    items = hist.get("items", [])
    if not items:
        st.info("Sem análises salvas ainda.")
    else:
        import pandas as pd
        df = pd.DataFrame(items)
        if "fazenda" not in df.columns:
            st.warning("Registros não possuem 'fazenda'. Salve novas análises com campo 'fazenda'.")
        else:
            st.subheader("Lucro total por fazenda")
            g = df.groupby("fazenda")["lucro_total"].sum().sort_values(ascending=False)
            st.dataframe(g.reset_index().rename(columns={"lucro_total":"lucro_total_R$"}))
            st.bar_chart(g)
            st.subheader("Top talhões")
            st.dataframe(df.sort_values("lucro_total", ascending=False)[["fazenda","talhao","cultura","lucro_total"]].head(20))
except Exception as e:
    st.warning(f"Não foi possível carregar dados: {e}")

import requests as rq, os
role_api = os.getenv("TS_BACKEND_URL","http://localhost:8000") + "/auth/role"
_res = rq.get(role_api, params={"user_id": user_id}).json()
_user_role = (_res.get("role") or "visitante").lower()
_allowed = set(['gestor', 'integrador', 'engenheiro'])
if _user_role not in _allowed:
    import streamlit as st
    st.error(f"Acesso restrito. Seu papel: '{_user_role}'. Permitidos: {', '.join(_allowed)}"); st.stop()
