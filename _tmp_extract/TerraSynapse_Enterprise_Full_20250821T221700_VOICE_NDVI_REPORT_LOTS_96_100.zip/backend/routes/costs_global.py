from fastapi import APIRouter, Body
from ..services.costs_global import normalize_csv
from pathlib import Path

router = APIRouter(prefix="/costs/global", tags=["costs"])

@router.post("/normalize")
def normalize(src: str = Body(...)):
    out = Path(src).with_suffix(".normalized.csv")
    return normalize_csv(src, str(out))