from fastapi import APIRouter, Body
from ..services.vra_prescription import generate

router = APIRouter(prefix="/vra", tags=["vra"])

@router.post("/generate")
def gen(payload: dict = Body(...)):
    return generate(payload)