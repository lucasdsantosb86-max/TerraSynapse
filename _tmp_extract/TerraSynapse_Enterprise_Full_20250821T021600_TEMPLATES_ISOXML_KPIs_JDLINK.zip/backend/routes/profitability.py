from fastapi import APIRouter, Query
from ..services.profitability import calc_profit

router = APIRouter(prefix="/profit", tags=["profitability"])

@router.get("/calc")
def calc(culture: str, area_ha: float, price_per_t: float, yield_t_ha: float):
    return calc_profit(culture, area_ha, price_per_t, yield_t_ha)