from .branding import resolve_brand

def render_html(email: str, title: str, body: str):
    b = resolve_brand(email)
    primary = b.get("colors",{}).get("primary","#2E7D32")
    brand = b.get("brand","TerraSynapse")
    return f"""
<!doctype html>
<html><body style="font-family:Inter,Arial,sans-serif;">
  <div style="max-width:720px;margin:0 auto;border:1px solid #eee;border-radius:12px;overflow:hidden">
    <div style="background:{primary};color:#fff;padding:16px 20px;font-weight:700">{brand}</div>
    <div style="padding:20px">
      <h2 style="margin:0 0 8px 0;">{title}</h2>
      <div style="color:#333;line-height:1.5">{body}</div>
    </div>
    <div style="background:#f7f7f7;color:#666;padding:12px 20px;font-size:12px">Enviado automaticamente pela plataforma TerraSynapse.</div>
  </div>
</body></html>
"""