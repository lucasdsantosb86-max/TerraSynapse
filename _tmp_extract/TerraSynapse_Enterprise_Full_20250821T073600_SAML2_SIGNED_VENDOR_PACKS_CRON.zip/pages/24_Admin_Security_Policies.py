import streamlit as st, json, os, requests

st.set_page_config(page_title="Admin – Políticas de Segurança", page_icon="⚙️", layout="wide")
st.title("⚙️ Admin – Políticas de Segurança")

api = st.text_input("Backend URL", value=os.getenv("TS_BACKEND_URL","http://localhost:8000"))

st.subheader("Regras de Senha & 2FA por Role")
min_len = st.number_input("Tamanho mínimo de senha", 8, 64, 10)
expiry = st.number_input("Expiração (dias)", 30, 365, 180)
roles = st.multiselect("Roles que exigem 2FA", ["developer","gestor","admin","tecnico","operador"], default=["developer","gestor","admin"])

if st.button("Salvar políticas"):
    import json, pathlib
    p = pathlib.Path("config/security.json")
    sec = json.loads(p.read_text(encoding="utf-8"))
    sec["password_policy"] = {"min_length": int(min_len), "expiry_days": int(expiry), "forbid_reuse": 5}
    sec["roles_require_2fa"] = roles
    p.write_text(json.dumps(sec, indent=2), encoding="utf-8")
    st.success("Políticas atualizadas.")

st.markdown("---")
st.subheader("CSP por Ambiente")
env = st.selectbox("Ambiente", ["dev","prod"])
connect = st.text_area("connect-src (um por linha)", "\n".join(["'self'","http://localhost:8000","https://api.openweathermap.org","https://api.climatempo.com.br"]))
if st.button("Aplicar CSP"):
    import json, pathlib
    p = pathlib.Path("config/csp.json")
    csp = json.loads(p.read_text(encoding="utf-8"))
    csp["env"] = env
    lst = [ln.strip() for ln in connect.splitlines() if ln.strip()]
    csp[env]["connect_src"] = lst
    p.write_text(json.dumps(csp, indent=2), encoding="utf-8")
    st.success("CSP atualizado.")