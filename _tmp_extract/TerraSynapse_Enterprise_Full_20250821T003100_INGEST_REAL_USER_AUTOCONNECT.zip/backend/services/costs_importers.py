import pandas as pd
import requests, json, time
from pathlib import Path
from dateutil import parser as dparser

BASE = Path(__file__).resolve().parents[2]
DATA = BASE/"data"/"costs"/"sources"
DATA.mkdir(parents=True, exist_ok=True)

def _save(df: pd.DataFrame, name: str):
    out = DATA/f"{name}_{int(time.time())}.csv"
    df.to_csv(out, index=False)
    meta = {"name": name, "rows": len(df), "file": str(out)}
    Path(str(out)+".meta.json").write_text(json.dumps(meta, indent=2), encoding="utf-8")
    return {"ok": True, "meta": meta}

def _norm_schema(df: pd.DataFrame, source: str):
    cols = {c.lower(): c for c in df.columns}
    # mapeamento simples; ajuste conforme fonte real
    df = df.rename(columns={
        cols.get("item","item"): "item",
        cols.get("unidade","unit") if "unidade" in cols else cols.get("unit","unit"): "unit",
        cols.get("preco","price") if "preco" in cols else cols.get("price","price_local"): "price_local",
        cols.get("moeda","currency") if "moeda" in cols else cols.get("currency","currency"): "currency",
        cols.get("data","date") if "data" in cols else cols.get("date","date"): "date",
        cols.get("regiao","region") if "regiao" in cols else cols.get("region","region"): "region",
    })
    df["source"] = source
    # normalização de data
    def parse_dt(x):
        try: return dparser.parse(str(x)).date().isoformat()
        except: return str(x)
    if "date" in df.columns:
        df["date"] = df["date"].map(parse_dt)
    return df[["item","unit","price_local","currency","date","region","source"]].copy()

def import_imea(url: str):
    # stub: CSV público
    df = pd.read_csv(url)
    return _save(_norm_schema(df, "IMEA"), "imea")

def import_conab(url: str):
    df = pd.read_csv(url)
    return _save(_norm_schema(df, "CONAB"), "conab")

def import_usda(url: str):
    df = pd.read_csv(url)
    return _save(_norm_schema(df, "USDA"), "usda")

def import_eurostat(url: str):
    df = pd.read_csv(url)
    return _save(_norm_schema(df, "Eurostat"), "eurostat")