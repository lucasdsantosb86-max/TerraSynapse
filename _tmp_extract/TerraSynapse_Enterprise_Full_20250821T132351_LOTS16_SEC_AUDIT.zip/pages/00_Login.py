
import streamlit as st
from frontend.auth import login_form, logout_button

st.set_page_config(page_title="Login – TerraSynapse IA", page_icon="🔐", layout="centered")
st.title("TerraSynapse IA — Acesso")
if "user" in st.session_state:
    st.success(f"Você já está logado como: {st.session_state['user']['display']}")
    logout_button()
else:
    login_form()
