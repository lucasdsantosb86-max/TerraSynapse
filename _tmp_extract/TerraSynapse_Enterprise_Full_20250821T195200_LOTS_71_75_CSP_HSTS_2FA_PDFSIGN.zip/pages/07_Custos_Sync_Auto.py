import json, requests, pandas as pd, streamlit as st
from pathlib import Path
from io import BytesIO
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib import colors
from reportlab.lib.units import cm
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet

st.set_page_config(page_title="Custos – Sync (Auto)", page_icon="⚙️")
st.title("⚙️ Custos – Sync (Auto) — 1 clique")

backend = st.text_input("Backend URL", value="http://localhost:8000")
cfg_path = Path(__file__).resolve().parents[1]/"data"/"costs"/"auto_links.json"
auto = json.loads(cfg_path.read_text(encoding="utf-8")) if cfg_path.exists() else {}

def do_sync(label, url, endpoint):
    st.write(f"Baixando **{label}**…")
    try:
        r = requests.post(f"{backend}{endpoint}", json={"url": url}, timeout=120).json()
        st.success(r)
    except Exception as e:
        st.error(e)

st.subheader("USDA ERS")
for item in auto.get("usda_ers", []):
    if st.button(f"Sync: {item['name']}"):
        do_sync(item["name"], item["url"], "/costs/sync/usda")

st.subheader("CONAB")
for item in auto.get("conab", []):
    if st.button(f"Sync: {item['name']}"):
        do_sync(item["name"], item["url"], "/costs/sync/conab")

st.subheader("IMEA")
for item in auto.get("imea", []):
    if st.button(f"Sync: {item['name']}"):
        do_sync(item["name"], item["url"], "/costs/sync/imea")

st.subheader("World Bank – Pink Sheet (fertilizantes)")
for item in auto.get("worldbank", []):
    if st.button(f"Sync: {item['name']}"):
        st.info("Cole a URL correta do Pink Sheet se este link variar.")

st.divider()
st.subheader("Arquivos baixados")
try:
    files = requests.get(f"{backend}/costs/files", timeout=10).json().get("files", [])
    st.write(files)
except Exception as e:
    st.error(e)

st.divider()
st.subheader("Gerar PDF comparativo (R$/ha por cultura/país)")
culturas = st.text_input("Culturas (vírgula)", value="soja,milho,trigo")
regioes = st.text_input("Regiões/Países (vírgula)", value="BR-MT,US,AR-BuenosAires")
if st.button("Gerar PDF"):
    # Carrega benchmarks existentes
    import json, glob
    data = []
    for fp in glob.glob(str(Path(__file__).resolve().parents[1]/"data"/"costs"/"benchmarks_*.jsonl")):
        for line in open(fp, "r", encoding="utf-8").read().splitlines():
            if not line.strip(): 
                continue
            data.append(json.loads(line))

    # Filtra algumas métricas úteis
    C = [c.strip().lower() for c in culturas.split(",") if c.strip()]
    R = [r.strip() for r in regioes.split(",") if r.strip()]
    rows = []
    for d in data:
        c = str(d.get("culture","")).lower()
        r = str(d.get("region",""))
        if C and c not in C: 
            continue
        if R and r not in R:
            continue
        metric = d.get("metric","")
        if any(x in metric.lower() for x in ["coe_r$_ha","fertilizantes","sementes","fertilizer_usd_ha"]):
            rows.append([d.get("region",""), d.get("culture",""), d.get("metric",""), d.get("value",""), d.get("currency",""), d.get("source","")])

    if not rows:
        st.warning("Sem dados filtrados. Sincronize planilhas e/ou amplie filtros.")
    else:
        # Gera PDF
        buf = BytesIO()
        doc = SimpleDocTemplate(buf, pagesize=landscape(A4))
        styles = getSampleStyleSheet()
        story = [Paragraph("TerraSynapse – Comparativo de Custos (R$/ha)", styles["Title"]), Spacer(1, 0.4*cm)]
        data_tbl = [["Região","Cultura","Métrica","Valor","Moeda","Fonte"]] + rows
        t = Table(data_tbl, repeatRows=1)
        t.setStyle(TableStyle([
            ("BACKGROUND",(0,0),(-1,0), colors.HexColor("#1565C0")),
            ("TEXTCOLOR",(0,0),(-1,0), colors.white),
            ("GRID",(0,0),(-1,-1), 0.25, colors.grey),
            ("FONT",(0,0),(-1,0), "Helvetica-Bold"),
            ("ROWBACKGROUNDS",(0,1),(-1,-1), [colors.whitesmoke, colors.HexColor("#E8F5E9")]),
        ]))
        story.append(t)
        doc.build(story)
        st.success("PDF gerado.")
        st.download_button("Baixar PDF", data=buf.getvalue(), file_name="comparativo_custos.pdf", mime="application/pdf")