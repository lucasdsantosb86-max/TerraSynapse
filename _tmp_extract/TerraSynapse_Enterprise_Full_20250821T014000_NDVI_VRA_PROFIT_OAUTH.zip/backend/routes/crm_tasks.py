from fastapi import APIRouter, Body, Query
from ..services.crm_tasks import list_tasks, get_task, create_task, update_task, delete_task, list_tasks_by

router = APIRouter(prefix="/crm/tasks", tags=["crm-tasks"])

@router.get("")
def all(client_id: str = Query(None), assignee_id: str = Query(None), status: str = Query(None)):
    items = list_tasks()
    if client_id: items = [t for t in items if t.get("client_id")==client_id]
    if assignee_id: items = [t for t in items if t.get("assignee_id")==assignee_id]
    if status: items = [t for t in items if t.get("status")==status]
    return {"ok": True, "items": items}

@router.get("/{tid}")
def one(tid: str):
    t = get_task(tid)
    return {"ok": bool(t), "item": t}

@router.post("")
def create(obj: dict = Body(...)):
    # defaults
    obj.setdefault("status","novo")
    obj.setdefault("priority","média")
    return {"ok": True, "item": create_task(obj)}

@router.put("/{tid}")
def upd(tid: str, patch: dict = Body(...)):
    return {"ok": True, "item": update_task(tid, patch)}

@router.delete("/{tid}")
def rem(tid: str):
    return {"ok": True, **delete_task(tid)}