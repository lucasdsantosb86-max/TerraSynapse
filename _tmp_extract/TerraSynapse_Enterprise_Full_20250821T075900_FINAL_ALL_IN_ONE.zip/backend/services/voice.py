from pathlib import Path
import json
try:
    import pyttsx3
except Exception:
    pyttsx3 = None

BASE = Path(__file__).resolve().parents[2]
CONF = BASE/"config"/"voice.json"
AUDIO = BASE/"static"/"audio"
AUDIO.mkdir(parents=True, exist_ok=True)

def _cfg():
    try:
        return json.loads(CONF.read_text(encoding="utf-8"))
    except Exception:
        return {"enabled": False}

def tts(text: str, filename: str = "tts.wav"):
    cfg = _cfg()
    if not cfg.get("enabled") or cfg.get("tts") != "pyttsx3" or not pyttsx3:
        return {"ok": False, "error":"tts_disabled"}
    engine = pyttsx3.init()
    out = AUDIO/filename
    engine.save_to_file(text, str(out))
    engine.runAndWait()
    return {"ok": True, "file": str(out.relative_to(BASE))}