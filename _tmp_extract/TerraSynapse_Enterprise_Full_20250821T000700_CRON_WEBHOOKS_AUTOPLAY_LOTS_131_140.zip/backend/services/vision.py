from __future__ import annotations
import io, json
from pathlib import Path
from typing import Dict, Any, Optional
from PIL import Image

LABELS_PATH = Path("backend/models/labels/labels_culturas_agro.json")

def _load_labels() -> Dict[str, Any]:
    data = json.loads(LABELS_PATH.read_text(encoding="utf-8"))
    return data

def analyze_plant_image(file_bytes: bytes, cultura_hint: Optional[str]=None) -> Dict[str, Any]:
    """
    Stub ONNX: carrega imagem e retorna rótulos prováveis a partir do catálogo (sem inferência real).
    """
    labels = _load_labels()
    candidates = labels.get(cultura_hint or "soja", [])
    img = Image.open(io.BytesIO(file_bytes)).convert("RGB")
    width, height = img.size
    top = candidates[:3] if candidates else []
    scored = [{"label": lbl, "score": round(0.80 - i*0.1, 2)} for i, lbl in enumerate(top)]
    return {"ok": True, "width": width, "height": height, "cultura": cultura_hint, "predictions": scored}

def analyze_animal_image(file_bytes: bytes, especie: Optional[str]="bovinos") -> Dict[str, Any]:
    labels = _load_labels().get("animal_regions", {})
    # retorna duas hipóteses por região como demonstração
    regions = {k: v[:2] for k, v in labels.items()}
    img = Image.open(io.BytesIO(file_bytes)).convert("RGB")
    w, h = img.size
    return {"ok": True, "species": especie, "width": w, "height": h, "regions": regions, "severity": "moderada"}
