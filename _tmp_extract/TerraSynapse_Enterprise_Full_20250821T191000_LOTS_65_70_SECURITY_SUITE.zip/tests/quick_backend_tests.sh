#!/usr/bin/env bash
set -e
echo "[1] Ping"
curl -s http://localhost:8000/health/ping | jq
echo "[2] Ingest GPS"
curl -s -X POST -H 'Content-Type: application/json' --data-binary @data/gps/sample.jsonl http://localhost:8000/ingest/gps | jq
echo "[3] Métricas GPS"
curl -s 'http://localhost:8000/gps/metrics?date=2025-08-20' | jq
