from fastapi import APIRouter, Body
from ..services.rag_turbo import build_cache, search, warm_startup

router = APIRouter(prefix="/rag", tags=["rag"])

@router.post("/warm")
def warm(category: str = Body(default="all")):
    if isinstance(category, list):
        # permite enviar lista
        return warm_startup(category)
    return build_cache(category)

@router.post("/search")
def rag_search(query: str = Body(...), category: str = Body(default="all"), top_k: int = Body(default=8), profile: str = Body(default="")):
    return search(query, category, top_k, profile)