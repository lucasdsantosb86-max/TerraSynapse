import streamlit as st, requests, os, json, pandas as pd

st.set_page_config(page_title="Lucro por Talhão – Consolidado", page_icon="💵", layout="wide")
st.title("💵 Lucro por Talhão – NDVI → Zonas → VRA → Custo → Lucro")

api = st.text_input("Backend URL", value=os.getenv("TS_BACKEND_URL","http://localhost:8000"))
user_id = st.text_input("Seu e-mail (para perfil e permissões)", "lucas@empresa.com")

st.markdown("### Cadastrar/Atualizar análise")
with st.form("calc"):
    faz = st.text_input("Fazenda", "Fazenda Modelo")
    tal = st.text_input("Talhão", "T01")
    cultura = st.text_input("Cultura", "soja")
    base_prod = st.number_input("Produtividade base (t/ha)", 0.0, 30.0, 3.6)
    preco = st.number_input("Preço (R$/t)", 0.0, 10000.0, 1800.0)
    zones_json = st.text_area("Zonas (JSON do /ndvi/segment)", '[{"zone_id":1,"class":"low","area_ha":10,"yield_factor":0.9},{"zone_id":2,"class":"mid","area_ha":15,"yield_factor":1.0},{"zone_id":3,"class":"high","area_ha":5,"yield_factor":1.1}]', height=200)
    custos = st.number_input("Custo total (R$/ha)", 0.0, 20000.0, 3200.0, help="Inclui semente/adubo/defensivos/máquinas")
    salvar = st.checkbox("Salvar este resultado", value=True)
    submitted = st.form_submit_button("Calcular")
    if submitted:
        try:
            zones = json.loads(zones_json)
        except Exception as e:
            st.error(f"JSON inválido das zonas: {e}")
            zones = None
        if zones:
            # calcula lucro por zona
            rows = []
            lucro_total = 0.0
            for z in zones:
                area = float(z.get("area_ha") or 0.0)
                yf   = float(z.get("yield_factor") or 1.0)
                prod = base_prod * yf
                receita_ha = prod * preco
                lucro_ha = receita_ha - custos
                lucro_z = lucro_ha * area
                lucro_total += lucro_z
                rows.append({"zona": z.get("class"), "area_ha": area, "yield_factor": yf, "prod_t_ha": prod, "R$/ha": receita_ha, "Custo_ha": custos, "Lucro_ha": lucro_ha, "Lucro_zona": lucro_z})
            df = pd.DataFrame(rows)
            st.subheader("Resultado por zona")
            st.dataframe(df)
            st.metric("Lucro total (R$)", f"{lucro_total:,.2f}".replace(",", "X").replace(".", ",").replace("X", "."))
            st.bar_chart(df.set_index("zona")[["Lucro_ha"]])
            if salvar:
                payload = {"user_id": user_id, "fazenda": faz, "talhao": tal, "cultura": cultura, "base_prod_t_ha": base_prod, "preco_r_t": preco, "custo_r_ha": custos, "zones": zones, "lucro_total": lucro_total}
                try:
                    j = requests.post(f"{api}/profit/store/save", json=payload).json()
                    st.success(f"Salvo: {j}")
                except Exception as e:
                    st.warning(f"Não foi possível salvar: {e}")

st.markdown("---")
st.markdown("### Histórico e comparação")
try:
    hist = requests.get(f"{api}/profit/store/list", params={"limit": 100}).json()
    items = hist.get("items", [])
    if items:
        dfh = pd.DataFrame(items)
        st.dataframe(dfh[["ts","fazenda","talhao","cultura","lucro_total","user_id"]].sort_values("ts", ascending=False))
        st.line_chart(dfh[["lucro_total"]])
    else:
        st.info("Sem histórico salvo ainda.")
except Exception as e:
    st.warning(f"Não foi possível listar histórico: {e}")

import requests, streamlit as st, os
role_api = os.getenv("TS_BACKEND_URL","http://localhost:8000") + "/auth/role"
_res = requests.get(role_api, params={"user_id": user_id}).json()
_user_role = (_res.get("role") or "visitante").lower()
_allowed = set(['gestor', 'integrador', 'engenheiro'])
if _user_role not in _allowed:
    st.error(f"Acesso restrito. Seu papel: '{_user_role}'. Permitidos: {', '.join(_allowed)}")
    st.stop()
