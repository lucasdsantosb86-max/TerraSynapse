import streamlit as st, requests, os, json

st.set_page_config(page_title="Profitabilidade por Talhão", page_icon="💹", layout="wide")
st.title("💹 Profitabilidade por Talhão (live)")

api = st.text_input("Backend URL", value=os.getenv("TS_BACKEND_URL","http://localhost:8000"))

c1,c2,c3,c4 = st.columns(4)
culture = c1.selectbox("Cultura", ["soja","milho","cana","cafe","trigo"])
area_ha = c2.number_input("Área (ha)", 0.0, 1e6, 50.0)
price = c3.number_input("Preço (R$/t)", 0.0, 100000.0, 1800.0)
yld   = c4.number_input("Produtividade (t/ha)", 0.0, 100.0, 3.5)

if st.button("Calcular"):
    j = requests.get(f"{api}/profit/calc", params={"culture":culture,"area_ha":area_ha,"price_per_t":price,"yield_t_ha":yld}).json()
    st.json(j)
    if j.get("ok"):
        per = j["per_ha"]; tot = j["total"]
        st.metric("Margem por ha (R$)", f"{per['margin']:.2f}", delta=None)
        st.metric("Margem total (R$)", f"{tot['margin']:.2f}")