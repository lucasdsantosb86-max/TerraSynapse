from pathlib import Path
import json, time
from passlib.hash import bcrypt

BASE = Path(__file__).resolve().parents[2]
USERS = BASE/"config"/"users_db.json"
ROLES = BASE/"config"/"users_roles.json"

def _load(fp):
    try:
        return json.loads(fp.read_text(encoding="utf-8"))
    except Exception:
        return {}

def _save(fp, data):
    fp.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")

def create_user(email: str, password: str, role: str = "visitante"):
    email = (email or "").lower().strip()
    if not email or not password:
        return {"ok": False, "error":"missing_fields"}
    users = _load(USERS)
    if email in users:
        return {"ok": False, "error":"already_exists"}
    users[email] = {"hash": bcrypt.hash(password), "created_at": int(time.time())}
    _save(USERS, users)
    # set role
    roles = _load(ROLES); roles[email] = role; _save(ROLES, roles)
    return {"ok": True, "email": email, "role": role}

def set_role(email: str, role: str):
    roles = _load(ROLES); roles[email] = role; _save(ROLES, roles)
    return {"ok": True, "email": email, "role": role}

def login(email: str, password: str):
    email = (email or "").lower().strip()
    users = _load(USERS)
    u = users.get(email)
    if not u: return {"ok": False, "error":"user_not_found"}
    if bcrypt.verify(password, u.get("hash")):
        return {"ok": True, "email": email}
    return {"ok": False, "error":"invalid_password"}

def get_role(email: str):
    roles = _load(ROLES)
    return {"ok": True, "role": roles.get(email, "visitante")}