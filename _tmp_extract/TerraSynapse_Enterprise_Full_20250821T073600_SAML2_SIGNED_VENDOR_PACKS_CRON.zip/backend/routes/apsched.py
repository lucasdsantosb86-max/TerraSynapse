from fastapi import APIRouter, Body
from ..services.apsched import start_scheduler, stop_scheduler, status_scheduler

router = APIRouter(prefix="/scheduler", tags=["scheduler"])

@router.post("/start")
def start(api_base: str = Body("http://localhost:8000")):
    return start_scheduler(api_base)

@router.post("/stop")
def stop():
    return stop_scheduler()

@router.get("/status")
def status():
    return status_scheduler()