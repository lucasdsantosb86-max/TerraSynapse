from fastapi import APIRouter
import time

router = APIRouter(prefix="", tags=["health"])

@router.get("/health")
def health():
    return {"ok": True, "ts": int(time.time()), "service":"backend"}

@router.get("/ready")
def ready():
    return {"ok": True}