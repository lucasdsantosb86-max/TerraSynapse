import json
from pathlib import Path
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.types import ASGIApp

BASE = Path(__file__).resolve().parents[2]
CSPF = BASE/"config"/"csp.json"

def _csp():
    try:
        cfg = json.loads(CSPF.read_text(encoding="utf-8"))
        env = cfg.get("env","dev")
        return cfg.get(env, {})
    except Exception:
        return {}

def _join(vals):
    return " ".join(vals) if isinstance(vals, list) else str(vals)

class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    def __init__(self, app: ASGIApp):
        super().__init__(app)
    async def dispatch(self, request, call_next):
        response = await call_next(request)
        response.headers['Strict-Transport-Security'] = 'max-age=15552000; includeSubDomains'
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['X-Frame-Options'] = 'DENY'
        response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
        c = _csp()
        csp = "default-src {d}; img-src {i}; media-src {m}; style-src {s}; script-src {j}; connect-src {k}; frame-ancestors {f}".format(
            d=_join(c.get("default_src",["'self'"])),
            i=_join(c.get("img_src",["'self'","data:","blob:"])),
            m=_join(c.get("media_src",["'self'","data:"])),
            s=_join(c.get("style_src",["'self'"])),
            j=_join(c.get("script_src",["'self'"])),
            k=_join(c.get("connect_src",["'self'"])),
            f=_join(c.get("frame_ancestors",["'none'"])),
        )
        response.headers['Content-Security-Policy'] = csp
        return response