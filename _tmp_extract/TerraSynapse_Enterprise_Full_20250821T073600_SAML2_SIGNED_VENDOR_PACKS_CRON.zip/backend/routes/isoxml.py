from fastapi import APIRouter, Body, Query
from typing import List, Dict, Any
from ..services.isoxml_profiles import load_profiles, validate_zones, export_zip, make_taskdata_xml, validate_xml, make_taskdata_xml_full

router = APIRouter(prefix="/isoxml", tags=["isoxml"])

@router.get("/profiles")
def profiles():
    return {"ok": True, "profiles": load_profiles()}

@router.post("/export")
def export(profile: str = Body(...), job_name: str = Body(...), culture: str = Body(...), zones: List[dict] = Body(...)):
    errs = validate_zones(zones)
    if errs:
        return {"ok": False, "errors": errs}
    path = export_zip(profile, job_name, culture, zones)
    return {"ok": True, "zip": path}

@router.post("/validate")
def validate(xml_text: str = Body(...)):
    return validate_xml(xml_text)

@router.post("/validate_xsd")
def validate_xsd(xml_text: str = Body(...)):
    from ..services.isoxml_validator import validate_with_xsd
    return validate_with_xsd(xml_text)

@router.post("/export_full")
def export_full(profile: str = Body(...), job_name: str = Body(...), culture: str = Body(...),
                zones: List[dict] = Body(...), asap: str = Body(""), grd: str = Body(""), pln: str = Body("")):
    errs = validate_zones(zones)
    if errs:
        return {"ok": False, "errors": errs}
    xml = make_taskdata_xml_full(profile, job_name, culture, zones, asap, grd, pln)
    return {"ok": True, "xml": xml}
