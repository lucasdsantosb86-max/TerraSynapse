# Cálculo de insumos por área, usando taxas por cultura e preço opcional
import json
from pathlib import Path

DATA = Path(__file__).resolve().parents[2]/"data"
RATES_PATH = DATA/"knowledge"/"insumos_por_cultura.json"
PRICES_PATH = DATA/"prices"/"precos_insumos.json"

def load_rates():
    if RATES_PATH.exists():
        return json.loads(RATES_PATH.read_text(encoding="utf-8"))
    return {}

def load_prices():
    if PRICES_PATH.exists():
        return json.loads(PRICES_PATH.read_text(encoding="utf-8"))
    return {}

def compute_inputs(cultura: str, area_ha: float):
    rates = load_rates().get(cultura.lower(), {})
    prices = load_prices()
    out = {"cultura": cultura, "area_ha": area_ha, "itens": [], "total_R$": 0.0}
    for item, taxa in rates.items():
        qtd = float(taxa) * float(area_ha)  # taxa na unidade do item (ex.: kg/ha, L/ha, mil sementes/ha)
        preco = float(prices.get(item, 0.0))
        custo = qtd * preco
        out["itens"].append({"insumo": item, "taxa_por_ha": taxa, "quantidade": qtd, "preco_unit": preco, "custo_R$": custo})
        out["total_R$"] += custo
    return out