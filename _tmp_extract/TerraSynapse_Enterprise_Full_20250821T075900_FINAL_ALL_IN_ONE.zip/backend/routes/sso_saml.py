from fastapi import APIRouter, Body, Query
from ..services.sso_saml import list_providers, set_providers, start, acs

router = APIRouter(prefix="/sso/saml", tags=["sso-saml"])

@router.get("/providers")
def providers():
    return list_providers()

@router.post("/providers/set")
def providers_set(payload: dict = Body(...)):
    return set_providers(payload)

@router.get("/start")
def start_auth(provider: str = Query(...), user_id: str = Query(...)):
    return start(provider, user_id)

@router.post("/acs")
def assertion_consume(provider: str = Query(...), SAMLResponse: str = Body(...), RelayState: str = Body("")):
    return acs(provider, SAMLResponse, RelayState)