import time, json
from pathlib import Path

CONF = Path(__file__).resolve().parents[2]/"config"/"sensors_aqua.json"
LOGS = Path(__file__).resolve().parents[2]/"data"/"mqtt"
LOGS.mkdir(parents=True, exist_ok=True)

def _load_conf():
    return json.loads(CONF.read_text(encoding="utf-8"))

def eval_rules(sample: dict, conf: dict):
    sensor = sample.get("sensor")
    val = sample.get("value")
    ts = sample.get("ts", int(time.time()*1000))
    farm = sample.get("farm"); tank = sample.get("tank")
    rules = conf["rules"].get(sensor)
    if not rules: return {"status":"ok"}
    status = "ok"
    if rules.get("direction")=="min":
        if val < rules["crit"]: status = "crit"
        elif val < rules["warn"]: status = "warn"
    elif rules.get("direction")=="max":
        if val > rules["crit"]: status = "crit"
        elif val > rules["warn"]: status = "warn"
    elif rules.get("direction")=="range":
        low, high = rules.get("warn_low"), rules.get("warn_high")
        if val<low or val>high: status = "warn"
    out = {"status":status,"sensor":sensor,"value":val,"farm":farm,"tank":tank,"ts":ts}
    # append to log
    logp = LOGS/f"{farm}_{tank}_{sensor}.jsonl"
    with logp.open("a", encoding="utf-8") as f:
        f.write(json.dumps({**sample, **out}, ensure_ascii=False)+"
")
    return out