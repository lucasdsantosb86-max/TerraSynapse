from pathlib import Path
import io, json
import numpy as np

def _read_ndvi_bytes(content: bytes):
    # tenta rasterio (GeoTIFF) → senão cai para imagem PIL (RGB) usando proxy NDVI
    try:
        import rasterio
        with rasterio.MemoryFile(content) as mem:
            with mem.open() as src:
                arr = src.read(1).astype("float32")
                # normaliza tentativa: se estiver em int16 com escala 1e4
                if np.nanmax(arr) > 1.5:
                    arr = arr / 10000.0
                arr = np.clip(arr, -1, 1)
                return arr
    except Exception:
        pass
    # fallback: imagem RGB → proxy NDVI = (G - R) / (G + R + eps)
    from PIL import Image
    im = Image.open(io.BytesIO(content)).convert("RGB")
    arr = np.asarray(im).astype("float32")
    R = arr[:,:,0]; G = arr[:,:,1]
    ndvi_proxy = (G - R) / (G + R + 1e-6)
    # reescala ~[-1,1]
    ndvi_proxy = np.clip(ndvi_proxy, -1, 1)
    return ndvi_proxy

def segment_ndvi(content: bytes, thresholds=(0.33,0.66), yield_map=None, area_ha: float = None):
    ndvi = _read_ndvi_bytes(content)
    # normaliza para [0,1] para threshold '%'
    nd01 = (ndvi - np.nanmin(ndvi)) / (np.nanmax(ndvi) - np.nanmin(ndvi) + 1e-9)
    t1, t2 = thresholds
    z_low  = nd01 < t1
    z_mid  = (nd01 >= t1) & (nd01 < t2)
    z_high = nd01 >= t2
    counts = [int(z_low.sum()), int(z_mid.sum()), int(z_high.sum())]
    total = sum(counts) or 1
    props = [c/total for c in counts]
    # yield_map padrão
    if not yield_map:
        yield_map = {"low":0.90, "mid":1.00, "high":1.10}
    # áreas por zona
    if area_ha is None:
        area_ha = 1.0
    areas = [p*area_ha for p in props]
    zones = [
        {"zone_id": 1, "class":"low",  "prop": props[0], "area_ha": areas[0], "yield_factor": yield_map.get("low",0.90)},
        {"zone_id": 2, "class":"mid",  "prop": props[1], "area_ha": areas[1], "yield_factor": yield_map.get("mid",1.00)},
        {"zone_id": 3, "class":"high", "prop": props[2], "area_ha": areas[2], "yield_factor": yield_map.get("high",1.10)},
    ]
    return {"ok": True, "zones": zones, "thresholds": thresholds, "area_ha": area_ha}