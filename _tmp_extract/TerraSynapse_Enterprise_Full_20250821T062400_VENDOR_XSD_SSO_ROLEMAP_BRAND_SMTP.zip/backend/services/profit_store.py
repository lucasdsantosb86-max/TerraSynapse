from pathlib import Path
import json, time, uuid

BASE = Path(__file__).resolve().parents[2]
DIR  = BASE/"data"/"profit"
DIR.mkdir(parents=True, exist_ok=True)

def save_record(payload: dict):
    rid = payload.get("id") or str(uuid.uuid4())
    payload["id"] = rid
    payload["ts"] = int(time.time())
    fp = DIR/f"{rid}.json"
    fp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"ok": True, "id": rid}

def list_records(limit: int = 100):
    items = []
    for fp in sorted(DIR.glob("*.json"))[-limit:]:
        try:
            items.append(json.loads(fp.read_text(encoding="utf-8")))
        except: pass
    # mais recentes primeiro
    items = sorted(items, key=lambda x: x.get("ts", 0), reverse=True)
    return {"ok": True, "items": items}