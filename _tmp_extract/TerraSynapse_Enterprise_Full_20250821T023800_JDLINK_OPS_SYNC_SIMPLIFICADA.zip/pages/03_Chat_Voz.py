import streamlit as st, requests, os, io, time
st.set_page_config(page_title="Chat – Voz (Offline)", page_icon="🎤", layout="centered")
st.title("🎤 Chat – Voz (Offline STT/TTS)")

api = st.text_input("Backend URL", value=os.getenv("TS_BACKEND_URL","http://localhost:8000"))

st.subheader("Falar com a IA (enviar áudio WAV)")
aud = st.file_uploader("Envie um arquivo .wav (16kHz mono)", type=["wav"])
if st.button("Transcrever (STT offline)") and aud:
    files = {"file": (aud.name, aud.read(), "audio/wav")}
    data = {"lang":"pt"}
    r = requests.post(f"{api}/voice/stt", files=files, data=data)
    st.json(r.json())

st.subheader("Resposta falada (TTS offline)")
txt = st.text_area("Texto para sintetizar", "Olá, Lucas! Bem-vindo ao TerraSynapse IA.")
if st.button("Gerar voz (TTS)"):
    r = requests.post(f"{api}/voice/tts", data={"text": txt})
    j = r.json()
    if j.get("ok"):
        st.audio(f"{api.rstrip('/')}/{j['out']}", format="audio/wav")
        st.success("Áudio gerado.")
    else:
        st.error(j)