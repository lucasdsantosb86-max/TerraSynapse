import streamlit as st, requests, os
st.set_page_config(page_title="GPS – Heatmap & Replay", page_icon="📍", layout="centered")
st.title("📍 GPS – Heatmap & Replay")

api = st.text_input("Backend URL", value=os.getenv("TS_BACKEND_URL","http://localhost:8000"))
up = st.file_uploader("Envie CSV (timestamp, lat, lon, ...)", type=["csv"])
tag = st.text_input("Tag (identificação)", "loteA")

if st.button("Ingerir CSV") and up:
    r = requests.post(f"{api}/ingest/gps", files={"file": (up.name, up.read(),"text/csv")}, data={"tag": tag})
    st.json(r.json())

st.markdown("---")
if st.button("Calcular métricas & gerar heatmap"):
    j = requests.get(f"{api}/ingest/gps/metrics", params={"tag":tag}).json()
    st.json(j)
    if j.get("ok") and j.get("heatmap"):
        st.image(f"{api.rstrip('/')}/{j['heatmap']}", caption="Heatmap GPS")