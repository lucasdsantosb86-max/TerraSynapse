from __future__ import annotations
import streamlit as st, json, hashlib, re, datetime as _dt
from pathlib import Path
from frontend.auth import require

st.set_page_config(page_title="Conta – Trocar Senha", page_icon="🔑", layout="centered")
user = require(roles=("developer","gestor","tecnico","visitante"))

USERS_PATH = Path("data/users/users.json")

def sha256(p: str) -> str:
    return hashlib.sha256(p.encode("utf-8")).hexdigest()

def load_users():
    try:
        return json.loads(USERS_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {"users":[]}

def save_users(d):
    USERS_PATH.write_text(json.dumps(d, indent=2, ensure_ascii=False), encoding="utf-8")

st.title("🔑 Trocar Senha")
st.caption(f"Usuário logado: **{user['username']}**")

oldp = st.text_input("Senha atual", type="password")
newp = st.text_input("Nova senha", type="password")
conf = st.text_input("Confirmar nova senha", type="password")

def strong(p:str)->bool:
    if len(p)<8: return False
    g=sum([bool(re.search(r"[a-z]",p)),bool(re.search(r"[A-Z]",p)),bool(re.search(r"[0-9]",p)),bool(re.search(r"[^a-zA-Z0-9]",p))])
    return g>=3

if st.button("Atualizar senha"):
    if not (oldp and newp and conf):
        st.error("Preencha todos os campos.")
    elif newp != conf:
        st.error("Confirmação não confere.")
    elif not strong(newp):
        st.error('Senha fraca: mínimo 8 caracteres e 3 dos 4 grupos (a-z, A-Z, 0-9, especial).')
        st.error("Confirmação não confere.")
    else:
        d = load_users()
        ok = False
        for u in d["users"]:
            if u["username"] == user["username"]:
                if u["password_hash"] == sha256(oldp):
                    u["password_hash"] = sha256(newp); u["pwd_last_set"] = _dt.datetime.utcnow().isoformat()+"Z"; u["pwd_expires_at"] = (_dt.datetime.utcnow()+_dt.timedelta(days=180)).isoformat()+"Z"; ok = True
                break
        if ok:
            save_users(d)
            st.success("Senha atualizada com sucesso. Faça login novamente.")
        else:
            st.error("Senha atual incorreta.")
