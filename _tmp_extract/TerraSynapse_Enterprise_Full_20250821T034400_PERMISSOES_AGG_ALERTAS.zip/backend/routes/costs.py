from fastapi import APIRouter, Body
from typing import Optional, Dict, Any
from ..services.cost_sync import fetch_worldbank_pink_sheet, fetch_usda_ers_costs, fetch_conab_planilha, fetch_imea, normalize_costs
from pathlib import Path
import json

router = APIRouter(prefix="/costs", tags=["costs"])

@router.post("/sync/usda")
def sync_usda(url: str = Body(..., embed=True)):
    return fetch_usda_ers_costs(url)

@router.post("/sync/conab")
def sync_conab(url: str = Body(..., embed=True)):
    return fetch_conab_planilha(url)

@router.post("/sync/imea")
def sync_imea(url: str = Body(..., embed=True)):
    return fetch_imea(url)

@router.post("/normalize")
def normalize(map_config: Dict[str, Any] = Body({}, embed=True)):
    return normalize_costs(map_config)

@router.get("/files")
def list_cost_files():
    p = Path(__file__).resolve().parents[2]/"data"/"costs"
    files = [str(x) for x in p.glob("*.csv")]
    return {"files": files}