
from __future__ import annotations
import streamlit as st, json, csv
from pathlib import Path
from frontend.auth import require

st.set_page_config(page_title="Auditoria – Logs", page_icon="🧾", layout="wide")
user = require(roles=("developer","gestor"))
LOG = Path("data/audit/audit_log.jsonl")
CSV = Path("data/audit/audit_log.csv")

st.title("🧾 Auditoria de Ações")

if not LOG.exists():
    st.info("Ainda não há registros.")
    st.stop()

# Filtros
act = st.multiselect("Ações", options=["create","update","delete","login","role_change"], default=[])
typ = st.multiselect("Tipo de alvo", options=["user","role","policy"], default=[])
who = st.text_input("Ator (contém)")

rows = []
for line in LOG.read_text(encoding="utf-8").splitlines():
    if not line.strip(): continue
    rec = json.loads(line)
    if act and rec.get("action") not in act: continue
    if typ and rec.get("target_type") not in typ: continue
    if who and who.lower() not in (rec.get("actor","").lower()): continue
    rows.append(rec)

st.write(f"Resultados: **{len(rows)}**")
st.dataframe(rows, use_container_width=True)

col1, col2 = st.columns(2)
with col1:
    if st.button("Exportar CSV"):
        if CSV.exists():
            st.download_button("Baixar audit_log.csv", data=CSV.read_bytes(), file_name="audit_log.csv")
        else:
            # gerar CSV agora
            import csv
            from io import StringIO
            out = StringIO()
            w = csv.writer(out)
            w.writerow(["ts","actor","action","target_type","target_id","details"])
            for r in rows:
                w.writerow([r.get("ts"),r.get("actor"),r.get("action"),r.get("target_type"),r.get("target_id"),json.dumps(r.get("details",{}), ensure_ascii=False)])
            st.download_button("Baixar audit_log.csv", data=out.getvalue().encode("utf-8"), file_name="audit_log.csv")
with col2:
    st.caption("PDF pode ser gerado a partir do CSV exportado no momento (flexível para filtros).")
