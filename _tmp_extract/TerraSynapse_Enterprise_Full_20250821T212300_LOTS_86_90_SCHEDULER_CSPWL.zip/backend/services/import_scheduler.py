import json, time
from pathlib import Path
from typing import List, Dict
import pandas as pd
from .costs_importers import import_imea, import_conab, import_usda, import_eurostat

BASE = Path(__file__).resolve().parents[2]
CONF = BASE/"data"/"costs"/"schedule.json"
OUTD = BASE/"data"/"costs"/"sources"
ALOG = BASE/"data"/"alerts"
OUTD.mkdir(parents=True, exist_ok=True)
ALOG.mkdir(parents=True, exist_ok=True)

def _load():
    if CONF.exists():
        return json.loads(CONF.read_text(encoding="utf-8"))
    return {"jobs":[]}

def _save(obj):
    CONF.parent.mkdir(parents=True, exist_ok=True)
    CONF.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")

def upsert_job(source: str, url: str, threshold_pct: float = 5.0):
    db = _load()
    jobs = [j for j in db["jobs"] if j["source"].lower()!=source.lower()]
    jobs.append({"source": source, "url": url, "threshold_pct": float(threshold_pct)})
    db["jobs"] = jobs
    _save(db); return {"ok": True, "jobs": db["jobs"]}

def list_jobs():
    return _load()

def _import_one(source: str, url: str):
    s = source.lower()
    if s=="imea": return import_imea(url)
    if s=="conab": return import_conab(url)
    if s=="usda": return import_usda(url)
    if s=="eurostat": return import_eurostat(url)
    raise ValueError("source inválida")

def _last_two_files():
    files = sorted(OUTD.glob("*.csv"), key=lambda p: p.stat().st_mtime, reverse=True)
    return files[:2]

def _alert(msg: str):
    (ALOG/"costs_variation.log").open("a", encoding="utf-8").write(f"{int(time.time())};{msg}\n")

def _check_variation(threshold_pct: float):
    files = _last_two_files()
    if len(files) < 2: return []
    import pandas as pd
    df_new = pd.read_csv(files[0])
    df_old = pd.read_csv(files[1])
    keys = ["item","unit","region","currency"]
    if not all(k in df_new.columns for k in keys): return []
    if not all(k in df_old.columns for k in keys): return []
    merged = pd.merge(df_new, df_old, on=keys, suffixes=("_new","_old"))
    if "price_local_new" not in merged.columns or "price_local_old" not in merged.columns:
        return []
    merged["pct"] = (merged["price_local_new"] - merged["price_local_old"]).abs() / merged["price_local_old"].replace(0, pd.NA) * 100
    alerts = merged[merged["pct"] > threshold_pct]
    result = []
    for _, r in alerts.iterrows():
        msg = f"{r['item']}@{r['region']} variação {r['pct']:.2f}% (old={r['price_local_old']}, new={r['price_local_new']})"
        _alert(msg); result.append(msg)
    return result

def run_all():
    db = _load()
    all_alerts = []
    for job in db.get("jobs", []):
        try:
            _import_one(job["source"], job["url"])
            all_alerts += _check_variation(job.get("threshold_pct", 5.0))
        except Exception as e:
            _alert(f"erro {job['source']}: {e}")
    return {"ok": True, "alerts": all_alerts}