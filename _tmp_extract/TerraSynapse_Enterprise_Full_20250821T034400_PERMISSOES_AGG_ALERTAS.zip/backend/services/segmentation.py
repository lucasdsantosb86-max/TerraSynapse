from pathlib import Path
import numpy as np
try:
    import onnxruntime as ort
except Exception:
    ort = None

MODEL_PATH = Path("backend/models/onnx/field_segmentation.onnx")

def segment_field(image_np: np.ndarray):
    """Stub: executa ONNX se disponível. Espera image_np (H,W,3) float32 [0..1].
    Saída: máscara (H,W) com 1=plantável, 0=excluir. Se modelo ausente, retorna None.
    """
    if ort is None or not MODEL_PATH.exists():
        return None
    sess = ort.InferenceSession(str(MODEL_PATH), providers=['CPUExecutionProvider'])
    x = np.transpose(image_np, (2,0,1))[None, ...].astype(np.float32)
    out_name = sess.get_outputs()[0].name
    pred = sess.run([out_name], {"input": x})[0]
    # assume shape (1,1,H,W)
    mask = (pred[0,0] > 0.5).astype(np.uint8)
    return mask