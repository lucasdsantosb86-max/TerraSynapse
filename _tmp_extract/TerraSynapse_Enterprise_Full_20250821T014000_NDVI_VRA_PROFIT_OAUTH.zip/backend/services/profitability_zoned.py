from .profitability import calc_profit

def calc_profit_zoned(culture: str, price_per_t: float, yield_t_ha: float, zones):
    # zones: [{"zone_id":1,"yield_factor":1.05,"area_ha":5.2}, ...]
    return calc_profit(culture, area_ha=sum([z.get("area_ha",0.0) for z in zones]), price_per_t=price_per_t, yield_t_ha=yield_t_ha, zone_factors=zones)