import streamlit as st, pandas as pd, json, glob
from pathlib import Path

st.set_page_config(page_title="Gestor – Desvios vs Benchmark", page_icon="📊")
st.title("📊 Desvios vs Benchmark (R$/ha)")

st.caption("Compare custos estimados (talhões) com benchmarks oficiais (ERS/CONAB/IMEA).")

data_dir = Path(__file__).resolve().parents[1]/"data"/"costs"
# Carrega amostras normalizadas (quando disponíveis)
bench = []
for fp in data_dir.glob("costs_normalized_*.csv"):
    try:
        df = pd.read_csv(fp); bench.append(df)
    except: pass
if bench:
    bench_df = pd.concat(bench, ignore_index=True)
else:
    bench_df = pd.DataFrame(columns=["region","culture","metric","value","currency","date","source"])

st.subheader("Benchmarks (amostra)")
st.dataframe(bench_df.head(100))

st.subheader("Talhões (estimados)")
# Simples: ler um CSV talhoes_estimados.csv se existir
tal_fp = Path(__file__).resolve().parents[1]/"data"/"reports"/"talhoes_estimados.csv"
if tal_fp.exists():
    tal = pd.read_csv(tal_fp)
else:
    tal = pd.DataFrame([{"talhao":"A","cultura":"soja","custo_R$_ha":5200.0},{"talhao":"B","cultura":"milho","custo_R$_ha":4800.0}])
st.dataframe(tal)

st.subheader("Semáforo de Desvio")
limiares = {"soja":6000,"milho":5000,"trigo":4500,"citros":20000,"cana":12000}
tal["limiar"] = tal["cultura"].map(limiares).fillna(0.0)
tal["status"] = tal.apply(lambda r: "🟢 OK" if r["custo_R$_ha"]<=r["limiar"] else "🔴 Acima", axis=1)
st.dataframe(tal[["talhao","cultura","custo_R$_ha","limiar","status"]])

st.caption("→ Para aprofundar, sincronize ‘Custos – Sync (Auto/Manual)’ e alimente os talhões via upload CSV em data/reports/talhoes_estimados.csv.")