
import os
def asr_transcribe(wav_bytes: bytes, lang: str="pt") -> str|None:
    try:
        from vosk import Model, KaldiRecognizer
        import json, wave, tempfile
    except Exception:
        return None
    with tempfile.NamedTemporaryFile(suffix=".wav", delete=True) as tmp:
        tmp.write(wav_bytes); tmp.flush()
        wf = wave.open(tmp.name, "rb")
        model_path = os.environ.get("VOSK_MODEL_PT", "/opt/vosk-model-small-pt-0.3")
        if not os.path.exists(model_path): return None
        rec = KaldiRecognizer(Model(model_path), wf.getframerate())
        rec.SetWords(True); text = ""
        while True:
            data = wf.readframes(4000)
            if len(data) == 0: break
            if rec.AcceptWaveform(data):
                text += json.loads(rec.Result()).get("text","") + " "
        text += json.loads(rec.FinalResult()).get("text","")
        return text.strip()
def tts_speak(text: str, voice: str|None=None):
    try: import pyttsx3
    except Exception: return False
    eng = pyttsx3.init()
    if voice:
        for v in eng.getProperty("voices"):
            if voice.lower() in v.name.lower():
                eng.setProperty("voice", v.id); break
    eng.say(text); eng.runAndWait(); return True
