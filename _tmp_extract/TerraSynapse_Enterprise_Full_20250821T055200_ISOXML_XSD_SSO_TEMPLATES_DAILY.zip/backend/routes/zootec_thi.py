from fastapi import APIRouter, Query
from ..services.zootec_thi import thi

router = APIRouter(prefix="/zootec", tags=["zootec"])

@router.get("/thi")
def get_thi(temp_c: float = Query(...), rh: float = Query(...)):
    return thi(temp_c, rh)