
from __future__ import annotations
import numpy as np
try:
    import cv2
except Exception:
    cv2 = None

def morph_open_close(mask: np.ndarray, k: int=3, it: int=1) -> np.ndarray:
    if cv2 is None:
        return mask
    import numpy as np
    kernel = np.ones((k,k), np.uint8)
    m = cv2.morphologyEx(mask.astype("uint8")*255, cv2.MORPH_OPEN, kernel, iterations=it)
    m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, kernel, iterations=it)
    return (m>0).astype("uint8")

def segment_plantable(ndvi: np.ndarray, th: float=0.15) -> np.ndarray:
    mask = (ndvi >= th).astype("uint8")
    mask = morph_open_close(mask, k=5, it=1)
    return mask

def stats_from_mask(mask: np.ndarray, pixel_area_m2: float|None=None) -> dict:
    px = int(mask.sum())
    stats = {"pixels": px}
    if pixel_area_m2:
        stats["area_m2"] = float(px*pixel_area_m2)
        stats["area_ha"] = float(stats["area_m2"]/10000.0)
    return stats
