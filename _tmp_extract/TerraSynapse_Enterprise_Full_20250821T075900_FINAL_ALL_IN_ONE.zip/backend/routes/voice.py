from fastapi import APIRouter, Body
from ..services.voice import tts

router = APIRouter(prefix="/voice", tags=["voice"])

@router.post("/tts")
def tts_(text: str = Body(...)):
    return tts(text)