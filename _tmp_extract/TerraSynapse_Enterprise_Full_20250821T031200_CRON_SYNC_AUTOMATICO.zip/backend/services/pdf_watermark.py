from PyPDF2 import PdfReader, PdfWriter
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from io import BytesIO
import datetime as dt

def add_watermark(src_pdf: str, dst_pdf: str, text: str):
    # cria página de watermark transparente
    buf = BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    c.setFont("Helvetica", 10)
    c.setFillGray(0.6, alpha=0.15)
    c.saveState()
    c.translate(0, 0)
    c.rotate(35)
    for y in range(-5, 30, 4):
        for x in range(-2, 18, 4):
            c.drawString(x*cm, y*cm, text)
    c.restoreState()
    c.save()
    buf.seek(0)

    # aplica
    wm = PdfReader(buf)
    reader = PdfReader(src_pdf)
    writer = PdfWriter()
    for i, page in enumerate(reader.pages):
        page.merge_page(wm.pages[0])
        writer.add_page(page)
    with open(dst_pdf, "wb") as f:
        writer.write(f)
    return {"ok": True, "out": dst_pdf}