from fastapi import APIRouter, Body, Query
from ..services.user_integrations import set_autoconnect, get_settings, on_secret_saved

router = APIRouter(prefix="/users/integrations", tags=["users-integrations"])

@router.post("/auto-connect")
def auto_connect(user_id: str = Body(...), enabled: bool = Body(...)):
    return set_autoconnect(user_id, enabled)

@router.get("/settings")
def settings(user_id: str = Query(...)):
    return get_settings(user_id)

@router.post("/on-secret-saved")
def on_secret(user_id: str = Body(...), provider: str = Body(...)):
    return on_secret_saved(user_id, provider)