from fastapi import APIRouter, UploadFile, File
from PIL import Image
import numpy as np, time
from pathlib import Path
from ..services.segmentation import segment_field

router = APIRouter(prefix="/vision/aerial", tags=["vision"])

@router.post("/segment")
async def segment(file: UploadFile = File(...)):
    tmp = Path("data/geo")/f"img_{int(time.time())}.png"
    tmp.parent.mkdir(parents=True, exist_ok=True)
    with open(tmp, "wb") as f:
        f.write(await file.read())
    img = Image.open(tmp).convert("RGB")
    arr = np.array(img).astype(np.float32)/255.0
    mask = segment_field(arr)
    if mask is None:
        return {"ok": False, "detail":"modelo ausente (coloque backend/models/onnx/field_segmentation.onnx)", "area_pixels": None}
    area = int(mask.sum())
    return {"ok": True, "area_pixels": area}