from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.lib import colors
from pathlib import Path
import json, datetime as dt

PALETA = {"verde":"#2E7D32","azul":"#1565C0","cinza":"#607D8B","oliva":"#6B8E23"}

def hexc(c): 
    c = c.lstrip("#")
    return tuple(int(c[i:i+2],16)/255 for i in (0,2,4))

def gerar_relatorio_talhao(out_path:str, empresa_logo:str=None, user_name:str="Usuário",
                           talhao:str="Talhão 1", area_ha:float=0.0, ndvi_medio:float=0.0,
                           zonas:list=None, custos:dict=None):
    zonas = zonas or []
    custos = custos or {}
    c = canvas.Canvas(out_path, pagesize=A4)
    W,H = A4
    # header
    c.setFillColorRGB(*hexc(PALETA["verde"])); c.rect(0,H-50,W,50,fill=1,stroke=0)
    c.setFillColorRGB(1,1,1); c.setFont("Helvetica-Bold",14)
    c.drawString(30,H-35,"TerraSynapse IA – Relatório de Talhão")
    c.setFont("Helvetica",10); c.drawRightString(W-20,H-28,dt.datetime.now().strftime("%Y-%m-%d %H:%M"))
    # logo
    if empresa_logo and Path(empresa_logo).exists():
        try: c.drawImage(empresa_logo, W-160, H-60, width=120, height=40, preserveAspectRatio=True, mask='auto')
        except: pass
    # info
    c.setFillColorRGB(0,0,0); c.setFont("Helvetica-Bold",12)
    y = H-90; c.drawString(30,y,f"Talhão: {talhao}"); y-=16
    c.setFont("Helvetica",11); c.drawString(30,y,f"Responsável: {user_name}"); y-=16
    c.drawString(30,y,f"Área útil (ha): {area_ha:.2f}"); y-=16
    c.drawString(30,y,f"NDVI médio: {ndvi_medio:.3f}"); y-=20
    # zonas
    c.setFont("Helvetica-Bold",12); c.drawString(30,y,"Zonas de manejo:"); y-=14
    c.setFont("Helvetica",10)
    c.drawString(30,y,"Zona"); c.drawString(140,y,"Área (ha)"); c.drawString(220,y,"Vigor"); c.drawString(300,y,"Sementes"); c.drawString(400,y,"Adubo"); c.drawString(480,y,"Defensivos")
    y-=10; c.line(28,y,560,y); y-=12
    for z in zonas:
        c.drawString(30,y,str(z.get("id","Z")))
        c.drawRightString(200,y,f"{z.get('area_ha',0):.2f}")
        c.drawString(220,y,str(z.get("vigor","-")))
        c.drawString(300,y,str(z.get("sementes","-")))
        c.drawString(400,y,str(z.get("adubo","-")))
        c.drawString(480,y,str(z.get("defensivos","-")))
        y-=14
        if y<90: c.showPage(); y=H-60
    # custos resumo
    y-=6; c.setFont("Helvetica-Bold",12); c.drawString(30,y,"Custos estimados"); y-=14
    c.setFont("Helvetica",10)
    for k,v in custos.items():
        c.drawString(30,y,f"{k}: {v}")
        y-=12
        if y<80: c.showPage(); y=H-60
    # rodapé
    c.setFillColorRGB(*hexc(PALETA["azul"])); c.rect(0,0,W,30,fill=1,stroke=0)
    c.setFillColorRGB(1,1,1); c.setFont("Helvetica",9); c.drawString(20,10,"Assinado digitalmente (se habilitado). Confidencial – TerraSynapse IA.")
    c.save()
    return {"ok": True, "out": out_path}