import streamlit as st, requests, os

st.set_page_config(page_title="Admin – Eventos & Webhooks", page_icon="🔔", layout="centered")
st.title("🔔 Eventos & Webhooks")

api = st.text_input("Backend URL", value=os.getenv("TS_BACKEND_URL","http://localhost:8000"))

st.subheader("Status do Agendador")
col = st.columns(3)
if col[0].button("Iniciar agendador (15 min)"):
    st.json(requests.post(f"{api}/scheduler/start").json())
if col[1].button("Parar agendador"):
    st.json(requests.post(f"{api}/scheduler/stop").json())
if col[2].button("Ver status"):
    st.json(requests.get(f"{api}/scheduler/status").json())

st.markdown("---")
st.subheader("Gerenciar Webhooks")
evt = st.selectbox("Tipo de evento", ["alert_frost","alert_wind","alert_rain","alert_disconnect"])
url = st.text_input("URL do webhook")

cc = st.columns(2)
if cc[0].button("Adicionar webhook"):
    st.json(requests.post(f"{api}/events/webhooks/add", json={"event_type":evt,"url":url}).json())
if cc[1].button("Remover webhook"):
    st.json(requests.post(f"{api}/events/webhooks/remove", json={"event_type":evt,"url":url}).json())

st.markdown("---")
if st.button("Listar webhooks"):
    st.json(requests.get(f"{api}/events/webhooks").json())