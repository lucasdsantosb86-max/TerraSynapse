
import streamlit as st, requests, datetime as dt, os
from pathlib import Path
from frontend.auth import require

st.set_page_config(page_title="Admin – Upload de Conhecimento", page_icon="📤", layout="wide")
user = require(roles=("developer","gestor"))

st.title("📤 Upload de Snippets Premium / Arquivos de Conhecimento")

KNOW_DIR = Path("data/knowledge"); KNOW_DIR.mkdir(parents=True, exist_ok=True)
DOCS_DIR = Path("data/docs"); DOCS_DIR.mkdir(parents=True, exist_ok=True)

tab1, tab2 = st.tabs(["Snippets JSONL", "Outros arquivos (PDF/TXT/CSV)"])

with tab1:
    st.subheader("Adicionar novos snippets (JSONL)")
    up = st.file_uploader("Selecione um arquivo .jsonl", type=["jsonl"])
    if up is not None:
        ts = dt.datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
        dest = KNOW_DIR/f"snippets_premium_custom_{ts}.jsonl"
        dest.write_bytes(up.read())
        st.success(f"Arquivo salvo em {dest}")
        if st.button("Ingerir todos agora"):
            r = requests.post("http://localhost:8000/knowledge/ingest_all")
            st.write(r.json() if r.ok else r.text)

with tab2:
    st.subheader("Enviar documentação de referência (PDF/TXT/CSV)")
    up2 = st.file_uploader("Selecione arquivos", type=["pdf","txt","csv"], accept_multiple_files=True)
    if up2:
        saved = []
        for f in up2:
            dest = DOCS_DIR/f.name
            dest.write_bytes(f.read())
            saved.append(dest.as_posix())
        st.success("Arquivos salvos:")
        st.write(saved)
        st.info("Obs.: Estes arquivos ficam armazenados e podem ser incorporados na curadoria futura.")
