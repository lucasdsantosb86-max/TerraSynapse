from pathlib import Path
import json, requests

BASE = Path(__file__).resolve().parents[2]
CONF = BASE/"config"/"alerts_channels.json"
LOG  = BASE/"data"/"alerts"/"multi_webhook.log"
LOG.parent.mkdir(parents=True, exist_ok=True)

def _cfg():
    try:
        return json.loads(CONF.read_text(encoding="utf-8"))
    except Exception:
        return {"channels":[]}

def set_channels(channels):
    CONF.write_text(json.dumps({"channels": channels or []}, indent=2, ensure_ascii=False), encoding="utf-8")
    return {"ok": True, "channels": channels}

def send_all(payload: dict):
    cfg = _cfg()
    results = []
    for ch in cfg.get("channels", []):
        t = (ch.get("type") or "slack").lower()
        url = (ch.get("url") or "").strip()
        item = {"name": ch.get("name"), "type": t, "ok": False}
        try:
            if not url:
                item["error"] = "empty_url"
            else:
                # formato genérico JSON; Slack/Teams aceitam simples; WhatsApp via bridge custom
                msg = format_message(payload, t)
                r = requests.post(url, json=msg, timeout=5)
                item["ok"] = r.status_code in (200,201,202)
                item["status"] = r.status_code
        except Exception as e:
            item["error"] = str(e)
        results.append(item)
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(json.dumps({"payload": payload, "results": results}) + "\n")
    return {"ok": True, "results": results}

TEMPL = BASE/"config"/"alerts_message_templates.json"

def _templates():
    try:
        return json.loads(TEMPL.read_text(encoding="utf-8"))
    except Exception:
        return {}

def format_message(payload: dict, ch_type: str) -> dict:
    tpls = _templates()
    kind = payload.get("type","generic")
    tpl = ((tpls.get(kind) or {}).get(ch_type)) or json.dumps(payload, ensure_ascii=False)
    try:
        text = tpl.format(**payload)
    except Exception:
        text = json.dumps(payload, ensure_ascii=False)
    # Slack/Teams simples aceitam {"text": "..."}; bridges WhatsApp variam
    return {"text": text, "payload": payload}
