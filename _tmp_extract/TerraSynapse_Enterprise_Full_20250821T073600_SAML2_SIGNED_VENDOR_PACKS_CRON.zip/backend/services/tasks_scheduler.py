from pathlib import Path
import json, time, datetime as dt
from .crm_tasks import list_tasks

BASE = Path(__file__).resolve().parents[2]
LOG  = BASE/"data"/"alerts_log.jsonl"

def check_due():
    now = int(time.time())
    soon = now + 24*3600  # próximas 24h
    events = []
    for t in list_tasks():
        due = t.get("due_ts")
        if not due: continue
        if now <= due <= soon and t.get("status","") not in ("concluída","feito","done"):
            ev = {"ts": dt.datetime.utcnow().isoformat()+"Z", "type":"task_due", "detail": f"Task '{t.get('title')}' vence em 24h", "task_id": t.get("id"), "client_id": t.get("client_id")}
            events.append(ev)
            LOG.write_text(json.dumps(ev)+"
", encoding="utf-8", append=True) if hasattr(LOG,'append') else open(LOG,"a",encoding="utf-8").write(json.dumps(ev)+"
")
    return {"ok": True, "alerts": events}