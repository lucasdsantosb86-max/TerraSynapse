from fastapi import APIRouter, Body
from ..services.oauth_jdlink import start_oauth, receive_token

router = APIRouter(prefix="/oauth/jdlink", tags=["oauth-jdlink"])

@router.post("/start")
def start(user_id: str = Body(...), client_id: str = Body(...), redirect_uri: str = Body(...)):
    return start_oauth(user_id, client_id, redirect_uri)

@router.post("/callback")
def callback(user_id: str = Body(...), access_token: str = Body(...), refresh_token: str = Body(None)):
    return receive_token(user_id, access_token, refresh_token)