from pathlib import Path
import json, time, uuid

BASE = Path(__file__).resolve().parents[2]
CRM  = BASE/"data"/"crm"
CRM.mkdir(parents=True, exist_ok=True)

def _fp(name: str) -> Path:
    return CRM/f"{name}.json"

def _load(name: str):
    p = _fp(name)
    if not p.exists(): return []
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return []

def _save(name: str, arr):
    _fp(name).write_text(json.dumps(arr, ensure_ascii=False, indent=2), encoding="utf-8")

def _now():
    return int(time.time())

def list_all(name: str):
    return _load(name)

def get_by_id(name: str, _id: str):
    for r in _load(name):
        if r.get("id")==_id: return r
    return None

def create(name: str, obj: dict):
    arr = _load(name)
    obj = dict(obj)
    obj.setdefault("id", str(uuid.uuid4()))
    obj.setdefault("created_at", _now())
    arr.append(obj)
    _save(name, arr)
    return obj

def update(name: str, _id: str, patch: dict):
    arr = _load(name)
    out = None
    for i,r in enumerate(arr):
        if r.get("id")==_id:
            r.update(patch)
            r["updated_at"] = _now()
            arr[i] = r
            out = r
            break
    _save(name, arr)
    return out

def delete(name: str, _id: str):
    arr = _load(name)
    arr2 = [r for r in arr if r.get("id")!=_id]
    _save(name, arr2)
    return {"deleted": len(arr)-len(arr2)}