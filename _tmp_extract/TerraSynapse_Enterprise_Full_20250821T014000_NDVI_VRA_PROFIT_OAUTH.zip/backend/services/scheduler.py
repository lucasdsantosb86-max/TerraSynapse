import threading, time, json
from pathlib import Path
from .weather_common import get_forecast
from .alerts import run_checks
from .tasks_scheduler import check_due

BASE = Path(__file__).resolve().parents[2]
CONF = BASE/"config"/"alerts.json"
WEBH = BASE/"config"/"webhooks.json"
STATE = BASE/"data"/"scheduler_state.json"

_interval_sec = 900  # 15 min
_running = False
_thread = None

def _center_of_bbox(bbox):
    min_lon, min_lat, max_lon, max_lat = bbox
    return ( (min_lat+max_lat)/2.0, (min_lon+max_lon)/2.0 )

def _notify_webhooks(events):
    try:
        cfg = json.loads(WEBH.read_text(encoding="utf-8"))
    except Exception:
        cfg = {}
    urls = cfg.get("urls", {})
    if not urls: return
    import requests
    for ev in events:
        typ = ev.get("type")
        for wh in urls.get(typ, []):
            try:
                requests.post(wh, json=ev, timeout=10)
            except Exception:
                pass

def _tick():
    global _running
    while _running:
        try:
            cfg = json.loads(CONF.read_text(encoding="utf-8"))
            perims = cfg.get("perimeters", [])
            events_all = []
            for p in perims:
                lat, lon = _center_of_bbox(p.get("bbox"))
                fc = get_forecast(lat, lon)
                r = run_checks(fc)
                events_all.extend(r.get("alerts", []))
            # tarefas com vencimento
            td = check_due(); events_all.extend(td.get('alerts', []))
            if events_all:
                _notify_webhooks(events_all)
            STATE.write_text(json.dumps({"last_run": int(time.time()), "alerts_count": len(events_all)}), encoding="utf-8")
        except Exception as e:
            STATE.write_text(json.dumps({"error": str(e)}), encoding="utf-8")
        time.sleep(_interval_sec)

def start():
    global _running, _thread
    if _running: return {"ok": True, "status":"running"}
    _running = True
    _thread = threading.Thread(target=_tick, daemon=True)
    _thread.start()
    return {"ok": True, "status":"started", "interval_sec": _interval_sec}

def stop():
    global _running
    _running = False
    return {"ok": True, "status":"stopped"}

def status():
    try:
        return json.loads(STATE.read_text(encoding="utf-8"))
    except Exception:
        return {"last_run": None}