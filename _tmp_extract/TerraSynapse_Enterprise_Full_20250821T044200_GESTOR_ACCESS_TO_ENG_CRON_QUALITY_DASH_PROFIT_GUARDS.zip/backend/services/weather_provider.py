import json, os, time, requests
from pathlib import Path

BASE = Path(__file__).resolve().parents[1]/"data"/"security"
POL_PATH = BASE/"policies.json"
KEY_PATH = BASE/"api_keys.json"

class WeatherClient:
    def __init__(self):
        self._pol = json.loads(POL_PATH.read_text(encoding="utf-8"))
        self._keys = json.loads(KEY_PATH.read_text(encoding="utf-8"))
        self.provider = self._pol.get("weather_provider","climatempo")
        self.units = self._pol.get("weather_units","metric")
        self.locale_id = int(self._pol.get("weather_locale_id", 3477))

    # --- ClimaTempo ---
    def _climatempo_current(self):
        token = self._keys.get("climatempo_token")
        if not token or token.startswith("COLOQUE_"):
            return {"provider":"climatempo","error":"Token ausente"}
        # Endpoint documentado (API Advisor): /api/v1/weather/locale/{id}/current?token={token}
        url = f"http://apiadvisor.climatempo.com.br/api/v1/weather/locale/{self.locale_id}/current?token={token}"
        r = requests.get(url, timeout=10)
        if r.status_code != 200:
            return {"provider":"climatempo","status":r.status_code,"detail":r.text[:200]}
        data = r.json()
        # Normaliza saída
        out = {
            "provider":"climatempo",
            "city": data.get("name"),
            "state": data.get("state"),
            "country": "BR",
            "updated_at": data.get("data",{}).get("date"),
            "temp": data.get("data",{}).get("temperature"),
            "condition": data.get("data",{}).get("condition"),
            "humidity": data.get("data",{}).get("humidity"),
            "wind_kmh": data.get("data",{}).get("wind_velocity")
        }
        return out

    # Registrar cidade ao token (ClimaTempo exige)
    def climatempo_register_locale(self, locale_id:int=None):
        token = self._keys.get("climatempo_token")
        if not token or token.startswith("COLOQUE_"):
            return {"ok":False,"detail":"Token ausente"}
        lid = int(locale_id or self.locale_id)
        # Endpoint público de registro de locale
        url = f"http://apiadvisor.climatempo.com.br/api-manager/user-token/locale/register?token={token}"
        payload = {"localeId":[lid]}
        r = requests.put(url, json=payload, timeout=10)
        return {"status":r.status_code,"body":r.text[:200]}

    # --- OpenWeather fallback ---
    def _openweather_current(self):
        key = self._keys.get("openweather_key")
        if not key or key.startswith("OPCIONAL"):
            return {"provider":"openweather","error":"Chave ausente"}
        # Busca por cidade via locale_id não é direta. Espera que a UI passe lat/lon opcionalmente.
        # Como fallback, consultamos OneCall/Current se coords vierem; aqui mantemos placeholder.
        return {"provider":"openweather","detail":"Implementar consulta por lat/lon na UI"}

    def current(self):
        if self.provider == "climatempo":
            return self._climatempo_current()
        return self._openweather_current()