from fastapi import APIRouter, Body, Query
from ..services.jdlink_client import test, ingest_activity, list_recent

router = APIRouter(prefix="/jdlink", tags=["jdlink"])

@router.get("/test")
def t(user_id: str):
    return test(user_id)

@router.post("/ingest/activity")
def ingest(user_id: str = Body(...), payload: dict = Body(...)):
    return ingest_activity(user_id, payload)

@router.get("/recent")
def recent(limit: int = Query(20)):
    return list_recent(limit)