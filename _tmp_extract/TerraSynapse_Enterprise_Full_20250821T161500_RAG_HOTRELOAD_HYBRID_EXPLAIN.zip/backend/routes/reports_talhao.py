from fastapi import APIRouter, Body
from ..services.report_talhao import gerar_pdf
from pathlib import Path
import tempfile

router = APIRouter(prefix="/reports/talhao", tags=["reports"])

@router.post("/pdf")
def pdf(plan: dict = Body(...)):
    # plan: {cultura, area_ha, ndvi_mean, insumos:[{item,qtd,un,preco_R$,total_R$}], total_R$, custo_R$_ha, benchmark_R$_ha, economia_R$_ha}
    out = Path(__file__).resolve().parents[2]/"data"/"reports"/"talhao.pdf"
    out.parent.mkdir(parents=True, exist_ok=True)
    return gerar_pdf(plan, str(out))