from fastapi import APIRouter, Body, Request
from ..services.sso_saml2 import set_settings, metadata_xml, login_url, acs_http_post

router = APIRouter(prefix="/sso/saml2", tags=["sso-saml2"])

@router.post("/settings/set")
def set_(payload: dict = Body(...)):
    return set_settings(payload)

@router.get("/metadata")
def meta():
    return {"ok": True, "metadata": metadata_xml()}

@router.get("/start")
def start():
    return {"ok": True, "redirect_to": login_url()}

@router.post("/acs")
async def acs(request: Request):
    form = await request.form()
    # monta request_data mínimo
    req = {
        "https": "on" if request.url.scheme == "https" else "off",
        "http_host": request.client.host,
        "server_port": request.url.port or (443 if request.url.scheme=="https" else 80),
        "script_name": request.url.path,
        "get_data": request.query_params,
        "post_data": form
    }
    return acs_http_post(req)