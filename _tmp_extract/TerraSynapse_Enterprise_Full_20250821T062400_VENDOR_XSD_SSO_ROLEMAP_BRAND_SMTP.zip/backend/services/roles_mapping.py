from pathlib import Path
import json

BASE = Path(__file__).resolve().parents[2]
CONF = BASE/"config"/"auth_role_mapping.json"
ROLES = BASE/"config"/"users_roles.json"

def _cfg():
    try:
        return json.loads(CONF.read_text(encoding="utf-8"))
    except Exception:
        return {"default":{},"providers":{}}

def set_mapping(payload: dict):
    CONF.write_text(json.dumps(payload or {}, indent=2, ensure_ascii=False), encoding="utf-8")
    return {"ok": True}

def _save_role(user_id: str, role: str):
    try:
        m = json.loads(ROLES.read_text(encoding="utf-8"))
    except Exception:
        m = {}
    m[user_id] = role
    ROLES.write_text(json.dumps(m, indent=2, ensure_ascii=False), encoding="utf-8")

def map_role(provider: str, userinfo: dict, fallback_email: str = "") -> str:
    cfg = _cfg()
    # provider-specific
    p = (cfg.get("providers") or {}).get(provider) or {}
    claim = p.get("claim")
    if claim and claim in (userinfo or {}):
        val = userinfo[claim]
        if isinstance(val, list):
            for needle in (p.get("contains") or []):
                if needle in val:
                    _save_role(fallback_email or userinfo.get("email",""), p.get("role","visitante"))
                    return p.get("role","visitante")
        elif isinstance(val, str):
            if p.get("match") and p["match"] in val:
                _save_role(fallback_email or userinfo.get("email",""), p.get("role","visitante"))
                return p.get("role","visitante")
    # default rule
    d = cfg.get("default") or {}
    d_claim = d.get("claim"); d_match = d.get("match"); d_role = d.get("role","visitante")
    v = (userinfo or {}).get(d_claim) or fallback_email
    if d_claim and v and d_match and d_match in v:
        _save_role(fallback_email or userinfo.get("email",""), d_role)
        return d_role
    return "visitante"