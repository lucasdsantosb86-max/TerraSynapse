from pathlib import Path
import json, re
import numpy as np
from typing import List, Dict, Any

# Dependências leves para cache/TF‑IDF
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import joblib

BASE = Path(__file__).resolve().parents[2]
KNOW = BASE/"data"/"knowledge"
CACHE = BASE/"data"/"cache"
CACHE.mkdir(parents=True, exist_ok=True)

def _load_snippets() -> List[Dict[str,Any]]:
    idx = KNOW/"index_snippets.jsonl"
    if not idx.exists():
        return []
    rows = []
    for line in idx.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            rows.append(json.loads(line))
        except:
            pass
    return rows

def _filter_by_category(snips, category: str):
    if not category or category.lower() in ["todas","all","*"]:
        return snips
    cat = category.lower()
    out = []
    for r in snips:
        c = (r.get("category") or r.get("culture") or "misc").lower()
        if cat in c or c in cat:
            out.append(r)
    return out or snips  # fallback

def build_cache(category: str = "all") -> Dict[str, Any]:
    snips = _load_snippets()
    snips = _filter_by_category(snips, category)
    texts = [f"{r.get('title','')} — {r.get('content','')}" for r in snips]
    if not texts:
        return {"ok": False, "detail": "Sem snippets para cache."}
    vec = TfidfVectorizer(max_features=40000, ngram_range=(1,2))
    X = vec.fit_transform(texts)
    meta = [{"id": r.get("id",""), "title": r.get("title",""), "category": r.get("category",""), "culture": r.get("culture",""), "premium": r.get("premium",False)} for r in snips]
    joblib.dump(vec, CACHE/f"tfidf_{category}.joblib")
    joblib.dump(X, CACHE/f"tfidf_{category}.npz")
    (CACHE/f"tfidf_{category}.meta.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    return {"ok": True, "count": len(meta)}

def search(query: str, category: str = "all", top_k: int = 8) -> Dict[str, Any]:
    vec_p = CACHE/f"tfidf_{category}.joblib"
    mat_p = CACHE/f"tfidf_{category}.npz"
    meta_p= CACHE/f"tfidf_{category}.meta.json"
    if not (vec_p.exists() and mat_p.exists() and meta_p.exists()):
        build_cache(category)
    vec = joblib.load(vec_p)
    X = joblib.load(mat_p)
    meta = json.loads(meta_p.read_text(encoding="utf-8"))
    qv = vec.transform([query])
    sims = cosine_similarity(qv, X).ravel()
    idx = np.argsort(-sims)[:top_k]
    results = []
    snips = _load_snippets()
    # Índice em 'meta' segue a ordem do cache, que segue 'snips' filtrados; por segurança, casamos por title/id.
    for i in idx:
        m = meta[i]
        # recuperar conteúdo original pelo id (quando houver)
        content = None
        if m.get("id"):
            for s in snips:
                if s.get("id")==m["id"]:
                    content = s.get("content"); break
        results.append({"score": float(sims[i]), **m, "content": content})
    return {"ok": True, "results": results}