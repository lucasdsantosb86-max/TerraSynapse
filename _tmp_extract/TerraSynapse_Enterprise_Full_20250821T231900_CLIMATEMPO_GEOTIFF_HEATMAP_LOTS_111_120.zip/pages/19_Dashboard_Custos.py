import streamlit as st
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

st.set_page_config(page_title="Dashboard de Custos", page_icon="💲", layout="wide")
st.title("💲 Dashboard de Custos – Global & Local")

base = Path(__file__).resolve().parents[1]
g_csv = base/"data"/"costs"/"global"/"costs_global_sample.normalized.csv"
l_csv = base/"data"/"costs"/"local"/"costs_local_sample.normalized.csv"

st.caption("Use as APIs de normalização para atualizar os CSVs antes de abrir este dashboard.")
colA, colB = st.columns(2)

def load_csv(p: Path):
    if not p.exists():
        st.warning(f"Arquivo não encontrado: {p}")
        return pd.DataFrame()
    return pd.read_csv(p)

with colA:
    st.subheader("Global (normalizado → BRL)")
    dfg = load_csv(g_csv)
    if not dfg.empty:
        st.dataframe(dfg.head(50))
with colB:
    st.subheader("Local (microrregião, normalizado)")
    dfl = load_csv(l_csv)
    if not dfl.empty:
        st.dataframe(dfl.head(50))

st.markdown("---")
st.subheader("Filtros")
culture = st.text_input("Cultura (ex.: soja, milho, trigo, citros)", value="soja")
item = st.text_input("Insumo (ex.: ureia, NPK_08-28-16, defensivo_IRAC28)", value="ureia")
region = st.text_input("Região/UF/Microrregião (opcional)", value="")

def semaforo(val, ref_low, ref_high):
    # verde se dentro do corredor; amarelo se 10% fora; vermelho se 20% fora
    import math
    if math.isnan(val): return "cinza"
    center = (ref_low+ref_high)/2
    tol = 0.1*center
    if ref_low <= val <= ref_high: return "verde"
    if val < ref_low - tol or val > ref_high + tol: return "vermelho"
    return "amarelo"

if st.button("Gerar visões"):
    dfg = load_csv(g_csv)
    dfl = load_csv(l_csv)

    tabs = st.tabs(["Visão Global", "Visão Local"])

    with tabs[0]:
        if dfg.empty:
            st.info("Sem dados globais normalizados ainda.")
        else:
            sel = dfg[(dfg["culture"].str.contains(culture, case=False, na=False)) & (dfg["item"].str.contains(item, case=False, na=False))]
            st.write(f"{len(sel)} registros filtrados.")
            if not sel.empty:
                fig, ax = plt.subplots()
                ax.plot(pd.to_datetime(sel["date"]), sel["price_BRL"])
                ax.set_xlabel("Data"); ax.set_ylabel("Preço (BRL)")
                st.pyplot(fig, clear_figure=True)
                # faixa de referência simples (P10–P90)
                q10, q90 = sel["price_BRL"].quantile(0.10), sel["price_BRL"].quantile(0.90)
                last = sel.sort_values("date").iloc[-1]["price_BRL"]
                st.metric("Último preço (BRL)", f"{last:,.2f}".replace(",", "X").replace(".", ",").replace("X","."), help=f"Faixa de referência ~ P10={q10:.0f} / P90={q90:.0f}")
                st.write("Semáforo:", semaforo(last, q10, q90).upper())

    with tabs[1]:
        if dfl.empty:
            st.info("Sem dados locais normalizados ainda.")
        else:
            sel = dfl[(dfl["culture"].str.contains(culture, case=False, na=False)) & (dfl["input"].str.contains(item, case=False, na=False))]
            if region.strip():
                mask = sel.apply(lambda r: region.lower() in (str(r.get("region",""))+str(r.get("state",""))+str(r.get("microregion",""))).lower(), axis=1)
                sel = sel[mask]
            st.write(f"{len(sel)} registros filtrados.")
            if not sel.empty:
                fig, ax = plt.subplots()
                sel["date_dt"] = pd.to_datetime(sel["date"])
                sel = sel.sort_values("date_dt")
                ax.plot(sel["date_dt"], sel["price_BRL"])
                ax.set_xlabel("Data"); ax.set_ylabel("Preço (BRL)")
                st.pyplot(fig, clear_figure=True)
                last = sel.iloc[-1]["price_BRL"]
                q10, q90 = sel["price_BRL"].quantile(0.10), sel["price_BRL"].quantile(0.90)
                st.metric("Último preço (BRL)", f"{last:,.2f}".replace(",", "X").replace(".", ",").replace("X","."), help=f"Faixa local ~ P10={q10:.0f} / P90={q90:.0f}")
                st.write("Semáforo:", semaforo(last, q10, q90).upper())

st.caption("Endpoints úteis: POST /costs/global/normalize | POST /costs/local/normalize | GET /weather/forecast | POST /ingest/aqua/sample")