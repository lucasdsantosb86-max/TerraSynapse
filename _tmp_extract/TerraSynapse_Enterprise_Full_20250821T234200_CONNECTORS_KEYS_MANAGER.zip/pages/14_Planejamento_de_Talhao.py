import streamlit as st, numpy as np, rasterio, os, requests, io
from pathlib import Path
from sklearn.cluster import KMeans

st.set_page_config(page_title="Planejamento de Talhão", page_icon="🛰️", layout="wide")
st.title("🛰️ Planejamento de Talhão – NDVI GeoTIFF + KMeans + Máscara")

col1, col2 = st.columns(2)
with col1:
    tif = st.file_uploader("Upload GeoTIFF (Sentinel/Landsat)", type=["tif","tiff"])
    red_band = st.number_input("Banda Red (ex. 4)", 1, 20, 4)
    nir_band = st.number_input("Banda NIR (ex. 8)", 1, 20, 8)
with col2:
    talhao = st.text_input("Nome do talhão", "Talhão 1")
    area_ha = st.number_input("Área estimada (ha)", 0.0, 100000.0, 10.0)
    n_zonas = st.slider("Nº de zonas (KMeans)", 3, 5, 3)

if tif:
    with rasterio.open(tif) as src:
        R = src.read(int(red_band)).astype(np.float32)
        N = src.read(int(nir_band)).astype(np.float32)
        ndvi = (N - R) / (N + R + 1e-6)
    st.subheader(f"NDVI – média: {float(np.nanmean(ndvi)):.3f}")
    # normaliza p/ visualizar
    view = ((ndvi - np.nanmin(ndvi)) / (np.nanmax(ndvi)-np.nanmin(ndvi)+1e-6) * 255).astype(np.uint8)
    st.image(view, caption="NDVI (escala 0–255)", use_column_width=True)

    x = ndvi.reshape(-1,1)
    km = KMeans(n_clusters=n_zonas, n_init=10, random_state=42).fit(x)
    centers = sorted([c[0] for c in km.cluster_centers_])
    labels = km.labels_.reshape(ndvi.shape)
    st.caption(f"Centroides (vigor baixo→alto): {', '.join(f'{c:.3f}' for c in centers)}")

    zonas = []
    frac = 1.0/n_zonas
    for i in range(n_zonas):
        area_i = float((labels==i).sum()) / labels.size * area_ha
        zonas.append({"id": f"Z{i+1}", "area_ha": area_i, "vigor": ["baixo","médio","alto","muito alto","elite"][i]})

    st.subheader("Zonas de manejo (estimadas)")
    st.json(zonas)

    if st.button("Gerar PDF (com benchmark de custos)"):
        api = os.getenv("TS_BACKEND_URL","http://localhost:8000")
        # obtém benchmark simples por cultura/região (opcional: adicione inputs)
        bench = {"Sementes (R$/ha)":"-", "NPK (R$/ha)":"-", "Defensivos (R$/ha)":"-"}
        try:
            r = requests.get(f"{api}/costs/benchmark", params={"culture":"soja"}, timeout=20).json()
            if r.get("ok"):
                # usa os 3 itens mais baratos como proxy textual
                items = r["bench"][:3]
                if items:
                    bench = {f"{it['item']} ({it['unit']})": f"{it['price_med']:.2f}" for it in items}
        except Exception as e:
            pass
        payload = {
            "talhao": talhao, "area_ha": area_ha,
            "ndvi_medio": float(np.nanmean(ndvi)), "zonas": zonas,
            "custos": bench, "user_name":"Lucas", "logo_path": None
        }
        try:
            rr = requests.post(f"{api}/reports/talhao/generate", json=payload, timeout=60).json()
            st.success("Relatório gerado"); st.json(rr)
        except Exception as e:
            st.error(str(e))