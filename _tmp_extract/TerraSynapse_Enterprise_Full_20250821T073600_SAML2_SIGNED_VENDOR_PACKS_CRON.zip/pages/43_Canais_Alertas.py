import streamlit as st, requests, os, json

st.set_page_config(page_title="Canais de Alertas", page_icon="📣", layout="wide")
st.title("📣 Canais de Alertas (Slack/Teams/WhatsApp via webhook)")

api = st.text_input("Backend URL", value=os.getenv("TS_BACKEND_URL","http://localhost:8000"))
user_id = st.text_input("Seu e-mail (para permissões)", "lucas@empresa.com")

# Guard
import requests as rq
role_api = api + "/auth/role"
_res = rq.get(role_api, params={"user_id": user_id}).json()
_user_role = (_res.get("role") or "visitante").lower()
_allowed = {"gestor","integrador","engenheiro"}
if _user_role not in _allowed:
    st.error(f"Acesso restrito. Seu papel: '{_user_role}'. Permitidos: {', '.join(_allowed)}")
    st.stop()

st.subheader("Configurar canais (JSON)")
cfg = st.text_area("alerts_channels.json", value=json.dumps({
    "channels":[{"name":"slack-default","type":"slack","url":""},{"name":"teams-default","type":"teams","url":""},{"name":"whatsapp-bridge","type":"whatsapp","url":""}]
}, indent=2))
if st.button("Salvar canais"):
    try:
        payload = json.loads(cfg)
        st.json(requests.post(f"{api}/alerts/channels/set", json=payload.get("channels")).json())
    except Exception as e:
        st.error(f"JSON inválido: {e}")

st.subheader("Enviar teste")
ptype = st.selectbox("Tipo de payload", ["quality_alert","machine_disconnected","daily_summary"])
if st.button("Disparar teste"):
    ex = {
        "quality_alert":{"type":"quality_alert","machine_id":"JD-001","task":"plantio","problems":[{"metric":"fuel_l_ha","value":35,"limit":20}]},
        "machine_disconnected":{"type":"machine_disconnected","machine_id":"JD-002","gap_hours":6.5},
        "daily_summary":{"type":"daily_summary","files":["data/reports/daily_summary_x.csv","data/reports/daily_summary_x.pdf"]}
    }[ptype]
    st.json(requests.post(f"{api}/alerts/channels/test", json=ex).json())