from fastapi import APIRouter, Body, Query
from ..services.sso_oidc import list_providers, set_providers, start, callback

router = APIRouter(prefix="/sso/oidc", tags=["sso-oidc"])

@router.get("/providers")
def providers():
    return list_providers()

@router.post("/providers/set")
def providers_set(payload: dict = Body(...)):
    return set_providers(payload)

@router.get("/start")
def start_auth(provider: str = Query(...), user_id: str = Query(...)):
    return start(provider, user_id)

@router.get("/callback")
def cb(code: str = Query(...), state: str = Query(...)):
    return callback(code, state)

@router.get("/complete")
def complete(provider: str = Query(...), code: str = Query(...), user_id: str = Query(...)):
    from ..services.sso_oidc import exchange_token, fetch_userinfo, persist_link, set_providers
    tok = exchange_token(provider, code)
    if not tok.get("ok"):
        return tok
    access = (tok.get("tokens") or {}).get("access_token","")
    ui = fetch_userinfo(provider, access) if access else {"ok": False, "error":"no_access_token"}
    if ui.get("ok"):
        uinfo = ui.get("userinfo") or {}
        persist_link(user_id, provider, uinfo, tok.get("tokens") or {})
        try:
            from ..services.roles_mapping import map_role
            role = map_role(provider, uinfo, user_id)
        except Exception:
            role = "visitante"
        return {"ok": True, "linked_user": user_id, "provider": provider, "has_userinfo": True, "role_mapped": role}
    return {"ok": True, "linked_user": user_id, "provider": provider, "has_userinfo": False}
