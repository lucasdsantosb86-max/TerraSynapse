from pathlib import Path
import json, time
from .secrets import get_secret_user

BASE = Path(__file__).resolve().parents[2]
ING  = BASE/"data"/"ingest"/"jdlink"
ING.mkdir(parents=True, exist_ok=True)

def save_mock(provider: str, obj: dict):
    fn = ING/f"{provider}_{int(time.time())}.json"
    fn.write_text(json.dumps(obj), encoding="utf-8")
    return fn

def list_recent(limit=20):
    items = []
    for fp in sorted(ING.glob("*.json"))[-limit:]:
        try:
            items.append(json.loads(fp.read_text(encoding='utf-8')))
        except: pass
    return {"ok": True, "items": items}

def test(user_id: str):
    tok = get_secret_user(user_id, "jdlink", "access_token")
    return {"ok": bool(tok), "has_token": bool(tok)}

def ingest_activity(user_id: str, payload: dict):
    # em produção: validar schema JDLink e salvar
    save_mock("activity", {"user_id": user_id, "payload": payload})
    return {"ok": True}