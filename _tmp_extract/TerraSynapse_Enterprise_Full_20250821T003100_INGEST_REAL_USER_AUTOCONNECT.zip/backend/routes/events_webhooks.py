from fastapi import APIRouter, Body
from pathlib import Path
import json

BASE = Path(__file__).resolve().parents[2]
CONF = BASE/"config"/"webhooks.json"

router = APIRouter(prefix="/events", tags=["events"])

@router.get("/webhooks")
def list_hooks():
    return json.loads(CONF.read_text(encoding="utf-8"))

@router.post("/webhooks/add")
def add_hook(event_type: str = Body(...), url: str = Body(...)):
    obj = json.loads(CONF.read_text(encoding="utf-8"))
    obj.setdefault("urls", {}).setdefault(event_type, [])
    if url not in obj["urls"][event_type]:
        obj["urls"][event_type].append(url)
    CONF.write_text(json.dumps(obj, indent=2), encoding="utf-8")
    return {"ok": True}

@router.post("/webhooks/remove")
def remove_hook(event_type: str = Body(...), url: str = Body(...)):
    obj = json.loads(CONF.read_text(encoding="utf-8"))
    arr = obj.setdefault("urls", {}).setdefault(event_type, [])
    if url in arr:
        arr.remove(url)
    CONF.write_text(json.dumps(obj, indent=2), encoding="utf-8")
    return {"ok": True}