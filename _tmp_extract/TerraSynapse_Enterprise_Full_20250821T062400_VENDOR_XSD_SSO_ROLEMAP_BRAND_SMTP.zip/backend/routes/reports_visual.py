from fastapi import APIRouter, Body
from ..services.reports_visual import generate_visual_pdf

router = APIRouter(prefix="/reports/visual", tags=["reports"])

@router.post("/pdf")
def visual_pdf(title: str = Body(...), body: str = Body(...), out_name: str = Body(None), user: str = Body("User")):
    return generate_visual_pdf(title, body, out_name, user)