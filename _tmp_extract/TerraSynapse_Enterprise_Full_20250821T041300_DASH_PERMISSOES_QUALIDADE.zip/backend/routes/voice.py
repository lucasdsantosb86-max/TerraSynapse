from fastapi import APIRouter, UploadFile, File, Form
from ..services.voice import stt_from_wav, tts_to_wav
from pathlib import Path
import time

router = APIRouter(prefix="/voice", tags=["voice"])

@router.post("/stt")
async def stt(file: UploadFile = File(...), lang: str = Form("pt")):
    tmp = Path("data/voice")/f"in_{int(time.time())}.wav"
    with open(tmp, "wb") as f:
        f.write(await file.read())
    return stt_from_wav(str(tmp), lang)

@router.post("/tts")
def tts(text: str = Form(...)):
    out = Path("data/voice")/f"out_{int(time.time())}.wav"
    r = tts_to_wav(text, str(out))
    return {"ok": True, "out": str(out)}