import json, datetime as dt
from pathlib import Path
from apscheduler.schedulers.background import BackgroundScheduler
import requests, os

BASE = Path(__file__).resolve().parents[2]
CONF = BASE/"config"/"scheduler.json"
STATE = BASE/"data"/"scheduler_state.json"

scheduler = None

def _cfg():
    return json.loads(CONF.read_text(encoding="utf-8"))

def _save_state(obj):
    STATE.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")

def _load_state():
    if STATE.exists():
        return json.loads(STATE.read_text(encoding="utf-8"))
    return {"running": False, "last_run": None}

def start_scheduler(api_base: str):
    global scheduler
    cfg = _cfg()
    if scheduler and scheduler.running:
        return {"ok": True, "detail": "already_running"}
    scheduler = BackgroundScheduler(timezone=cfg.get("timezone","America/Sao_Paulo"))
    hh, mm = cfg.get("daily_time","06:10").split(":")
    def _job():
        try:
            url = api_base.rstrip("/") + cfg["job"]["endpoint"]
            r = requests.post(url, timeout=120)
            st = _load_state(); st["last_run"] = dt.datetime.utcnow().isoformat()+"Z"; _save_state(st)
        except Exception as e:
            st = _load_state(); st["last_run"] = "error:"+str(e); _save_state(st)
    scheduler.add_job(_job, "cron", hour=int(hh), minute=int(mm))
    scheduler.start()
    st = _load_state(); st["running"] = True; _save_state(st)
    return {"ok": True, "scheduled": f"{hh}:{mm} {cfg.get('timezone')}"}

def stop_scheduler():
    global scheduler
    if scheduler and scheduler.running:
        scheduler.shutdown(wait=False)
    st = _load_state(); st["running"] = False; _save_state(st)
    return {"ok": True}

def status_scheduler():
    st = _load_state()
    return {"ok": True, **st}