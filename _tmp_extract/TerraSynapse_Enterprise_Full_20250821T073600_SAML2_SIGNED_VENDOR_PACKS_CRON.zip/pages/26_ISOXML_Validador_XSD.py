import streamlit as st, requests, os

st.set_page_config(page_title="Validador ISOXML (XSD)", page_icon="✅", layout="wide")
st.title("✅ Validador ISOXML – XSD (schema-lite)")

api = st.text_input("Backend URL", value=os.getenv("TS_BACKEND_URL","http://localhost:8000"))
user_id = st.text_input("Seu e-mail (para permissões)", "lucas@empresa.com")

# Guard
import requests as rq
role_api = api + "/auth/role"
_res = rq.get(role_api, params={"user_id": user_id}).json()
_user_role = (_res.get("role") or "visitante").lower()
_allowed = {"gestor","integrador","engenheiro"}
if _user_role not in _allowed:
    st.error(f"Acesso restrito. Seu papel: '{_user_role}'. Permitidos: {', '.join(_allowed)}")
    st.stop()

xml = st.text_area("Cole o TASKDATA.XML", height=220)
if st.button("Validar XSD"):
    st.json(requests.post(f"{api}/isoxml/validate_xsd", json={"xml_text": xml}).json())