import json, requests
from pathlib import Path

BASE = Path(__file__).resolve().parents[2]
CONF = BASE/"config"/"weather.json"

def _cfg():
    return json.loads(CONF.read_text(encoding="utf-8"))

def city_id_by_coords(lat: float, lon: float, token: str):
    # API: /locale/city?latitude={lat}&longitude={lon}&token=TOKEN
    api = _cfg()["climatempo"]["api_base"].rstrip("/")
    r = requests.get(f"{api}/locale/city", params={"latitude":lat,"longitude":lon,"token":token}, timeout=20)
    r.raise_for_status()
    arr = r.json()
    if isinstance(arr, list) and arr:
        return arr[0]["id"]
    raise RuntimeError("Cidade não encontrada para as coordenadas.")

def daily_forecast(city_id: int, token: str):
    # API: /forecast/locale/{id}/daily?days=7&token=TOKEN
    api = _cfg()["climatempo"]["api_base"].rstrip("/")
    r = requests.get(f"{api}/forecast/locale/{city_id}/daily", params={"days":7,"token":token}, timeout=20)
    r.raise_for_status()
    return r.json()

def forecast_by_coords(lat: float, lon: float):
    cfg = _cfg()
    token = cfg["climatempo"].get("token","")
    if not token:
        return {"ok": False, "detail":"token_climatempo_ausente"}
    cid = city_id_by_coords(lat, lon, token)
    data = daily_forecast(cid, token)
    return {"ok": True, "provider":"climatempo", "city_id": cid, "data": data}