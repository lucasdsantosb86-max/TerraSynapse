from fastapi import APIRouter, Body
from ..services.import_scheduler import upsert_job, list_jobs, run_all

router = APIRouter(prefix="/costs/schedule", tags=["costs"])

@router.get("/list")
def list_all():
    return list_jobs()

@router.post("/upsert")
def upsert(source: str = Body(...), url: str = Body(...), threshold_pct: float = Body(5.0)):
    return upsert_job(source, url, threshold_pct)

@router.post("/run")
def run():
    return run_all()