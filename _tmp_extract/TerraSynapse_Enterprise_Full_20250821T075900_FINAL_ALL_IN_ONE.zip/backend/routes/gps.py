from fastapi import APIRouter, Body
from ..services.gps_ingest import ingest_row, ingest_bulk

router = APIRouter(prefix="/ingest/gps", tags=["gps"])

@router.post("/row")
def row(payload: dict = Body(...)):
    return ingest_row(payload)

@router.post("/bulk")
def bulk(payload: list = Body(...)):
    return ingest_bulk(payload)