from fastapi import APIRouter, Body
from ..services.alerts import update_health, run_checks
from pathlib import Path, PurePosixPath
import json

router = APIRouter(prefix="/alerts", tags=["alerts"])

@router.post("/health")
def ping(component: str = Body(...), ok: bool = Body(...)):
    return update_health(component, ok)

@router.post("/run")
def run(forecast: dict = Body(None)):
    return run_checks(forecast)