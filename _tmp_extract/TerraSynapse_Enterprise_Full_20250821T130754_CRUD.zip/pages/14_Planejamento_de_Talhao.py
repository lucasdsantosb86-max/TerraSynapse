
import streamlit as st, numpy as np
st.set_page_config(page_title='Planejamento de Talhão – TerraSynapse', page_icon='🛰️', layout='wide')
st.title('🛰️ Planejamento de Talhão – NDVI / Segmentação / Rotas')
tab1, tab2 = st.tabs(['GeoTIFF (NDVI/NDRE)', 'RGB + escala (proxy)'])
with tab1:
    st.subheader('GeoTIFF com bandas NIR/RED (opcional RE)')
    uploaded = st.file_uploader('Envie um GeoTIFF (pilha: NIR, RED, [RE])', type=['tif','tiff'])
    cultura = st.selectbox('Cultura', ['soja','milho','cana','cafe','trigo','arroz','algodao','sorgo'])
    spacing = st.slider('Espaçamento de linhas (m)', 5, 30, 10, 1)
    if uploaded and st.button('Analisar GeoTIFF'):
        import requests
        files = {'file': (uploaded.name, uploaded.getvalue(), uploaded.type)}
        resp = requests.post('http://localhost:8000/vision/aerial/geotiff', files=files, data={'cultura': cultura, 'spacing_m': spacing})
        if resp.ok:
            res = resp.json()
            colA, colB = st.columns(2)
            with colA:
                st.metric('Área útil (ha)', f"{res.get('area_ha',0):.3f}")
                st.json(res.get('ndvi_stats', {}))
            with colB:
                st.write('Rotas sugeridas (GeoJSON)'); st.code(res.get('routes_geojson', {}), language='json')
            rec = res.get('recomendacao', {})
            st.success(f"Sementes (un/ha): {rec.get('sementes_un_ha')} | Adubo (kg/ha): {rec.get('adubo_kg_ha')}")
        else:
            st.error('Falha na análise. Verifique o backend em :8000.')
with tab2:
    st.subheader('Imagem RGB de drone (proxy NDVI)')
    img = st.camera_input('Tirar Foto (RGB)')
    mpp = st.number_input('Escala (metros por pixel)', min_value=0.0, value=0.0, step=0.01, help='Se desconhecida, 0 para ignorar.')
    cultura2 = st.selectbox('Cultura (RGB)', ['soja','milho','cana','cafe','trigo','arroz','algodao','sorgo'], key='c2')
    if img and st.button('Analisar RGB'):
        import numpy as np, PIL.Image as Image
        from backend.services.aerial import analyze_rgb_image
        rgb = np.array(Image.open(img).convert('RGB'))
        res = analyze_rgb_image(rgb, meters_per_px=(mpp or None), cultura=cultura2)
        st.metric('Pixels plantáveis', res['mask_pixels'])
        if res.get('area_ha'): st.metric('Área útil (ha)', f"{res['area_ha']:.3f}")
        st.json(res['ndvi_proxy_stats'])
        rec = res['recomendacao']; st.success(f"Sementes (un/ha): {rec['sementes_un_ha']} | Adubo (kg/ha): {rec['adubo_kg_ha']}")
