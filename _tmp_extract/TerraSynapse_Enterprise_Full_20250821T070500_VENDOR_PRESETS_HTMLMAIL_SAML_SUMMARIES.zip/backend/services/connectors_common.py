from pathlib import Path
import json, requests
from .secrets import get_secret, get_secret_user

BASE = Path(__file__).resolve().parents[2]
REG = json.loads((BASE/"config"/"providers_registry.json").read_text(encoding="utf-8"))

def _resp(ok, status, detail=""):
    return {"ok": ok, "status": status, "detail": detail}

def test_provider(provider: str, user_id: str=None):
    p = REG.get(provider, {})
    if not p: return _resp(False, "unknown_provider", "Provider não registrado")
    # coleta chaves
    def sec(k):
        if user_id:
            v = get_secret_user(user_id, provider, k)
            if v: return v
        return get_secret(provider, k)

    if provider == "openmeteo":
        # sem chave; teste de reachability simples
        try:
            r = requests.get("https://api.open-meteo.com/v1/forecast?latitude=0&longitude=0&daily=temperature_2m_max&forecast_days=1", timeout=10)
            return _resp(r.status_code==200, "ready" if r.status_code==200 else "error", f"http_{r.status_code}")
        except Exception as e:
            return _resp(False, "error", str(e))

    if provider == "climatempo":
        token = sec("token")
        if not token: return _resp(False, "missing_keys", "token")
        # ping básico (documentação pública exige cadastro); aqui só verifica formato
        return _resp(True, "ready", "token_presente")

    if provider == "openweather":
        key = sec("api_key")
        if not key: return _resp(False, "missing_keys", "api_key")
        try:
            r = requests.get("https://api.openweathermap.org/data/2.5/weather", params={"lat":0,"lon":0,"appid":key}, timeout=10)
            ok = r.status_code in (200,401)  # 401 indica chave inválida, mas host acessível
            return _resp(ok, "ready" if r.status_code==200 else "auth_error", f"http_{r.status_code}")
        except Exception as e:
            return _resp(False, "error", str(e))

    if provider == "jdlink":
        cid = sec("client_id"); csec = sec("client_secret")
        if not cid or not csec: return _resp(False, "missing_keys", "client_id/client_secret")
        # endpoint OAuth exigirá ambiente real; validamos formato/alcance do host público
        try:
            r = requests.get("https://developer.deere.com/", timeout=10)
            return _resp(r.status_code==200, "ready" if r.status_code==200 else "error", f"http_{r.status_code}")
        except Exception as e:
            return _resp(False, "error", str(e))

    if provider in ("dji","dronedeploy","pix4d","sentinelhub"):
        # valida host público e presença de chave
        need = {"dji":"app_key","dronedeploy":"api_key","pix4d":"api_key","sentinelhub":"client_id"}[provider]
        if not sec(need): return _resp(False, "missing_keys", need)
        try:
            url = {"dji":"https://developer.dji.com/","dronedeploy":"https://developers.dronedeploy.com/",
                   "pix4d":"https://developer.pix4d.com/","sentinelhub":"https://www.sentinel-hub.com/"}[provider]
            r = requests.get(url, timeout=10)
            return _resp(r.status_code==200, "ready" if r.status_code==200 else "error", f"http_{r.status_code}")
        except Exception as e:
            return _resp(False, "error", str(e))

    if provider in ("nmea_tcp","mqtt_sensors","modbus_tcp"):
        # conexão testada em /connectors/activate específicos; aqui só confirma presença de parâmetros
        reqs = p.get("required", [])
        miss = [k for k in reqs if not sec(k)]
        if miss: return _resp(False, "missing_keys", ",".join(miss))
        return _resp(True, "ready", "parametros_ok")

    return _resp(True, "ready", "sem_teste_especifico")