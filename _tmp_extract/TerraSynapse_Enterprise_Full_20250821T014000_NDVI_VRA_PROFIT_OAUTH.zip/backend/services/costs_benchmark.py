from pathlib import Path
import pandas as pd

BASE = Path(__file__).resolve().parents[2]
SRC = BASE/"data"/"costs"/"sources"
SRC.mkdir(parents=True, exist_ok=True)

def benchmark(culture: str=None, region: str=None):
    files = sorted(SRC.glob("*.csv"), key=lambda p: p.stat().st_mtime, reverse=True)[:10]
    if not files: return {"ok": False, "detail":"sem dados"}
    df = pd.concat([pd.read_csv(f) for f in files], ignore_index=True)
    if culture:
        df = df[df["item"].str.contains(culture, case=False, na=False)]
    if region:
        df = df[df["region"].str.contains(region, case=False, na=False)]
    if df.empty: return {"ok": False, "detail":"sem linhas após filtros"}
    res = df.groupby(["item","unit"]).agg(price_med=("price_local","median"), n=("price_local","count")).reset_index()
    out = res.sort_values("price_med").head(50).to_dict(orient="records")
    return {"ok": True, "bench": out}