
import streamlit as st, json
from pathlib import Path
st.set_page_config(page_title='Admin – Configurações TerraSynapse', page_icon='⚙️', layout='wide')
from frontend.auth import require
user = require(roles=('developer','gestor'))

st.title('⚙️ Admin – Configurações gerais')
CONFIG_DIR = Path('data/config'); CONFIG_DIR.mkdir(parents=True, exist_ok=True)
bp_path = CONFIG_DIR/'brand_policy.json'
pr_path = CONFIG_DIR/'insumos_precos.json'
def load_json(p, default): 
    try: return json.loads(p.read_text(encoding='utf-8'))
    except Exception: return default
brand = load_json(bp_path, {"hide_third_party_brands": True, "scenario":"consultoria_tecnica"})
precos = load_json(pr_path, {"moeda":"BRL"})
st.subheader('Política de marcas')
brand['hide_third_party_brands'] = st.toggle('Ocultar marcas de terceiros nas respostas (modo consultoria)', value=brand.get('hide_third_party_brands', True))
brand['scenario'] = st.selectbox('Cenário de comunicação', ['consultoria_tecnica','proposta_comercial'], index=0 if brand.get('scenario')=='consultoria_tecnica' else 1)
if st.button('Salvar política de marcas'):
    bp_path.write_text(json.dumps(brand, indent=2), encoding='utf-8')
    st.success('Política de marcas salva.')
st.divider()
st.subheader('Preços de insumos (por cultura)')
moeda = st.text_input('Moeda', value=precos.get('moeda','BRL'))
precos['moeda'] = moeda
for cult in ['soja','milho','cana','cafe','trigo','arroz','algodao','sorgo']:
    st.markdown(f'**{cult.capitalize()}**')
    row = precos.get(cult, {})
    colA, colB, colC = st.columns(3)
    with colA: row['preco_semente_un'] = st.number_input(f'{cult} – Preço semente (por unidade)', value=float(row.get('preco_semente_un',0.0)), min_value=0.0, step=0.0001, format="%.4f", key=f's_{cult}')
    with colB: row['preco_fert_kg'] = st.number_input(f'{cult} – Preço fertilizante (kg)', value=float(row.get('preco_fert_kg',0.0)), min_value=0.0, step=0.1, key=f'f_{cult}')
    with colC: row['preco_defensivo_l'] = st.number_input(f'{cult} – Preço defensivo (L)', value=float(row.get('preco_defensivo_l',0.0)), min_value=0.0, step=0.1, key=f'd_{cult}')
    precos[cult] = row
if st.button('Salvar preços'):
    pr_path.write_text(json.dumps(precos, indent=2, ensure_ascii=False), encoding='utf-8')
    st.success('Preços atualizados.')
