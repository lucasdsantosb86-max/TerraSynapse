from pathlib import Path
import json
from .connectors_common import test_provider

BASE = Path(__file__).resolve().parents[2]
CONF = BASE/"config"/"user_integrations.json"

def _load():
    try:
        return json.loads(CONF.read_text(encoding="utf-8"))
    except Exception:
        return {"users":{}}

def _save(obj):
    CONF.write_text(json.dumps(obj, indent=2), encoding="utf-8")

def set_autoconnect(user_id: str, enabled: bool):
    obj = _load()
    obj["users"].setdefault(user_id, {}).update({"auto_connect": bool(enabled)})
    _save(obj); return {"ok": True, "auto_connect": enabled}

def get_settings(user_id: str):
    return _load().get("users",{}).get(user_id, {"auto_connect": False})

def on_secret_saved(user_id: str, provider: str):
    st = get_settings(user_id)
    if not st.get("auto_connect"): 
        return {"ok": True, "auto": False, "detail":"auto_connect_desativado"}
    res = test_provider(provider, user_id)
    # poderia persistir status por usuário+provider
    obj = _load()
    u = obj["users"].setdefault(user_id, {})
    provs = u.setdefault("providers_status", {})
    provs[provider] = res
    _save(obj)
    return {"ok": True, "auto": True, "result": res}