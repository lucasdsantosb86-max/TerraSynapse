import io, json, numpy as np
from pathlib import Path
import streamlit as st
from PIL import Image
from backend.geo.ndvi_segment import ndvi_from_bands, ndvi_proxy_from_rgb, segment_ndvi, area_ha_from_mask
from backend.geo.area_insumos import compute_inputs

st.set_page_config(page_title="Planejamento de Talhão", page_icon="🧭")

st.title("🧭 Planejamento de Talhão – TerraSynapse")
st.caption("NDVI/segmentação, cálculo de área útil e insumos com custo estimado.")

with st.expander("Configurações"):
    cultura = st.selectbox("Cultura", ["soja","milho","trigo","citros","cana"])
    pixel_area_m2 = st.number_input("Área por pixel (m²)", value=0.25, min_value=0.0001)
    threshold = st.slider("Limiar NDVI/proxy para vegetação", 0.0, 1.0, 0.30, 0.01)

tab1, tab2 = st.tabs(["Imagem RGB (proxy NDVI)", "Bandas RED+NIR (.npy)"])

area_ha = None

with tab1:
    rgb_file = st.file_uploader("Imagem RGB (JPG/PNG)", type=["jpg","jpeg","png"])
    if rgb_file is not None:
        im = Image.open(rgb_file).convert("RGB")
        st.image(im, caption="Pré-visualização (RGB)", use_column_width=True)
        ndvi = ndvi_proxy_from_rgb(np.array(im))
        mask = segment_ndvi(ndvi, threshold=threshold)
        area_ha = area_ha_from_mask(mask, pixel_area_m2=pixel_area_m2)
        st.success(f"Área estimada (ha): {area_ha:.4f}")
        st.bar_chart(np.clip(ndvi.flatten(), -1, 1))

with tab2:
    red_np = st.file_uploader("Banda RED (.npy)", type=["npy"])
    nir_np = st.file_uploader("Banda NIR (.npy)", type=["npy"])
    if red_np and nir_np:
        red = np.load(red_np)
        nir = np.load(nir_np)
        ndvi = ndvi_from_bands(red, nir)
        mask = segment_ndvi(ndvi, threshold=threshold)
        area_ha = area_ha_from_mask(mask, pixel_area_m2=pixel_area_m2)
        st.success(f"Área estimada (ha): {area_ha:.4f}")
        st.bar_chart(np.clip(ndvi.flatten(), -1, 1))

st.divider()
if area_ha is not None:
    st.subheader("📦 Insumos e custo estimado")
    calc = compute_inputs(cultura, area_ha)
    st.json(calc)
    if st.button("Exportar JSON de planejamento"):
        out_path = Path("/mnt/data")/f"planejamento_{cultura}.json"
        out_path.write_text(json.dumps(calc, ensure_ascii=False, indent=2), encoding="utf-8")
        st.success(f"Arquivo gerado: {out_path}")

from backend.services.alerts import check_cost_threshold

# alerta automático quando custo/ha > limiar
if area_ha is not None:
    per_ha = 0.0
    try:
        per_ha = calc["total_R$"]/area_ha if area_ha>0 else 0.0
    except:
        per_ha = 0.0
    chk = check_cost_threshold(cultura, calc["total_R$"], area_ha)
    if chk.get("alerta"):
        st.error(f"🚨 Custo estimado {chk['custo_R$_ha']:.2f} R$/ha excede limiar {chk['limiar_R$_ha']:.2f} R$/ha para {cultura}.")
    else:
        st.success(f"Custo estimado {chk['custo_R$_ha']:.2f} R$/ha dentro do limiar ({chk['limiar_R$_ha']:.2f} R$/ha).")


st.subheader("GeoTIFF (NDVI real)")
tif = st.file_uploader("Enviar GeoTIFF (Sentinel/Landsat)", type=["tif","tiff"])
if tif is not None:
    from backend.services.geotiff import read_ndvi_from_geotiff
    import numpy as np, tempfile
    with tempfile.NamedTemporaryFile(delete=False, suffix=".tif") as tf:
        tf.write(tif.read()); tf.flush()
        ndvi, px = read_ndvi_from_geotiff(tf.name)
    thr = st.slider("Threshold NDVI (área útil)", 0.2, 0.8, 0.35, 0.01)
    mask = ndvi >= thr
    area_ha = (mask.sum() * px) / 10000.0
    st.metric("Área útil (ha)", f"{area_ha:.2f}")
    if 'calc' in locals():
        from backend.services.alerts import check_cost_threshold
        chk = check_cost_threshold(cultura, calc.get("total_R$",0.0), area_ha)
        if chk.get("alerta"):
            st.error(f"🚨 {chk['custo_R$_ha']:.2f} R$/ha > {chk['limiar_R$_ha']:.2f} (limiar {cultura})")
        else:
            st.success(f"{chk['custo_R$_ha']:.2f} R$/ha dentro do limiar ({cultura})")
