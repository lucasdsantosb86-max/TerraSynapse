
from __future__ import annotations
from fastapi import FastAPI
from .services.security_mw import RateLimitMiddleware, UploadFile, File, Form
from typing import Optional
import json
from backend.services import gps as gpssvc
from backend.services import alerts as alertsvc
from backend.services import aerial as aerialsvc
app = FastAPI(title="TerraSynapse IA – Backend")
@app.get("/health/ping")
def ping(): return {"ok": True}
@app.post("/ingest/gps")
async def ingest_gps(payload: Optional[str]=Form(None), file: Optional[UploadFile]=File(None)):
    if file is not None:
        content = (await file.read()).decode("utf-8", errors="ignore")
        ok = True
        for line in content.splitlines():
            line = line.strip()
            if not line: continue
            if line.startswith("$"): ok = gpssvc.ingest(line) and ok
            else:
                try: ok = gpssvc.ingest(json.loads(line)) and ok
                except Exception: pass
        return {"ok": ok}
    elif payload:
        try:
            data = json.loads(payload); ok = gpssvc.ingest(data); return {"ok": ok}
        except Exception:
            ok = gpssvc.ingest(payload); return {"ok": ok}
    return {"ok": False}
@app.get("/gps/metrics")
def gps_metrics(date: Optional[str]=None): return gpssvc.get_daily_metrics(date)
@app.post("/alerts/apply")
async def alerts_apply(payload: str = Form(...)):
    rows = json.loads(payload); out = alertsvc.apply_sensor_rules(rows); return {"alerts": out}
@app.post("/alerts/heartbeat")
async def alerts_heartbeat(ping_ok: bool = Form(True)):
    rec = alertsvc.check_connectivity(ping_ok); return {"recorded": rec is not None}
@app.post("/vision/aerial/geotiff")
async def vision_aerial_geotiff(file: UploadFile = File(...), cultura: str="soja", spacing_m: float=10.0):
    data = await file.read()
    import tempfile
    with tempfile.NamedTemporaryFile(suffix=".tif", delete=True) as tmp:
        tmp.write(data); tmp.flush()
        res = aerialsvc.analyze_geotiff(tmp.name, cultura=cultura, spacing_m=spacing_m)
    return res


from backend.services import knowledge as knsvc

@app.get("/knowledge/list")
def knowledge_list(): 
    return knsvc.list_sources()

@app.post("/knowledge/ingest_all")
def knowledge_ingest_all():
    return knsvc.ingest_all()

from .routes.security_tools import router as security_tools_router
app.include_router(security_tools_router)

from .routes.costs_seeds import router as costs_seeds_router
app.include_router(costs_seeds_router)

from .routes.benchmarks import router as benchmarks_router
app.include_router(benchmarks_router)

from .routes.auth import router as auth_router
app.include_router(auth_router)

from .routes.reports_visual import router as reports_visual_router
app.include_router(reports_visual_router)

from .routes.totp_recovery import router as totp_recovery_router
app.include_router(totp_recovery_router)

from .routes.costs_importers import router as costs_importers_router
app.include_router(costs_importers_router)
\nfrom .routes.costs_schedule import router as costs_schedule_router\napp.include_router(costs_schedule_router)\n
from .routes.apsched import router as scheduler_router
app.include_router(scheduler_router)
\nfrom .routes.reports_talhao import router as reports_talhao_router\napp.include_router(reports_talhao_router)\n\nfrom .routes.voice import router as voice_router\napp.include_router(voice_router)\n
from .routes.ndvi import router as ndvi_router
app.include_router(ndvi_router)

from .routes.aerial_segment import router as aerial_segment_router
app.include_router(aerial_segment_router)

from .routes.costs_benchmark import router as costs_benchmark_router
app.include_router(costs_benchmark_router)

from .routes.weather_climatempo import router as weather_router
app.include_router(weather_router)

from .routes.gps_ingest import router as gps_router
app.include_router(gps_router)

from .routes.secrets import router as secrets_router
app.include_router(secrets_router)

from .routes.connectors import router as connectors_router
app.include_router(connectors_router)

from .routes.scheduler import router as scheduler_router
app.include_router(scheduler_router)

from .routes.events_webhooks import router as events_router
app.include_router(events_router)

from .routes.alerts import router as alerts_router
app.include_router(alerts_router)

from .routes.events_log import router as events_log_router
app.include_router(events_log_router)

from .routes.reports_alerts import router as reports_alerts_router
app.include_router(reports_alerts_router)

from .routes.connectors_test import router as connectors_test_router
app.include_router(connectors_test_router)

from .routes.user_integrations import router as user_integrations_router
app.include_router(user_integrations_router)

from .routes.secrets_user_hook import router as secrets_user_hook_router
app.include_router(secrets_user_hook_router)

from .routes.ingest_gps import router as ingest_gps_router
app.include_router(ingest_gps_router)

from .routes.ingest_external import router as ingest_external_router
app.include_router(ingest_external_router)

from .routes.crm_clients import router as crm_clients_router
app.include_router(crm_clients_router)

from .routes.crm_team import router as crm_team_router
app.include_router(crm_team_router)

from .routes.crm_tasks import router as crm_tasks_router
app.include_router(crm_tasks_router)

from .routes.crm_comms import router as crm_comms_router
app.include_router(crm_comms_router)

from .routes.vra_prescription import router as vra_prescription_router
app.include_router(vra_prescription_router)

from .routes.profitability import router as profitability_router
app.include_router(profitability_router)

from .routes.zootec_thi import router as zootec_thi_router
app.include_router(zootec_thi_router)

from .routes.dairy_kpis import router as dairy_kpis_router
app.include_router(dairy_kpis_router)

from .routes.ingest_dairy import router as ingest_dairy_router
app.include_router(ingest_dairy_router)
\nfrom .routes.ndvi_segment import router as ndvi_segment_router\napp.include_router(ndvi_segment_router)\n\nfrom .routes.profitability_zoned import router as profitability_zoned_router\napp.include_router(profitability_zoned_router)\n\nfrom .routes.oauth_jdlink import router as oauth_jdlink_router\napp.include_router(oauth_jdlink_router)\n
from .routes.templates import router as templates_router
app.include_router(templates_router)

from .routes.dairy_alerts import router as dairy_alerts_router
app.include_router(dairy_alerts_router)

from .routes.jdlink import router as jdlink_router
app.include_router(jdlink_router)
