from pathlib import Path
import json, time
import requests

BASE = Path(__file__).resolve().parents[2]
CONF = BASE/"config"/"alerts.json"
LOG  = BASE/"data"/"alerts"/"webhook.log"

def _cfg():
    try:
        return json.loads(CONF.read_text(encoding="utf-8"))
    except Exception:
        return {"disconnect_hours": 4, "webhook_url": ""}

def set_webhook(url: str):
    c = _cfg(); c["webhook_url"] = url
    CONF.write_text(json.dumps(c, indent=2), encoding="utf-8")
    return {"ok": True, "webhook_url": url}

def set_threshold(hours: int):
    c = _cfg(); c["disconnect_hours"] = int(hours)
    CONF.write_text(json.dumps(c, indent=2), encoding="utf-8")
    return {"ok": True, "disconnect_hours": int(hours)}

def send(payload: dict):
    cfg = _cfg()
    url = (cfg.get("webhook_url") or "").strip()
    line = {"ts": int(time.time()), "payload": payload, "to": url or "local_log"}
    # registra no log sempre
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(json.dumps(line, ensure_ascii=False) + "\n")
    if not url:
        return {"ok": True, "sent": False, "reason": "webhook_url_empty"}
    try:
        r = requests.post(url, json=payload, timeout=5)
        return {"ok": r.status_code in (200,201,202), "status": r.status_code}
    except Exception as e:
        return {"ok": False, "error": str(e)}