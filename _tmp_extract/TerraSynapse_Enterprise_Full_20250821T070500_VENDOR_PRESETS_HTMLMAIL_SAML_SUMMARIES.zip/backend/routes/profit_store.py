from fastapi import APIRouter, Body, Query
from ..services.profit_store import save_record, list_records

router = APIRouter(prefix="/profit/store", tags=["profit-store"])

@router.post("/save")
def save(payload: dict = Body(...)):
    return save_record(payload)

@router.get("/list")
def list_(limit: int = Query(100)):
    return list_records(limit)