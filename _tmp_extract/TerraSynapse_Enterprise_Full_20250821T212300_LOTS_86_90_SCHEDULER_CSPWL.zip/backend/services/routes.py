
from __future__ import annotations
import numpy as np, json
from shapely.geometry import shape, mapping, Polygon, LineString
from shapely.affinity import rotate
def main_axis(poly: Polygon):
    min_rect = poly.minimum_rotated_rectangle
    coords = list(min_rect.exterior.coords)
    dists = []
    for i in range(4):
        p1, p2 = np.array(coords[i]), np.array(coords[(i+1)%4])
        d = np.linalg.norm(p2-p1); dists.append((d, p1, p2))
    dists.sort(reverse=True, key=lambda x:x[0])
    _, p1, p2 = dists[0]
    angle = np.degrees(np.arctan2(p2[1]-p1[1], p2[0]-p1[0]))
    return angle
def parallel_lines(poly: Polygon, spacing: float=10.0):
    from shapely.affinity import rotate
    angle = main_axis(poly)
    rot = rotate(poly, -angle, origin="centroid")
    minx, miny, maxx, maxy = rot.bounds
    y = miny + spacing/2.0
    lines = []
    from shapely.geometry import LineString
    while y <= maxy:
        line = LineString([(minx, y), (maxx, y)])
        seg = line.intersection(rot)
        if not seg.is_empty:
            seg = rotate(seg, angle, origin="centroid")
            lines.append(seg)
        y += spacing
    return lines
def export_geojson(lines) -> dict:
    feats = []
    for i, geom in enumerate(lines):
        feats.append({"type":"Feature","properties":{"id":i},"geometry":mapping(geom)})
    return {"type":"FeatureCollection","features":feats}
