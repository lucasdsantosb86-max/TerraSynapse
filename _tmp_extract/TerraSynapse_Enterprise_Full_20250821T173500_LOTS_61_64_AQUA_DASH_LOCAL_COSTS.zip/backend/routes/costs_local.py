from fastapi import APIRouter, Body
from ..services.costs_local import normalize_local
from pathlib import Path

router = APIRouter(prefix="/costs/local", tags=["costs"])

@router.post("/normalize")
def normalize(src: str = Body(...)):
    out = Path(src).with_suffix(".normalized.csv")
    return normalize_local(src, str(out))