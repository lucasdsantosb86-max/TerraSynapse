import requests, json
def forecast_by_coords(lat: float, lon: float):
    # 7 dias diários (min/max, wind, rain) — sem chave
    url = "https://api.open-meteo.com/v1/forecast"
    params = {
        "latitude": lat, "longitude": lon,
        "daily": "temperature_2m_min,temperature_2m_max,precipitation_sum,windspeed_10m_max",
        "forecast_days": 7, "timezone": "auto"
    }
    r = requests.get(url, params=params, timeout=20); r.raise_for_status()
    j = r.json()
    days = []
    for i, d in enumerate(j.get("daily", {}).get("time", [])):
        days.append({
            "date": d,
            "temperature": {"min": j["daily"]["temperature_2m_min"][i], "max": j["daily"]["temperature_2m_max"][i]},
            "rain": {"precipitation": j["daily"]["precipitation_sum"][i]},
            "wind": {"velocity_max": j["daily"]["windspeed_10m_max"][i]}
        })
    return {"ok": True, "provider":"openmeteo", "data": days}