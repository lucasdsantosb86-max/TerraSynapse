<# TerraSynapse – run_all.ps1
Uso:
  .\run_all.ps1 start|stop|status|restart
#>
param([string]$cmd="help")
$ErrorActionPreference = "Stop"
$APP_DIR = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $APP_DIR
$VENV = Join-Path $APP_DIR ".venv"
$LOGS = Join-Path $APP_DIR "logs"
$PIDS = Join-Path $APP_DIR ".pids"
New-Item -ItemType Directory -Force -Path $LOGS,$PIDS | Out-Null

function Ensure-Venv {
  if (-Not (Test-Path $VENV)) { python -m venv $VENV }
  & "$VENV\Scripts\python.exe" -m pip install --upgrade pip | Out-Null
  & "$VENV\Scripts\pip.exe" install -r requirements.txt
}
function Start-Backend {
  $backend = Start-Process -FilePath "$VENV\Scripts\python.exe" -ArgumentList "-m","uvicorn","backend.app:app","--host","0.0.0.0","--port","8000" -RedirectStandardOutput "$LOGS\backend.out" -RedirectStandardError "$LOGS\backend.err" -PassThru
  Set-Content "$PIDS\backend.pid" $backend.Id
  Write-Host "Backend PID $($backend.Id)"
}
function Start-Streamlit([string]$page,[int]$port){
  $name = [IO.Path]::GetFileNameWithoutExtension($page)
  $proc = Start-Process -FilePath "$VENV\Scripts\streamlit.exe" -ArgumentList "run",$page,"--server.port",$port,"--server.headless","true" -RedirectStandardOutput "$LOGS\streamlit_${name}.out" -RedirectStandardError "$LOGS\streamlit_${name}.err" -PassThru
  Set-Content "$PIDS\streamlit_${name}.pid" $proc.Id
  Write-Host "Streamlit $name PID $($proc.Id) porta $port"
}
function Stop-All {
  Get-ChildItem "$PIDS\*.pid" -ErrorAction SilentlyContinue | ForEach-Object {
    $pid = Get-Content $_.FullName
    try { Stop-Process -Id $pid -Force -ErrorAction SilentlyContinue } catch {}
    Remove-Item $_.FullName -Force -ErrorAction SilentlyContinue
  }
  Write-Host "Processos finalizados."
}
function Status-All {
  Get-ChildItem "$PIDS\*.pid" -ErrorAction SilentlyContinue | ForEach-Object {
    $pid = Get-Content $_.FullName
    try { $p = Get-Process -Id $pid -ErrorAction Stop; Write-Host "$($_.BaseName): OK PID $pid" }
    catch { Write-Host "$($_.BaseName): parado (PID $pid)" }
  }
}
switch ($cmd) {
  "start" {
    Ensure-Venv
    if (-Not $env:TS_SECRETS_KEY) { $env:TS_SECRETS_KEY = & "$VENV\Scripts\python.exe" -c "from cryptography.fernet import Fernet;print(Fernet.generate_key().decode())" }
    Start-Backend
    Start-Streamlit "pages/04_Gerenciar_Usuarios.py" 8501
    Start-Streamlit "pages/27_ISOXML_Schemas_Vendor.py" 8502
    Start-Streamlit "pages/28_ISOXML_Vendor_Presets.py" 8503
    Start-Streamlit "pages/44_Scheduler_Summaries.py" 8504
  }
  "stop" { Stop-All }
  "status" { Status-All }
  "restart" { Stop-All; & $MyInvocation.MyCommand.Path start }
  default { Write-Host "Uso: .\run_all.ps1 start|stop|status|restart" }
}