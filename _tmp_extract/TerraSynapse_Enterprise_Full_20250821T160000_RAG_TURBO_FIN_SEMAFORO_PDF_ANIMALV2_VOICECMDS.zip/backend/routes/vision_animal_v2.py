from fastapi import APIRouter, UploadFile, File
import numpy as np, cv2
from ..services.vision_animal_v2 import analyze

router = APIRouter(prefix="/vision/animal_v2", tags=["vision"])

@router.post("/analyze")
async def analyze_animal_v2(file: UploadFile = File(...)):
    data = await file.read()
    img = cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_COLOR)
    return analyze(img)