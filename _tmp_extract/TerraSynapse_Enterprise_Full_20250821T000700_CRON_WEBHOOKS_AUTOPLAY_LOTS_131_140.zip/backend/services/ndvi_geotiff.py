from pathlib import Path
import rasterio
import numpy as np
from sklearn.cluster import KMeans

def compute_ndvi_geotiff(tif_path: str, red_band:int=None, nir_band:int=None):
    """Computa NDVI a partir de um GeoTIFF multibanda.
    - Se red_band/nir_band não informados, tenta heurísticas comuns (Sentinel-2: B4=Red, B8=NIR).
    - Retorna dict: {ndvi_mean, ndvi_min, ndvi_max}
    """
    with rasterio.open(tif_path) as src:
        count = src.count
        # Heurística: se >= 8 bandas, usa 4 e 8 (1-indexed). Se 3 bandas, tenta RGB proxy (G-R)/(G+R).
        if red_band is None or nir_band is None:
            if count >= 8:
                red_band = 4; nir_band = 8
            elif count >= 4:
                red_band = 3; nir_band = 4
            else:
                # fallback: RGB proxy se só 3 bandas
                arr = src.read([1,2,3]).astype(np.float32)
                R,G,B = arr[0], arr[1], arr[2]
                ndvi = (G - R) / (G + R + 1e-6)
                return {"mode":"proxy_rgb","ndvi_mean":float(np.nanmean(ndvi)), "ndvi_min":float(np.nanmin(ndvi)), "ndvi_max":float(np.nanmax(ndvi))}
        red = src.read(red_band).astype(np.float32)
        nir = src.read(nir_band).astype(np.float32)
        ndvi = (nir - red) / (nir + red + 1e-6)
        return {"mode":"geotiff","ndvi_mean":float(np.nanmean(ndvi)), "ndvi_min":float(np.nanmin(ndvi)), "ndvi_max":float(np.nanmax(ndvi))}

def zone_by_kmeans(ndvi_array: np.ndarray, n_zonas:int=3, random_state:int=42):
    x = ndvi_array.reshape(-1,1)
    km = KMeans(n_clusters=n_zonas, n_init=10, random_state=random_state)
    labels = km.fit_predict(x)
    centers = sorted([(i, km.cluster_centers_[i][0]) for i in range(n_zonas)], key=lambda t:t[1])
    # mapa de label antigo→rank (baixo, médio, alto)
    rank = {centers[i][0]: i for i in range(n_zonas)}
    ranked = np.vectorize(rank.get)(labels)
    return ranked.reshape(ndvi_array.shape), centers