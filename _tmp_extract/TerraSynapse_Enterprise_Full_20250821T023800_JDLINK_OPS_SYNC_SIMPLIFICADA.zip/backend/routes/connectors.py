from fastapi import APIRouter, Body
from pathlib import Path
import json
from ..services.secrets import get_secret, masked
from ..connectors.gps_nmea_tcp import test_connect as nmea_test
from ..connectors.mqtt_client import test_connect as mqtt_test

BASE = Path(__file__).resolve().parents[2]
REG = json.loads((BASE/"config"/"providers_registry.json").read_text(encoding="utf-8"))

router = APIRouter(prefix="/connectors", tags=["connectors"])

@router.get("/registry")
def registry():
    return {"ok": True, "providers": REG}

@router.post("/activate")
def activate(provider: str = Body(...)):
    reqs = REG.get(provider, {}).get("required", [])
    missing = []
    for k in reqs:
        if not get_secret(provider, k):
            missing.append(k)
    if missing:
        return {"ok": False, "status":"missing_keys", "missing": missing}
    # smoke tests para alguns tipos
    if provider == "nmea_tcp":
        res = nmea_test(get_secret(provider,"host"), get_secret(provider,"port"))
        return {"ok": res.get("ok",False), "status": ("ready" if res.get("ok") else "error"), "detail": res.get("detail")}
    if provider == "mqtt_sensors":
        res = mqtt_test(get_secret(provider,"broker"), get_secret(provider,"port"),
                        get_secret(provider,"username"), get_secret(provider,"password"))
        return {"ok": res.get("ok",False), "status": ("ready" if res.get("ok") else "error"), "detail": res.get("detail")}
    # demais provedores: apenas validação de chaves
    return {"ok": True, "status": "ready"}