import streamlit as st, requests, os

st.set_page_config(page_title="Alertas de Desconexão de Máquinas", page_icon="⚠️", layout="wide")
st.title("⚠️ Alertas – Desconexão de Máquinas (JDLink)")

api = st.text_input("Backend URL", value=os.getenv("TS_BACKEND_URL","http://localhost:8000"))
webhook = st.text_input("Webhook URL (opcional)", value="")
hours = st.number_input("Disparar alerta após (horas sem reportar)", 1, 48, 4)

c1,c2,c3 = st.columns(3)
if c1.button("Salvar Webhook"):
    st.json(requests.post(f"{api}/alerts/webhook/set", json={"url": webhook}).json())
if c2.button("Salvar Threshold"):
    st.json(requests.post(f"{api}/alerts/disconnect/threshold", json={"hours": int(hours)}).json())
if c3.button("Executar verificação agora"):
    st.json(requests.post(f"{api}/alerts/disconnect/check_now").json())

st.info("Dica: o agendador executa a checagem automaticamente a cada ~10 minutos (pode ajustar no backend).")