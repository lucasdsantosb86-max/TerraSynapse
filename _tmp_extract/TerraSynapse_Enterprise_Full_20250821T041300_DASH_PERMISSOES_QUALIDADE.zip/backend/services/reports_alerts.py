from pathlib import Path
import json, datetime as dt, io
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle

BASE = Path(__file__).resolve().parents[2]
LOG  = BASE/"data"/"alerts_log.jsonl"
OUT  = BASE/"data"/"reports"
OUT.mkdir(parents=True, exist_ok=True)

def _parse_ts(ts: str):
    try:
        return dt.datetime.fromisoformat(ts.replace("Z","+00:00"))
    except Exception:
        try:
            return dt.datetime.utcfromtimestamp(int(ts))
        except Exception:
            return None

def _read_logs(start: str=None, end: str=None, limit: int=500):
    rows = []
    if not LOG.exists(): return []
    t0 = _parse_ts(start) if start else None
    t1 = _parse_ts(end) if end else None
    with LOG.open("r", encoding="utf-8") as f:
        for ln in f:
            try:
                j = json.loads(ln)
            except Exception:
                continue
            ts = j.get("ts")
            dt_ts = _parse_ts(ts) if ts else None
            if t0 and dt_ts and dt_ts < t0: continue
            if t1 and dt_ts and dt_ts > t1: continue
            rows.append(j)
    return rows[-limit:]

def build_pdf(start: str=None, end: str=None):
    rows = _read_logs(start, end)
    now = dt.datetime.utcnow().strftime("%Y-%m-%d %H:%M UTC")
    name = f"rel_alertas_{dt.datetime.utcnow().strftime('%Y%m%dT%H%M%S')}.pdf"
    fp = OUT/name

    styles = getSampleStyleSheet()
    story = []
    story.append(Paragraph("<b>TerraSynapse – Relatório de Alertas</b>", styles["Title"]))
    story.append(Paragraph(f"Período: {start or '-'} a {end or '-'}", styles["Normal"]))
    story.append(Paragraph(f"Gerado: {now}", styles["Normal"]))
    story.append(Spacer(1, 12))

    if not rows:
        story.append(Paragraph("Sem eventos no período.", styles["Italic"]))
    else:
        data = [["Data (UTC)", "Tipo", "Detalhe"]]
        for r in rows:
            data.append([r.get("ts",""), r.get("type",""), r.get("detail","")])
        tbl = Table(data, colWidths=[120, 120, 260])
        tbl.setStyle(TableStyle([
            ("BACKGROUND",(0,0),(-1,0), colors.lightgrey),
            ("GRID",(0,0),(-1,-1), 0.25, colors.grey),
            ("FONT",(0,0),(-1,0),"Helvetica-Bold"),
            ("ALIGN",(0,0),(-1,0),"CENTER")
        ]))
        story.append(tbl)

    doc = SimpleDocTemplate(str(fp), pagesize=A4, rightMargin=36,leftMargin=36, topMargin=36,bottomMargin=36)
    doc.build(story)
    return {"ok": True, "path": f"data/reports/{name}"}