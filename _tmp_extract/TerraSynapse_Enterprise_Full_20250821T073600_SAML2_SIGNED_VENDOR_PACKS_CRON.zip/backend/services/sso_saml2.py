from pathlib import Path
import json
from typing import Dict, Any
from onelogin.saml2.settings import OneLogin_Saml2_Settings
from onelogin.saml2.auth import OneLogin_Saml2_Auth

BASE = Path(__file__).resolve().parents[2]
CONF = BASE/"config"/"saml2"/"settings.json"

def _settings_dict():
    try:
        return json.loads(CONF.read_text(encoding="utf-8"))
    except Exception:
        return {}

def set_settings(payload: dict):
    CONF.write_text(json.dumps(payload or {}, indent=2, ensure_ascii=False), encoding="utf-8")
    return {"ok": True}

def metadata_xml() -> str:
    settings = OneLogin_Saml2_Settings(_settings_dict(), raise_exceptions=False)
    return settings.get_sp_metadata()

def login_url() -> str:
    s = _settings_dict()
    return (s.get("idp") or {}).get("singleSignOnService",{}).get("url","")

def acs_http_post(request_data: dict, user_id_hint: str = "") -> Dict[str,Any]:
    # request_data precisa conter: 'http_host','server_port','script_name','get_data','post_data','https'
    auth = OneLogin_Saml2_Auth(request_data, old_settings=_settings_dict())
    auth.process_response()
    errors = auth.get_errors()
    if errors:
        return {"ok": False, "errors": errors, "reason": auth.get_last_error_reason()}
    if not auth.is_authenticated():
        return {"ok": False, "error":"not_authenticated"}
    attrs = auth.get_attributes()
    nameid = auth.get_nameid() or user_id_hint
    email = nameid or ""
    # mapeia papel via role mapper
    role = "visitante"
    try:
        from .roles_mapping import map_role
        info = {"email": email}
        info.update({k: v if isinstance(v, list) else [v] for k,v in attrs.items()})
        role = map_role("saml2", info, email)
    except Exception:
        pass
    return {"ok": True, "email": email, "attributes": attrs, "role_mapped": role}