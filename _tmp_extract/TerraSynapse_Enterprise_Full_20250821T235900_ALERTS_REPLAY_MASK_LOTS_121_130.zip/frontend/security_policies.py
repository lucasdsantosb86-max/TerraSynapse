
from __future__ import annotations
from pathlib import Path
import json, re, hashlib, datetime as dt, hmac, base64, os, secrets, requests

SEC = Path("data/security"); SEC.mkdir(parents=True, exist_ok=True)
POL = SEC/"policies.json"
FAILED = SEC/"failed_logins.json"
FAILED_IP = SEC/"failed_ips.json"
SESS = SEC/"sessions.json"

def load_policy():
    try:
        return json.loads(POL.read_text(encoding="utf-8"))
    except Exception:
        return {"password_policy":{"level":"medium","min_length":8,"groups_required":3,"expire_days":180,"history_depth":3,"max_failed_attempts":5,"lockout_minutes":15},
                "auth":{"require_2fa":False,"captcha_enabled":False,"captcha_provider":"math"},
                "audit_hmac_secret": base64.b64encode(os.urandom(32)).decode("ascii"),
                "audit_hmac_old":[]}

def strong_enough(p: str, min_len: int, groups: int) -> bool:
    g = 0
    g += bool(re.search(r"[a-z]", p))
    g += bool(re.search(r"[A-Z]", p))
    g += bool(re.search(r"[0-9]", p))
    g += bool(re.search(r"[^a-zA-Z0-9]", p))
    return len(p) >= min_len and g >= groups

def hash_pw(p:str) -> str:
    return hashlib.sha256(p.encode("utf-8")).hexdigest()

def check_history(user_record: dict, new_hash: str, depth: int) -> bool:
    hist = user_record.get("pwd_history", [])
    return new_hash not in hist[-depth:] if depth>0 else True

def push_history(user_record: dict, new_hash: str):
    hist = user_record.get("pwd_history", [])
    hist.append(new_hash)
    user_record["pwd_history"] = hist[-10:]

# Backup codes
def generate_backup_codes(n:int=10):
    return [secrets.token_hex(4) for _ in range(n)]  # 8 hex chars

def get_backup_hash(code:str)->str:
    return hashlib.sha256(("BC:"+code).encode("utf-8")).hexdigest()

def consume_backup_code(user_record: dict, code: str) -> bool:
    arr = user_record.get("backup_codes", [])
    h = get_backup_hash(code)
    for item in arr:
        if not item.get("used") and item.get("hash") == h:
            item["used"] = True
            return True
    return False

# CAPTCHA
def gen_captcha():
    a, b = secrets.randbelow(9)+1, secrets.randbelow(9)+1
    return {"question": f"{a} + {b} = ?", "answer": str(a+b)}

def verify_recaptcha(token: str) -> bool:
    p = load_policy().get("auth",{})
    secret = p.get("recaptcha_secret")
    if not secret: return False
    try:
        resp = requests.post("https://www.google.com/recaptcha/api/siteverify", data={"secret": secret, "response": token}, timeout=5)
        j = resp.json()
        return bool(j.get("success"))
    except Exception:
        return False

# IP helpers
def client_ip() -> str:
    return os.environ.get("HTTP_X_FORWARDED_FOR") or os.environ.get("REMOTE_ADDR") or "unknown"

def add_failed(username: str, ip: str|None=None):
    pol = load_policy()["password_policy"]
    # por usuário
    data = {}
    if FAILED.exists():
        try: data = json.loads(FAILED.read_text(encoding="utf-8"))
        except Exception: data = {}
    rec = data.get(username, {"fails":0,"until":None})
    rec["fails"] = rec.get("fails",0) + 1
    if rec["fails"] >= pol.get("max_failed_attempts",5):
        until = dt.datetime.utcnow() + dt.timedelta(minutes=pol.get("lockout_minutes",15))
        rec["until"] = until.isoformat()+"Z"
    data[username] = rec
    FAILED.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    # por IP
    if ip:
        ipd = {}
        if FAILED_IP.exists():
            try: ipd = json.loads(FAILED_IP.read_text(encoding="utf-8"))
            except Exception: ipd = {}
        r = ipd.get(ip, {"fails":0,"until":None})
        r["fails"] = r.get("fails",0) + 1
        if r["fails"] >= pol.get("max_failed_attempts",5):
            until = dt.datetime.utcnow() + dt.timedelta(minutes=pol.get("lockout_minutes",15))
            r["until"] = until.isoformat()+"Z"
        ipd[ip] = r
        FAILED_IP.write_text(json.dumps(ipd, indent=2, ensure_ascii=False), encoding="utf-8")

def clear_failed(username: str, ip: str|None=None):
    if FAILED.exists():
        try:
            data = json.loads(FAILED.read_text(encoding="utf-8"))
            if username in data: data.pop(username)
            FAILED.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
        except Exception:
            pass
    if ip and FAILED_IP.exists():
        try:
            ipd = json.loads(FAILED_IP.read_text(encoding="utf-8"))
            if ip in ipd: ipd.pop(ip)
            FAILED_IP.write_text(json.dumps(ipd, indent=2, ensure_ascii=False), encoding="utf-8")
        except Exception:
            pass

def locked(username: str, ip: str|None=None) -> bool:
    try:
        if FAILED.exists():
            data = json.loads(FAILED.read_text(encoding="utf-8"))
            rec = data.get(username)
            if rec and rec.get("until"):
                u = dt.datetime.fromisoformat(rec["until"].replace("Z",""))
                if dt.datetime.utcnow() < u: return True
        if ip and FAILED_IP.exists():
            ipd = json.loads(FAILED_IP.read_text(encoding="utf-8"))
            r = ipd.get(ip)
            if r and r.get("until"):
                u = dt.datetime.fromisoformat(r["until"].replace("Z",""))
                if dt.datetime.utcnow() < u: return True
        return False
    except Exception:
        return False

# Sessões
def add_session(username: str, ip: str):
    sess = {}
    if SESS.exists():
        try: sess = json.loads(SESS.read_text(encoding="utf-8"))
        except Exception: sess = {}
    sess[username] = {"last_login": dt.datetime.utcnow().isoformat()+"Z", "ip": ip}
    SESS.write_text(json.dumps(sess, indent=2, ensure_ascii=False), encoding="utf-8")

def sessions():
    if not SESS.exists(): return {}
    try: return json.loads(SESS.read_text(encoding="utf-8"))
    except Exception: return {}

# 2FA TOTP
def verify_totp(user_record: dict, code: str) -> bool:
    try:
        import pyotp
        secret = user_record.get("totp_secret")
        if not secret: return False
        totp = pyotp.TOTP(secret)
        return totp.verify(code, valid_window=1)
    except Exception:
        return False

def ensure_totp_secret(user_record: dict) -> str:
    if user_record.get("totp_secret"): return user_record["totp_secret"]
    try:
        import pyotp
        secret = pyotp.random_base32()
    except Exception:
        secret = base64.b32encode(os.urandom(20)).decode("ascii").replace("=", "")
    user_record["totp_secret"] = secret
    return secret

# HMAC – assinatura e rotação
def hmac_sign(msg: str) -> str:
    pol = load_policy()
    key = base64.b64decode(pol.get("audit_hmac_secret",""))
    return hmac.new(key, msg.encode("utf-8"), digestmod="sha256").hexdigest()

def rotate_hmac_secret():
    pol = load_policy()
    old = pol.get("audit_hmac_secret")
    olds = pol.get("audit_hmac_old", [])
    if old: olds.append(old)
    pol["audit_hmac_old"] = olds[-5:]
    pol["audit_hmac_secret"] = base64.b64encode(os.urandom(32)).decode("ascii")
    POL.write_text(json.dumps(pol, indent=2, ensure_ascii=False), encoding="utf-8")
    return True
