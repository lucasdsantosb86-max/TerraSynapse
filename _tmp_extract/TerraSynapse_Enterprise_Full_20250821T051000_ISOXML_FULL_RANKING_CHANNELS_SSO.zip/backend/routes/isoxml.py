from fastapi import APIRouter, Body, Query
from typing import List, Dict, Any
from ..services.isoxml_profiles import load_profiles, validate_zones, export_zip, make_taskdata_xml, validate_xml

router = APIRouter(prefix="/isoxml", tags=["isoxml"])

@router.get("/profiles")
def profiles():
    return {"ok": True, "profiles": load_profiles()}

@router.post("/export")
def export(profile: str = Body(...), job_name: str = Body(...), culture: str = Body(...), zones: List[dict] = Body(...)):
    errs = validate_zones(zones)
    if errs:
        return {"ok": False, "errors": errs}
    path = export_zip(profile, job_name, culture, zones)
    return {"ok": True, "zip": path}

@router.post("/validate")
def validate(xml_text: str = Body(...)):
    return validate_xml(xml_text)