from __future__ import annotations
import streamlit as st, json, hashlib
from pathlib import Path
from typing import Dict, Any
from frontend.auth import require

st.set_page_config(page_title="Admin – Usuários", page_icon="👥", layout="wide")
user = require(roles=("developer","gestor"))

USERS_PATH = Path("data/users/users.json")
ROLES_PATH = Path("data/users/roles.json")

def load_users() -> Dict[str, Any]:
    try:
        return json.loads(USERS_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {"users": []}

def save_users(data: Dict[str, Any]):
    USERS_PATH.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")

def load_roles() -> Dict[str, Any]:
    try:
        return json.loads(ROLES_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}

def sha256(p: str) -> str:
    return hashlib.sha256(p.encode("utf-8")).hexdigest()

st.title("👥 Administração de Usuários")

colL, colR = st.columns([1,2])

with colL:
    st.subheader("➕ Criar novo usuário")
    new_user = st.text_input("Usuário (login)")
    new_display = st.text_input("Nome de exibição")
    new_email = st.text_input("E-mail")
    roles = load_roles()
    new_role = st.selectbox("Papel", options=list(roles.keys()), index=list(roles.keys()).index("gestor") if "gestor" in roles else 0)
    new_pass = st.text_input("Senha inicial", type="password")
    if st.button("Criar usuário"):
        if not (new_user and new_pass):
            st.error("Preencha usuário e senha.")
        else:
            data = load_users()
            if any(u.get("username")==new_user for u in data.get("users",[])):
                st.warning("Usuário já existe.")
            else:
                data.setdefault("users", []).append({
                    "username": new_user,
                    "password_hash": sha256(new_pass),
                    "role": new_role,
                    "display_name": new_display or new_user,
                    "email": new_email or ""
                })
                save_users(data)
                st.success(f"Usuário '{new_user}' criado.")

with colR:
    st.subheader("🗂️ Usuários existentes")
    data = load_users()
    if not data.get("users"):
        st.info("Nenhum usuário cadastrado.")
    else:
        for u in data["users"]:
            with st.expander(f"{u.get('username')}  —  {u.get('display_name','')}  ({u.get('role')})"):
                c1, c2, c3 = st.columns(3)
                with c1:
                    disp = st.text_input("Nome exibição", u.get("display_name",""), key=f"disp_{u['username']}")
                    mail = st.text_input("E-mail", u.get("email",""), key=f"mail_{u['username']}")
                with c2:
                    roles = load_roles()
                    role = st.selectbox("Papel", options=list(roles.keys()), index=list(roles.keys()).index(u.get("role","visitante")), key=f"role_{u['username']}")
                    newp = st.text_input("Nova senha (opcional)", type="password", key=f"pwd_{u['username']}")
                with c3:
                    st.write(" ")
                    if st.button("Salvar alterações", key=f"save_{u['username']}"):
                        d = load_users()
                        for uu in d["users"]:
                            if uu["username"] == u["username"]:
                                uu["display_name"] = disp
                                uu["email"] = mail
                                uu["role"] = role
                                if newp:
                                    uu["password_hash"] = sha256(newp)
                        save_users(d)
                        st.success("Alterações salvas.")
                    danger = st.checkbox("Confirmar exclusão", key=f"chk_{u['username']}")
                    if st.button("Excluir usuário", key=f"del_{u['username']}"):
                        if not danger:
                            st.error("Marque a confirmação para excluir.")
                        elif u["username"] in ("dev_terrasynapse",):
                            st.error("Por segurança, não é permitido excluir o usuário principal de desenvolvimento.")
                        else:
                            d = load_users()
                            d["users"] = [uu for uu in d["users"] if uu["username"] != u["username"]]
                            save_users(d)
                            st.success("Usuário excluído. Atualize a página.")
