from pathlib import Path
import json, statistics as stats

BASE = Path(__file__).resolve().parents[2]
ING  = BASE/"data"/"ingest"/"dairy"
ING.mkdir(parents=True, exist_ok=True)

def _last(provider: str, limit=10):
    p = ING/provider
    rows = []
    if p.exists():
        for fp in sorted(p.glob("*.json"))[-limit:]:
            try:
                rows.append(json.loads(fp.read_text(encoding="utf-8")))
            except: pass
    return rows

def summarize(client_id: str=None):
    # Le leitura de ruminação (min/d), passos, produção (L), CCS, etc. dos providers
    af  = _last("afimilk")
    cm  = _last("cowmanager")
    dlv = _last("delaval")
    out = {}
    # métricas simplificadas
    def safe_avg(arr): 
        return (sum(arr)/len(arr)) if arr else None
    # produção de leite por vaca
    milk = [r.get("milk_l") for r in af if "milk_l" in r] + [r.get("milk_l") for r in dlv if "milk_l" in r]
    rum  = [r.get("rumination_min") for r in af if "rumination_min" in r] + [r.get("rumination_min") for r in cm if "rumination_min" in r]
    heat = [r.get("heat_index") for r in cm if "heat_index" in r]
    ccs  = [r.get("ccs") for r in dlv if "ccs" in r]
    out["milk_avg_l"] = safe_avg([x for x in milk if isinstance(x,(int,float))])
    out["rumination_avg_min"] = safe_avg([x for x in rum if isinstance(x,(int,float))])
    out["heat_index_avg"] = safe_avg([x for x in heat if isinstance(x,(int,float))])
    out["ccs_avg"] = safe_avg([x for x in ccs if isinstance(x,(int,float))])
    # riscos simples
    risk = []
    if out["rumination_avg_min"] is not None and out["rumination_avg_min"] < 400: risk.append("baixa_ruminacao")
    if out["ccs_avg"] is not None and out["ccs_avg"] > 400000: risk.append("mastite_ccs_alta")
    out["risks"] = risk
    return {"ok": True, "kpis": out}