import streamlit as st, pandas as pd, requests
from pathlib import Path

st.set_page_config(page_title="Gestor – Semáforo Financeiro", page_icon="💡")
st.title("💡 Gestor – Semáforo Financeiro Mensal")

backend = st.text_input("Backend URL", value="http://localhost:8000")
tal_fp = st.text_input("CSV de talhões (custo_R$_ha por mês)", value=str(Path(__file__).resolve().parents[1]/"data"/"reports"/"talhoes_estimados.csv"))
periodo = st.text_input("Período (YYYY-MM)", value="2025-08")

limiares = {"soja":6000,"milho":5000,"trigo":4500,"citros":20000,"cana":12000}
st.write("Limiar padrão por cultura:", limiares)

if st.button("Gerar PDF Gerencial"):
    try:
        r = requests.post(f"{backend}/reports/financeiro/pdf", json={"periodo": periodo, "talhoes_csv": tal_fp, "limiares": limiares}, timeout=60).json()
        st.success(r)
        if r.get("file"):
            st.info(f"Gerado em: {r['file']} (no servidor)")
    except Exception as e:
        st.error(e)