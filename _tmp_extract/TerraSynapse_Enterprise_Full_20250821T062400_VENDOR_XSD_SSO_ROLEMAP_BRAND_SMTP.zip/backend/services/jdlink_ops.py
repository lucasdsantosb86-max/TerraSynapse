from pathlib import Path
import json, time, random
from .secrets import get_secret_user
from .jdlink_client import save_mock
from .user_roles import get_role, allowed_for_sync
from .jdlink_agg import aggregate

BASE = Path(__file__).resolve().parents[2]
CFG  = BASE/"config"/"jdlink_sync.json"
OPS  = BASE/"data"/"ingest"/"jdlink"/"operations"
OPS.mkdir(parents=True, exist_ok=True)

def _load_cfg():
    if CFG.exists():
        try:
            return json.loads(CFG.read_text(encoding="utf-8"))
        except: return {}
    return {}

def _save_cfg(cfg):
    CFG.write_text(json.dumps(cfg, indent=2), encoding="utf-8")

def set_sync(user_id: str, enabled: bool, interval_min: int = 60):
    cfg = _load_cfg()
    cfg[user_id] = {"enabled": bool(enabled), "interval_min": int(interval_min), "updated_ts": int(time.time())}
    _save_cfg(cfg)
    return {"ok": True, "user_id": user_id, "sync": cfg[user_id]}

def get_sync_status(user_id: str):
    cfg = _load_cfg()
    st = cfg.get(user_id, {"enabled": False, "interval_min": 60, "updated_ts": None})
    has_token = bool(get_secret_user(user_id, "jdlink", "access_token"))
    return {"ok": True, "user_id": user_id, "has_token": has_token, "sync": st}

def _fake_ops(user_id: str, n=3):
    ops = []
    now = int(time.time())
    for i in range(n):
        op = {
            "op_id": f"OP{now-i}",
            "user_id": user_id,
            "machine_id": f"JD-{random.randint(1000,9999)}",
            "start_ts": now - random.randint(3600, 7200),
            "end_ts": now - random.randint(0, 1800),
            "area_ha": round(random.uniform(3.0, 18.0), 2),
            "fuel_l": round(random.uniform(4.0, 25.0), 1),
            "task": random.choice(["plantio","pulverizacao","colheita"]),
        }
        ops.append(op)
    return ops

def fetch_now(user_id: str):
    role = get_role(user_id)
    if not allowed_for_sync(role):
        return {"ok": False, "error": "forbidden_role", "role": role}
    # Em produção: chamar JDLink com access_token do usuário e armazenar resposta
    tok = get_secret_user(user_id, "jdlink", "access_token")
    if not tok:
        return {"ok": False, "error": "no_token_for_user"}
    ops = _fake_ops(user_id, n=5)
    fn = OPS/f"{int(time.time())}_{user_id}.json"
    fn.write_text(json.dumps({"user_id": user_id, "items": ops}, ensure_ascii=False), encoding="utf-8")
    # também guarda um resumo em /data/ingest/jdlink para visualização geral
    save_mock("operations_index", {"user_id": user_id, "count": len(ops), "ts": int(time.time())})
    agg = aggregate()
    return {"ok": True, "stored": str(fn.relative_to(BASE)), "count": len(ops), "aggregate": agg}

def list_recent(limit=10):
    rows = []
    for fp in sorted(OPS.glob("*.json"))[-limit:]:
        try:
            rows.append(json.loads(fp.read_text(encoding="utf-8")))
        except: pass
    return {"ok": True, "items": rows}