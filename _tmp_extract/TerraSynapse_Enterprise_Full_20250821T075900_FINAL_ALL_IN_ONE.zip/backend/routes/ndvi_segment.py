from fastapi import APIRouter, UploadFile, File, Form
import json
from ..services.ndvi_zoning import segment_ndvi

router = APIRouter(prefix="/ndvi", tags=["ndvi"])

@router.post("/segment")
async def segment(ndvi_file: UploadFile = File(...),
                  thresholds: str = Form("[0.33,0.66]"),
                  yield_map: str = Form("{"low":0.9,"mid":1.0,"high":1.1}"),
                  area_ha: float = Form(50.0)):
    content = await ndvi_file.read()
    th = json.loads(thresholds)
    ym = json.loads(yield_map)
    return segment_ndvi(content, thresholds=tuple(th), yield_map=ym, area_ha=area_ha)