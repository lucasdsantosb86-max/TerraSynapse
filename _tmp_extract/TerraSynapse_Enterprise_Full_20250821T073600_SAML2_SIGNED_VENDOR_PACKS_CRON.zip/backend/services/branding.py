from pathlib import Path
import json

BASE = Path(__file__).resolve().parents[2]
CONF = BASE/"config"/"branding.json"

def resolve_brand(email: str):
    try:
        cfg = json.loads(CONF.read_text(encoding="utf-8"))
    except Exception:
        return {"brand":"TerraSynapse","logo_path":"", "colors":{"primary":"#2E7D32"}}
    dom = (email.split("@")[1] if "@" in email else "").lower()
    b = (cfg.get("by_domain") or {}).get(dom) or cfg.get("default")
    return b or {"brand":"TerraSynapse","logo_path":"", "colors":{"primary":"#2E7D32"}}