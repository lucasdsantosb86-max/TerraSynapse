import json, time
from datetime import datetime
from apscheduler.schedulers.background import BackgroundScheduler
from pathlib import Path
import pandas as pd

from .webhooks import send_event
from .costs_fetchers import sync_source

BASE = Path(__file__).resolve().parents[2]
CONF = BASE/"config"/"scheduler.json"
LOG  = BASE/"data"/"scheduler"
LOG.mkdir(parents=True, exist_ok=True)
STATE = LOG/"state.json"

_scheduler = None

def _load_conf():
    return json.loads(CONF.read_text(encoding="utf-8"))

def _save_state(obj):
    STATE.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")

def _load_state():
    if STATE.exists():
        return json.loads(STATE.read_text(encoding="utf-8"))
    return {"last_run": None, "last_changes": []}

def _pct_change(old: float, new: float):
    if old is None or old==0: return None
    return 100.0*(new-old)/old

def run_sync_once():
    cfg = _load_conf()
    state = _load_state()
    changes = []
    for rec in cfg.get("sources", []):
        res = sync_source(rec)
        if not res.get("ok"):
            changes.append({"source": rec.get("name"), "error": res})
            continue
        # carrega csv normalizado e calcula variação sobre último valor por (culture,item) ou (state,microregion,culture,input)
        norm = Path(res.get("normalized"))
        try:
            df = pd.read_csv(norm)
        except Exception as e:
            changes.append({"source": rec.get("name"), "error": str(e)})
            continue
        if "avg_price_BRL" in df.columns:
            # local
            key_cols = ["state","microregion","culture","input"]
            val_col = "price_BRL"
        else:
            # global
            key_cols = ["country","culture","item"]
            val_col = "price_BRL"
        if df.empty or val_col not in df.columns:
            continue
        latest = df.sort_values("date").groupby(key_cols).tail(1)
        for _, row in latest.iterrows():
            key = "|".join(str(row.get(k)) for k in key_cols)
            new_val = float(row.get(val_col, 0))
            # procura no histórico
            hist_path = LOG/f"{rec.get('name')}_history.csv"
            prev = None
            if hist_path.exists():
                try:
                    h = pd.read_csv(hist_path)
                    sel = h[h["key"]==key]
                    if not sel.empty:
                        prev = float(sel.sort_values("date").iloc[-1]["value"])
                except Exception:
                    pass
            # append no histórico
            with hist_path.open("a", encoding="utf-8") as f:
                f.write(f"{row.get('date')},{key},{new_val}\n")
            delta = _pct_change(prev, new_val)
            if delta is not None:
                changes.append({"source": rec.get("name"), "key": key, "prev": prev, "new": new_val, "delta_pct": delta})
    state["last_run"] = datetime.utcnow().isoformat()+"Z"
    state["last_changes"] = changes
    _save_state(state)

    # alerta se variar acima de X%
    limit = float(cfg.get("cost_change_alert_pct", 8))
    fired = []
    for c in changes:
        d = c.get("delta_pct")
        if d is not None and abs(d) >= limit:
            ev = {"type":"cost_change","source":c["source"],"key":c["key"],"delta_pct":round(d,2),"prev":c["prev"],"new":c["new"]}
            send_event(ev)
            fired.append(ev)
    return {"ok": True, "changes": changes, "alerts": fired}

def _schedule_job():
    cfg = _load_conf()
    hour = int(cfg.get("daily_hour", 6))
    sched = BackgroundScheduler(timezone="UTC")
    sched.add_job(run_sync_once, "cron", hour=hour, id="daily_sync")
    sched.start()
    return sched

def start():
    global _scheduler
    if _scheduler: return {"ok": True, "status":"already_running"}
    _scheduler = _schedule_job()
    return {"ok": True, "status":"started"}

def stop():
    global _scheduler
    if not _scheduler: return {"ok": True, "status":"not_running"}
    _scheduler.shutdown(wait=False)
    _scheduler = None
    return {"ok": True, "status":"stopped"}

def status():
    st = _load_state()
    return {"ok": True, "running": _scheduler is not None, **st}