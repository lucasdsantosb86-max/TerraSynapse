import os, time, json
from typing import Optional
import requests

CACHE = {}

class WeatherProvider:
    def __init__(self, provider: str = "openweather"):
        self.provider = provider.lower()
        self.ow_key = os.getenv("OPENWEATHER_API_KEY","")
        self.ct_key = os.getenv("CLIMATEMPO_API_KEY","")

    def _cache_get(self, key):
        v = CACHE.get(key)
        if v and time.time()-v["t"]<900:  # 15 min
            return v["data"]
        return None

    def _cache_set(self, key, data):
        CACHE[key] = {"t": time.time(), "data": data}

    def forecast(self, lat: float, lon: float):
        key = f"{self.provider}:{lat:.3f},{lon:.3f}"
        c = self._cache_get(key)
        if c: return c

        if self.provider=="climatempo" and self.ct_key:
            # Documentado para substituição com endpoint real do ClimaTempo
            # Exemplo ilustrativo (o usuário deve configurar a URL oficial):
            url = f"https://api.climatempo.com.br/forecast?lat={lat}&lon={lon}&token={self.ct_key}"
            try:
                r = requests.get(url, timeout=10); r.raise_for_status()
                data = r.json()
            except Exception as e:
                data = {"error": str(e)}
        else:
            # OpenWeather (OneCall-like)
            if not self.ow_key:
                return {"error":"OPENWEATHER_API_KEY ausente"}
            url = f"https://api.openweathermap.org/data/2.5/forecast?lat={lat}&lon={lon}&appid={self.ow_key}&units=metric&lang=pt_br"
            try:
                r = requests.get(url, timeout=10); r.raise_for_status()
                data = r.json()
            except Exception as e:
                data = {"error": str(e)}

        self._cache_set(key, data)
        return data