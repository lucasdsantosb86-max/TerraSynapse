import json, os, secrets, string, time
from pathlib import Path
from argon2 import PasswordHasher

BASE = Path(__file__).resolve().parents[2]
STORE = BASE/"data"/"users"
STORE.mkdir(parents=True, exist_ok=True)
REC_PATH = STORE/"2fa_recovery.json"
_ph = PasswordHasher(time_cost=3, memory_cost=65536, parallelism=2)

def _load():
    if REC_PATH.exists():
        return json.loads(REC_PATH.read_text(encoding="utf-8"))
    return {}

def _save(obj):
    REC_PATH.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")

def generate_recovery_codes(user: str, n:int=10):
    db = _load(); recs = []
    for _ in range(n):
        code = "".join(secrets.choice(string.ascii_uppercase+string.digits) for _ in range(10))
        recs.append(code)
    hashed = [_ph.hash(c) for c in recs]
    db[user] = {"hashes": hashed, "created_at": int(time.time())}
    _save(db)
    return {"ok": True, "codes": recs}

def use_recovery_code(user: str, code: str):
    db = _load(); rec = db.get(user)
    if not rec: return {"ok": False, "detail":"no codes"}
    hashes = rec.get("hashes", [])
    for i, h in enumerate(hashes):
        try:
            if _ph.verify(h, code):
                hashes.pop(i)
                db[user]["hashes"] = hashes
                _save(db)
                return {"ok": True}
        except Exception:
            pass
    return {"ok": False, "detail":"invalid"}