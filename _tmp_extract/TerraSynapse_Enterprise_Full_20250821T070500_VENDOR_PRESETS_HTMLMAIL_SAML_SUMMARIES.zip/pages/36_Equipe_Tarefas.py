import streamlit as st, requests, os, time, json

st.set_page_config(page_title="Equipe & Tarefas", page_icon="🧑‍🔧", layout="wide")
st.title("🧑‍🔧 Equipe & Tarefas")

api = st.text_input("Backend URL", value=os.getenv("TS_BACKEND_URL","http://localhost:8000"))

col = st.columns(2)
with col[0]:
    st.subheader("Equipe")
    with st.form("new_member"):
        name = st.text_input("Nome")
        role = st.selectbox("Perfil", ["gestor","engenheiro_agronomo","zootecnista","veterinario","tecnico_agro","programador","operador_campo"])
        email = st.text_input("E-mail")
        phone = st.text_input("Telefone/WhatsApp")
        cert = st.text_input("Documento profissional (CREA/CRMV/...)")
        ok = st.form_submit_button("Adicionar")
        if ok:
            obj = {"name": name, "role": role, "email": email, "phone": phone, "cert": cert}
            st.json(requests.post(f"{api}/crm/team", json=obj).json())

    if st.button("Atualizar equipe"):
        st.session_state.team = requests.get(f"{api}/crm/team").json().get("items",[])
    team = st.session_state.get("team", [])
    for m in team:
        st.markdown(f"**{m.get('name')}** — {m.get('role')}  |  📧 [{m.get('email')}](mailto:{m.get('email')})  |  💬 [WhatsApp](https://wa.me/{m.get('phone','').replace('+','')})")

with col[1]:
    st.subheader("Tarefas")
    clients = requests.get(f"{api}/crm/clients").json().get("items",[])
    team = requests.get(f"{api}/crm/team").json().get("items",[])
    cl_map = {c["name"]: c["id"] for c in clients} if clients else {}
    tm_map = {t["name"]: t["id"] for t in team} if team else {}
    with st.form("new_task"):
        title = st.text_input("Título")
        desc  = st.text_area("Descrição")
        client_name = st.selectbox("Cliente", list(cl_map.keys()) or ["(cadastre clientes)"])
        assignee_name = st.selectbox("Atribuir a", list(tm_map.keys()) or ["(cadastre equipe)"])
        priority = st.selectbox("Prioridade", ["baixa","média","alta"])
        status = st.selectbox("Status", ["novo","em_andamento","bloqueado","concluída"])
        due = st.date_input("Vencimento (até 24h alerta automático)")
        ok = st.form_submit_button("Criar tarefa")
        if ok:
            import datetime as dt
            due_ts = int(dt.datetime.combine(due, dt.time(23,59)).timestamp())
            obj = {"title": title, "description": desc, "client_id": cl_map.get(client_name), "assignee_id": tm_map.get(assignee_name), "priority": priority, "status": status, "due_ts": due_ts}
            st.json(requests.post(f"{api}/crm/tasks", json=obj).json())

    st.markdown("---")
    if st.button("Atualizar tarefas"):
        st.session_state.tasks = requests.get(f"{api}/crm/tasks").json().get("items",[])
    tasks = st.session_state.get("tasks", [])
    for t in tasks:
        with st.expander(f"[{t.get('priority')}] {t.get('title')} — status: {t.get('status')}"):
            st.write(t)
            if st.button(f"Marcar concluída {t.get('id')}"):
                st.json(requests.put(f"{api}/crm/tasks/{t['id']}", json={"status":"concluída"}).json())
            if st.button(f"Excluir {t.get('id')}"):
                st.json(requests.delete(f"{api}/crm/tasks/{t['id']}").json())