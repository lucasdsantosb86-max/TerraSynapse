from fastapi import APIRouter
from ..services import scheduler as sch

router = APIRouter(prefix="/admin/scheduler", tags=["admin"])

@router.post("/start")
def start(): return sch.start()

@router.post("/stop")
def stop(): return sch.stop()

@router.get("/status")
def status(): return sch.status()

@router.post("/run_once")
def run_once(): return sch.run_sync_once()