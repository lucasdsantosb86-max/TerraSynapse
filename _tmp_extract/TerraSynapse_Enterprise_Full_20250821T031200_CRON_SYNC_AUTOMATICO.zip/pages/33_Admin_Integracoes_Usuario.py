import streamlit as st, requests, os, json

st.set_page_config(page_title="Admin – Integrações por Usuário", page_icon="👤", layout="wide")
st.title("👤 Integrações por Usuário – Auto‑connect + Chaves")

api = st.text_input("Backend URL", value=os.getenv("TS_BACKEND_URL","http://localhost:8000"))
user_id = st.text_input("User ID (e-mail ou ID interno)", "lucas@empresa.com")

col = st.columns(3)
if col[0].button("Ver configurações"):
    st.json(requests.get(f"{api}/users/integrations/settings", params={"user_id": user_id}).json())

ac = st.checkbox("Auto‑connect ao salvar chaves", value=True)
if col[1].button("Salvar Auto‑connect"):
    st.json(requests.post(f"{api}/users/integrations/auto-connect", json={"user_id": user_id, "enabled": ac}).json())

st.markdown("---")
st.subheader("Salvar chave (por usuário) + testar automaticamente")
prov = st.selectbox("Provedor", ["climatempo","openweather","jdlink","sentinelhub","dji","dronedeploy","pix4d","nmea_tcp","mqtt_sensors","modbus_tcp"])
key = st.text_input("Campo (ex.: token, api_key, client_id, host, port, ...)", "token")
val = st.text_input("Valor", type="password")

if st.button("Salvar & Auto‑conectar"):
    j = requests.post(f"{api}/secrets/user/set_autoconnect", json={"user_id": user_id, "provider": prov, "key": key, "value": val}).json()
    st.json(j)

st.markdown("---")
st.subheader("Testar conexão agora")
if st.button("Testar provider"):
    st.json(requests.post(f"{api}/connectors/test", json={"provider": prov, "user_id": user_id}).json())