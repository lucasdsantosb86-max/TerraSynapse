from fastapi import APIRouter, Body, Query
from ..services.crm_clients import list_clients, get_client, create_client, update_client, delete_client

router = APIRouter(prefix="/crm/clients", tags=["crm-clients"])

@router.get("")
def all():
    return {"ok": True, "items": list_clients()}

@router.get("/{cid}")
def one(cid: str):
    c = get_client(cid)
    return {"ok": bool(c), "item": c}

@router.post("")
def create(obj: dict = Body(...)):
    return {"ok": True, "item": create_client(obj)}

@router.put("/{cid}")
def upd(cid: str, patch: dict = Body(...)):
    return {"ok": True, "item": update_client(cid, patch)}

@router.delete("/{cid}")
def rem(cid: str):
    return {"ok": True, **delete_client(cid)}