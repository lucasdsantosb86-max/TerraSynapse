from fastapi import APIRouter, Body, Query
from ..services.sso_oidc import list_providers, set_providers, start, callback

router = APIRouter(prefix="/sso/oidc", tags=["sso-oidc"])

@router.get("/providers")
def providers():
    return list_providers()

@router.post("/providers/set")
def providers_set(payload: dict = Body(...)):
    return set_providers(payload)

@router.get("/start")
def start_auth(provider: str = Query(...), user_id: str = Query(...)):
    return start(provider, user_id)

@router.get("/callback")
def cb(code: str = Query(...), state: str = Query(...)):
    return callback(code, state)