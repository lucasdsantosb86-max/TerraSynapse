import streamlit as st, json, pathlib, requests, os
st.set_page_config(page_title="Admin – ClimaTempo", page_icon="🌦️", layout="centered")
st.title("🌦️ Admin – Integração ClimaTempo")

p = pathlib.Path("config/weather.json")
cfg = json.loads(p.read_text(encoding="utf-8"))
token = st.text_input("Token ClimaTempo (cole aqui)", value=cfg.get("climatempo",{}).get("token",""), type="password")

if st.button("Salvar token"):
    cfg["climatempo"]["token"] = token
    p.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
    st.success("Token salvo.")

st.markdown("---")
st.subheader("Teste rápido")
api = st.text_input("Backend URL", value=os.getenv("TS_BACKEND_URL","http://localhost:8000"))
lat = st.number_input("Latitude", value=-15.78, format="%.6f")
lon = st.number_input("Longitude", value=-47.929, format="%.6f")

if st.button("Testar previsão (7 dias)"):
    try:
        r = requests.get(f"{api}/weather/climatempo/forecast", params={"lat":lat,"lon":lon}, timeout=30)
        st.json(r.json())
    except Exception as e:
        st.error(str(e))