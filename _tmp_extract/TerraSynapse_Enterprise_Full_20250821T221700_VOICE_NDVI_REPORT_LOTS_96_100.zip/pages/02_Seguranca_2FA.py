
from __future__ import annotations
import streamlit as st, json, io
from pathlib import Path
from frontend.auth import require
from frontend.security_policies import ensure_totp_secret, load_policy
import qrcode

st.set_page_config(page_title="Segurança – 2FA", page_icon="🧩", layout="centered")
user = require(roles=("developer","gestor","tecnico","visitante"))

USERS_PATH = Path("data/users/users.json")

def load_users():
    try:
        return json.loads(USERS_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {"users":[]}

def save_users(d):
    USERS_PATH.write_text(json.dumps(d, indent=2, ensure_ascii=False), encoding="utf-8")

st.title("🧩 Autenticação de Dois Fatores (2FA)")

d = load_users()
rec = None
for u in d["users"]:
    if u["username"] == user["username"]:
        rec = u; break
if rec is None:
    st.error("Usuário não encontrado."); st.stop()

pol = load_policy()
st.write(f"Política: 2FA {'obrigatório' if pol.get('auth',{}).get('require_2fa') else 'opcional'}")

if st.button("Gerar/mostrar segredo"):
    secret = ensure_totp_secret(rec)
    save_users(d)
    # URL otpauth
    issuer = "TerraSynapse IA"
    label = f"{issuer}:{rec['username']}"
    url = f"otpauth://totp/{label}?secret={secret}&issuer={issuer}"
    img = qrcode.make(url)
    buf = io.BytesIO(); img.save(buf, format="PNG")
    st.image(buf.getvalue(), caption="Escaneie no Google Authenticator / Authy")
    st.code(secret, language="text")
    st.caption("Depois de cadastrar o código no app autenticador, digite um código abaixo para validar.")

code = st.text_input("Código 2FA (6 dígitos)", max_chars=6)
if st.button("Validar 2FA"):
    import pyotp
    secret = rec.get("totp_secret")
    if not secret:
        st.error("Gere o segredo primeiro.")
    else:
        ok = pyotp.TOTP(secret).verify(code.strip(), valid_window=1)
        if ok:
            st.success("2FA validado com sucesso!")
        else:
            st.error("Código inválido. Tente novamente.")
