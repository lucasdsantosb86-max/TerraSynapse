import paho.mqtt.client as mqtt

def test_connect(broker: str, port: int, username: str=None, password: str=None, timeout=5):
    cli = mqtt.Client()
    if username: cli.username_pw_set(username, password)
    try:
        cli.connect(broker, int(port), timeout)
        cli.disconnect()
        return {"ok": True, "detail":"conexao_ok"}
    except Exception as e:
        return {"ok": False, "detail": str(e)}