from fastapi import APIRouter, Query
from ..services.weather import current_weather

router = APIRouter(prefix="/weather", tags=["weather"])

@router.get("/now")
def now(lat: float = Query(None), lon: float = Query(None)):
    return current_weather(lat, lon)