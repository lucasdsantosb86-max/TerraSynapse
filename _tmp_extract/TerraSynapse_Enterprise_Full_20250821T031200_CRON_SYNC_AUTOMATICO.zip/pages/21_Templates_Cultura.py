import streamlit as st, requests, os, json

st.set_page_config(page_title="Templates por Cultura (VRA)", page_icon="🧩", layout="wide")
st.title("🧩 Templates por Cultura → NDVI → VRA")

api = st.text_input("Backend URL", value=os.getenv("TS_BACKEND_URL","http://localhost:8000"))

cults = requests.get(f"{api}/templates/cultures").json().get("items", [])
culture = st.selectbox("Cultura", cults or ["soja"])
apps = requests.get(f"{api}/templates/apps", params={"culture": culture}).json().get("items", [])
application = st.selectbox("Aplicação", apps or ["fert_kg_ha"])

st.subheader("NDVI → zonas")
area = st.number_input("Área total (ha)", 0.0, 1e7, 50.0)
th   = st.text_input("Thresholds (JSON)", "[0.33,0.66]")
file = st.file_uploader("NDVI (GeoTIFF/RGB)", type=["tif","tiff","png","jpg","jpeg"])

fmt  = st.selectbox("Formato Prescrição", ["csv","shp","isoxml"])
name = st.text_input("Nome do arquivo", "presc_template_ndvi")
profile = st.selectbox("Perfil ISOXML (opcional)", ["", "deere_basic"])

if st.button("Gerar Prescrição a partir do Template"):
    if not file: st.error("Envie o NDVI."); 
    else:
        seg = requests.post(f"{api}/ndvi/segment", files={"ndvi_file": (file.name, file.getvalue(), file.type or "application/octet-stream")}, data={"thresholds": th, "area_ha": area}).json()
        st.json(seg)
        if seg.get("ok"):
            z = requests.post(f"{api}/templates/zones_from_ndvi", params={"culture":culture,"application":application}, json=seg["zones"]).json()["zones"]
            payload = {"name": name, "format": fmt, "zones": z}
            if profile: payload["profile"] = profile
            j = requests.post(f"{api}/vra/generate", json=payload).json()
            st.subheader("Arquivo")
            st.json(j)
            if j.get("ok"):
                st.markdown(f"[Baixar]({api.rstrip('/')}/{j['path']})")